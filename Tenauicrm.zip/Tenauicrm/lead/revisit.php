<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
  $events = (array)$database->getLeadRevisitDates();
             $n = 0;
                foreach ($events as $event) { 

                  $cat = $event['rDate'];
                  $cat = explode("/", $cat);
                  $d = $cat[0];
                  $m = $cat[1];
                  $y = $cat[2];

                  $dateMax = $y."".$m."".$d;
                  $database->updateDateStamp($event['id'],$dateMax);  
                }
?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tenaui+</title>

    <link href="<?php echo $host;?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/animate.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/style.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/dataTables/datatables.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/datapicker/datepicker3.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">

   <?php include("../includes/header.php");?>
            
        <div class="row">
        <?php 
            $rS = "";
            $rE = "";

            if(isset($_POST['btnSearchMyRdate'])){
                if(!empty($_POST['txtstart']) && !empty($_POST['txtend'])){
                        $rS = $database->test_input($_POST['txtstart']);
                        $rS = explode("/", $rS);
                          $d = $rS[0];
                          $m = $rS[1];
                          $y = $rS[2];
                          $rS = $y."".$d."".$m;

                        $rE = $database->test_input($_POST['txtend']);
                        $rE = explode("/", $rE);
                          $d = $rE[0];
                          $m = $rE[1];
                          $y = $rE[2];
                          $rE = $y."".$d."".$m;
                    }

            }
        ?>
        
       <?php $myleads = (array)$database->getRevisitDate($rS,$rE);?>

            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInUp">
                 <div class="form-group" id="data_5">
                            <form method="post">
                                <label class="font-normal">Range select</label>
                                <div class="input-daterange input-group" id="datepicker">
                                <span class="input-group-addon">from</span>
                                    <input type="text" class="input-sm form-control" readonly="" name="txtstart" value=""/>
                                    <span class="input-group-addon">to</span>
                                    <input type="text" class="input-sm form-control" readonly="" name="txtend" value="" />
                                     <span class="input-group-addon">
                                     <button name="btnSearchMyRdate" class="btn-primary"><i class="fa fa-search"></i></button>
                                     </span>
                                </div>
                            </form>
                    </div>
                  
<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        
                        <div class="ibox-tools">
                        
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                            <li>Company Name <input type="checkbox" checked="" id="myCheck1"></li>
                            <li><a class="toggle-vis" data-column="1">Contact person</a></li>
                            <li><a class="toggle-vis" data-column="2">Phone No.</a></li>
                            <li><a class="toggle-vis" data-column="3">Email</a></li>
                            <li><a class="toggle-vis" data-column="4">Quote Amount</a></li>
                            <li><a class="toggle-vis" data-column="5">Exp. Close Date</a></li>
                            <li><a class="toggle-vis" data-column="6">Revist Date</a></li>
                            <li><a class="toggle-vis" data-column="7">Sales Stage</a></li>

                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">

                        <div class="table-responsive">

                   
                    <table id="myExample" style="font-size: 12px;" class="table table-striped table-bordered table-hover dataTables-example" cellspacing="0" width="100%">
      <thead>
       <th></th>
           <th>Company Name</th>
           <th>Area</th>
                        <th>Contact Person</th>
                        <th>Phone No.</th>
                       <!-- <th>Email</th>-->
                        <th>Sales Stage</th>
                        <th>Assigned</th>
                        <th>Quote Amount</th>
                        
                        <th>Revist Date</th>
                        <th>Closing Date</th>
                        
                        
        </thead>
        <tfoot>
         <th></th>
            <th>Company Name</th>
            <th width="3%">Area</th>
                        <th>Contact Person</th>
                        <th>Phone No.</th>
                         <!-- <th>Email</th>-->
                        <th>Sales Stage</th>
                        <th>Assigned</th>
                        <th>Quote Amount</th>
                       
                        <th>Revist Date</th>
                        <th>Closing Date</th>
                        
                       
        </tfoot>

        <tbody>
             <?php $n =1;
                        foreach ((array)$myleads as $leads) {
                           
                                                    
                    ?>

                    <tr class="gradeX">
                    <td><?php echo $n;?></td>
                        <td><a href="<?php echo $host;?>lead-profile/<?php echo $leads['id'];?>"><?php echo $leads['companyName'];?></a></td>
                        <td><?php echo $leads['areaname'];?>, <?php echo ucfirst(strtolower($leads['state']));?></td>
                        <td><?php echo $leads['fullname'];?></td>
                        <td><?php echo $leads['phoneNo'];?></td>
                       <!-- <td><?php echo $leads['email'];?></td>-->
                        <td><?php echo $database->getSalesStage($leads['salesStage']);?>-<?php echo $leads['salesStage']."%";?></td>
                        <td><?php echo $leads['admin'];?> </td>
                        <td><?php echo $database->convertToMoney($database->getLeadQuoteAmount($leads['id']));?></td>
                       
                        <td><?php echo $leads['rDate'];?></td>
                        <td><?php echo $leads['ecDate'];?></td>
                       
                        
                        </tr>
                      
                        
                  
                    <?php $n++;}?>
                   </tbody>
    </table>
                 </div>

                    </div>
                </div>
            </div>
            </div>
        </div>




                </div>
            </div>
        </div>
      
        </div>

    <!-- Mainly scripts -->
     <script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo $host;?>js/bootstrap.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <script src="<?php echo $host;?>js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo $host;?>js/inspinia.js"></script>
    <script src="<?php echo $host;?>js/plugins/pace/pace.min.js"></script>  




<script>
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                pageLength: 100,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'Leads-Information'},
                    {extend: 'pdf', title: 'Leads-Information'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');
                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });         
        });

    $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myExample tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" size="10" placeholder="'+title+'" />' );
    } );
 
    // DataTable
    var table = $('#myExample').DataTable();
    // table.colReorder: { realtime: false }
 
// table.colReorder: true;

    // Apply the search
    table.columns().every( function () {
        var that = this;
 
        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );

    //hide columns
    table.column(0).visible(false);

   $('#myCheck1').change(function() {
      table.columns(0).visible($(this).is(':checked'))
    });
   

    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );

} );
    

    </script>

    <!-- Chosen -->
    <script src="<?php echo $host;?>js/plugins/chosen/chosen.jquery.js"></script>

   <!-- JSKnob -->
   <script src="js/plugins/jsKnob/jquery.knob.js"></script>

   <!-- Input Mask-->
    <script src="<?php echo $host;?>js/plugins/jasny/jasny-bootstrap.min.js"></script>

   <!-- Data picker -->
   <script src="<?php echo $host;?>js/plugins/datapicker/bootstrap-datepicker.js"></script>

   <!-- NouSlider -->
   <script src="<?php echo $host;?>js/plugins/nouslider/jquery.nouislider.min.js"></script>

   <!-- Switchery -->
   <script src="<?php echo $host;?>js/plugins/switchery/switchery.js"></script>

    <!-- IonRangeSlider -->
    <script src="<?php echo $host;?>js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

    <!-- iCheck -->
    <script src="<?php echo $host;?>js/plugins/iCheck/icheck.min.js"></script>

    <!-- MENU -->
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Color picker -->
    <script src="<?php echo $host;?>js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

    <!-- Clock picker -->
    <script src="<?php echo $host;?>js/plugins/clockpicker/clockpicker.js"></script>


    <!-- Image cropper -->
    <script src="<?php echo $host;?>js/plugins/cropper/cropper.min.js"></script>

    <!-- Date range use moment.js same as full calendar plugin -->
    <script src="<?php echo $host;?>js/plugins/fullcalendar/moment.min.js"></script>

    <!-- Date range picker -->
    <script src="<?php echo $host;?>js/plugins/daterangepicker/daterangepicker.js"></script>

    <!-- Select2 -->
    <script src="<?php echo $host;?>js/plugins/select2/select2.full.min.js"></script>

    <!-- TouchSpin -->
    <script src="<?php echo $host;?>js/plugins/touchspin/jquery.bootstrap-touchspin.min.js"></script>

    <!-- Tags Input -->
    <script src="<?php echo $host;?>js/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>

    <!-- Dual Listbox -->
    <script src="<?php echo $host;?>js/plugins/dualListbox/jquery.bootstrap-duallistbox.js"></script>

    <script>
        $(document).ready(function(){

           

            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#data_2 .input-group.date').datepicker({
                startView: 1,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $('#data_3 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_4 .input-group.date').datepicker({
                minViewMode: 1,
                keyboardNavigation: false,
                forceParse: false,
                forceParse: false,
                autoclose: true,
                todayHighlight: true
            });

            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            

            $('input[name="daterange"]').daterangepicker();

            $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));

            $('#reportrange').daterangepicker({
                format: 'MM/DD/YYYY',
                startDate: moment().subtract(29, 'days'),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '12/31/2015',
                dateLimit: { days: 60 },
                showDropdowns: true,
                showWeekNumbers: true,
                timePicker: false,
                timePickerIncrement: 1,
                timePicker12Hour: true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                opens: 'right',
                drops: 'down',
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-primary',
                cancelClass: 'btn-default',
                separator: ' to ',
                locale: {
                    applyLabel: 'Submit',
                    cancelLabel: 'Cancel',
                    fromLabel: 'From',
                    toLabel: 'To',
                    customRangeLabel: 'Custom',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
                    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                    firstDay: 1
                }
            }, function(start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            });

            $(".select2_demo_1").select2();
            $(".select2_demo_2").select2();
            $(".select2_demo_3").select2({
                placeholder: "Select a state",
                allowClear: true
            });


            $(".touchspin1").TouchSpin({
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin2").TouchSpin({
                min: 0,
                max: 100,
                step: 0.1,
                decimals: 2,
                boostat: 5,
                maxboostedstep: 10,
                postfix: '%',
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin3").TouchSpin({
                verticalbuttons: true,
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $('.dual_select').bootstrapDualListbox({
                selectorMinimalHeight: 160
            });


        });

        $('.chosen-select').chosen({width: "100%"});

        $("#ionrange_1").ionRangeSlider({
            min: 0,
            max: 5000,
            type: 'double',
            prefix: "$",
            maxPostfix: "+",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_2").ionRangeSlider({
            min: 0,
            max: 10,
            type: 'single',
            step: 0.1,
            postfix: " carats",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_3").ionRangeSlider({
            min: -50,
            max: 50,
            from: 0,
            postfix: "°",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_4").ionRangeSlider({
            values: [
                "January", "February", "March",
                "April", "May", "June",
                "July", "August", "September",
                "October", "November", "December"
            ],
            type: 'single',
            hasGrid: true
        });

        $("#ionrange_5").ionRangeSlider({
            min: 10000,
            max: 100000,
            step: 100,
            postfix: " km",
            from: 55000,
            hideMinMax: true,
            hideFromTo: false
        });

        $(".dial").knob();

        var basic_slider = document.getElementById('basic_slider');

        noUiSlider.create(basic_slider, {
            start: 40,
            behaviour: 'tap',
            connect: 'upper',
            range: {
                'min':  20,
                'max':  80
            }
        });

        var range_slider = document.getElementById('range_slider');

        noUiSlider.create(range_slider, {
            start: [ 40, 60 ],
            behaviour: 'drag',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });

        var drag_fixed = document.getElementById('drag-fixed');

        noUiSlider.create(drag_fixed, {
            start: [ 40, 60 ],
            behaviour: 'drag-fixed',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });


    </script>
    <script type="text/javascript">
$('.clockpicker').clockpicker();
</script>
</body>

</html>
