<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");


$month = date('n');
$yr = date('Y');

?>
<link href="<?php echo $host;?>css/plugins/footable/footable.core.css" rel="stylesheet">
 <link href="<?php echo $host;?>css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
      <link href="<?php echo $host;?>css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <link href="<?php echo $host;?>css/style.css" rel="stylesheet">



<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>

</head>

<?php include("../includes/header.php");?>
<script src="<?php echo $host;?>amcharts/amcharts.js" type="text/javascript"></script>
        <script src="<?php echo $host;?>amcharts/serial.js" type="text/javascript"></script>
        <script src="<?php echo $host;?>amcharts/pie.js" type="text/javascript"></script>


 <script>
            var chart;

            var chartData = [
            <?php

                $ranking = $database->getLeadProductCategoryRating();
                $n = 1;
                foreach ($ranking as $rank) {
                     $rand = dechex(rand(0x000000, 0xFFFFFF));
            ?>

                    {
                        "country": "<?php echo $rank['category'];?>",
                        "visits":"<?php echo $rank['myCount'];?>",
                        //"color":"rgba(255,"+<?php echo $rank['myCount'];?>+",0,1)"
                        "color" :"<?php echo('#' . $rand); ?>"
                    },

        <?php }?>

             ];


            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "country";
                chart.startDuration = 2;
                chart.depth3D = 0;
                chart.angle = 30;
                chart.marginRight = -5;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0;
                categoryAxis.axisAlpha = 0;
                categoryAxis.labelRotation = 20;
                categoryAxis.dashLength = 5;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.axisAlpha = 0;
                valueAxis.gridAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPH
                var graph = new AmCharts.AmGraph();
                graph.valueField = "visits";
                graph.colorField = "color";
                graph.balloonText = "<b>[[category]]: [[value]]</b>";
                graph.type = "column";
                graph.lineAlpha = 0.5;
                graph.lineColor = "#FFFFFF";
                graph.topRadius = 0.8;
                graph.innerRadius =0.2;

                graph.fillAlphas = 0.9;
                chart.addGraph(graph);

                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chartCursor.cursorAlpha = 0;
                chartCursor.zoomable = false;
                chartCursor.categoryBalloonEnabled = false;
                chartCursor.valueLineEnabled = true;
                chartCursor.valueLineBalloonEnabled = true;
                chartCursor.valueLineAlpha = 1;
                chart.addChartCursor(chartCursor);

                chart.creditsPosition = "top-right";

                // WRITE
                chart.write("chartdiv");
            });
        </script>

<!--pie chart-->

<script>
var chart2;
            var legend2;

            var chartData2 = [
            <?php

                $ranking = $database->getLeadProductCategoryRating();
                $n = 1;
                foreach ($ranking as $rank) {
                    $rand = dechex(rand(0xFF0000, 0xFFFFFF));
                    
            ?>

                    {
                        "country": "<?php echo $rank['category'];?>",
                        "litres":"<?php echo $rank['myCount'];?>",
                        //"color":"rgba(255,"+<?php echo $rank['myCount'];?>+",0,1)"
                       // "color" :"<?php echo('#' . $rand); ?>"
                    },

        <?php }?>
            ];

           AmCharts.ready(function () {
                // PIE CHART
                chart2 = new AmCharts.AmPieChart();
                chart2.dataProvider = chartData2;
                chart2.titleField = "country";
                chart2.valueField = "litres";
               // chart2.colorField = "color";

                chart2.gradientRatio = [0, 0, 0 ,-0.2, -0.4];
                chart2.gradientType = "radial";
                chart2.innerRadius = "30%";
                chart2.startDuration = 2;
                chart2.labelRadius = 15;

                // LEGEND
                legend2 = new AmCharts.AmLegend();
                legend2.align = "center";
                legend2.markerType = "circle";
                chart2.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                chart2.addLegend(legend2);

                // WRITE
                chart2.write("chartdiv2");
            });

            // changes label position (labelRadius)
            function setLabelPosition() {
                if (document.getElementById("rb1").checked) {
                    chart.labelRadius = 30;
                    chart.labelText = "[[title]]: [[value]]";
                } else {
                    chart.labelRadius = -30;
                    chart.labelText = "[[percents]]%";
                }
                chart.validateNow();
            }


            // makes chart 2D/3D
            function set3D() {
                if (document.getElementById("rb3").checked) {
                    chart.depth3D = 10;
                    chart.angle = 10;
                } else {
                    chart.depth3D = 0;
                    chart.angle = 0;
                }
                chart.validateNow();
            }

            // changes switch of the legend (x or v)
            function setSwitch() {
                if (document.getElementById("rb5").checked) {
                    legend.switchType = "x";
                } else {
                    legend.switchType = "v";
                }
                legend.validateNow();
            }


        </script>
  <div class="wrapper wrapper-content">

  <div class="row">
                    <div class="col-lg-6">
                        <div class="ibox float-e-margins">
                            <div class="ibox-content">
                                   <div id="chartdiv" style="width: 100%; height: 400px;"></div>
                            </div>
                        </div>
                    </div>
                        <div class="col-lg-6">
                                                <div class="ibox float-e-margins">
                                                        <div class="ibox-content">
                                                             <div id="chartdiv2" style="width: 100%; height: 400px;"></div>
                                                        </div>
                                                </div>
                                        </div>
</div>

 <!-- <?php 
  //if(isset()){

 // }

  ?> -->

  <div class="row">
                    <div class="col-lg-12">




     <form action="" method="POST">
          <div class="row">
                <div class="col-md-2"><label>&nbsp;</label></div>



                <div class="col-md-2"><select name="txtYear" class="form-control" id="">
                    <?php
                    $yr = date("Y");
                            for ($i=$yr; $i > $yr - 2; $i--) {?>
                                <option value="<?php echo $i;?>" <?php if(isset($_POST['txtYear']) && ($_POST['txtYear'] == $i) ){echo "selected";}?>> <?php echo $i; ?>   </option>
                    <?php  }?>
                    <option></option>
                </select>
            </div>
                <div class="col-md-3"><input type="submit" name="yearlySalesGraph" value="VIEW" class="btn btn-success col-md-12" /></div>
            </div>                    

  </form>
                        <div class="ibox float-e-margins">
                            <div class="ibox-content">
                                    <div>

                                    <?php

                                    if (isset($_POST['yearlySalesGraph'])) {
                                        
                                         $month = 12;

                                         $yr = $_POST['txtYear'];

                                         $totalSalesThisYear = 0;
                                             for ($i=1; $i < $month + 1; $i++) {
                                             $totalSalesThisYear +=$database->getTeamSumMonthlySales($i,$yr)+$database->getTeamMPSMonthlySales($i,$yr);
                                    }

                                    }


                                    else{

                                     
                                    $totalSalesThisYear = 0;
                                             for ($i=1; $i < date('m')+1; $i++) {
                                             $totalSalesThisYear +=$database->getTeamSumMonthlySales($i,$yr)+$database->getTeamMPSMonthlySales($i,$yr);
                                    }}?>
                                        <span class="pull-right text-right">
                                        <small>Average  value of sales in the past months for: <strong><?php echo $yr;?></strong></small>
                                            <br/>
                                            <!--Best Sales: 162,862-->
                                        </span>
                                        <h1 class="m-b-xs"><?php echo $database->convertToMoney($totalSalesThisYear);?></h1>
                                        <h3 class="font-bold no-margins">
                                         Gross revenue margin
                                        </h3>
                                        <small>Sales marketing.</small>
                                       <!-- <div class="pull-right">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-xs btn-white active">Today</button>
                                                <button type="button" class="btn btn-xs btn-white">Monthly</button>
                                                <button type="button" class="btn btn-xs btn-white">Annual</button>
                                            </div>
                                        </div>-->
                                    </div>

                                <div>
                                    <canvas id="lineChart" height="100"></canvas>
                                </div>

                                <div class="m-t-md">
                                    <small class="pull-right">
                                        <i class="fa fa-clock-o"> </i>
                                        Update on <?php echo date("d.M.Y");?>
                                    </small>
                                   <small>
                                       <strong>Analysis of sales:</strong> The value of this graph depends solely on information supplied by sales team.
                                   </small>
                                </div>

                            </div>
                        </div>

                    </div>
</div>

        <div class="row ibox float-e-margins ibox-content">
         <h1 class="font-bold m-b-xs">Your Monthly Sales</h1>
                                        <h3 class="font-bold no-margins">
                                            &nbsp;
                                        </h3>

                <?php
                        $myCount = 3;
                        for ($i=1; $i < 13; $i++) {

                ?>

                <?php if($myCount % 3 == 0){?>
                <?php if(($myCount % 3 == 0) && $myCount != 3){?>
                    </ul>
                  </div>
                <?php }?>
                 <div class="col-lg-3 ">
                      <ul class="stat-list">
                <?php }?>

                                        <li>
                                        <?php
                                                    $thatMTarget =  $database->getMonthlyTarget($i,$yr);
                                                     $monthName = date('F', mktime(0, 0, 0, $i, 10));
                                        ?>
                                                 <small>Total orders in the month of <?php echo $monthName;?></small><br/>
                                            <h2 class="no-margins">


                                            <?php
                                                 $thatMonthAmount_ = $database->getTeamSumMonthlySales($i,$yr) + $database->getTeamMPSMonthlySales($i,$yr);

                                                 echo $database->convertToMoney($thatMonthAmount_);
                                                 $pctn = $database->calculatePercentage($thatMonthAmount_,$thatMTarget);
                                            ?>
                                            </h2>


                                            <small><?php echo $monthName;?> Target : <b><?php  echo $database->convertToMoney($thatMTarget);?></b></small><br/>
                                            <div class="stat-percent"><?php echo $pctn;?>% <!--<i class="fa fa-level-up text-navy"></i>--></div>
                                            <div class="progress progress-striped active">
                                                <div style="width: <?php echo $pctn;?>%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="<?php echo $pctn;?>" role="progressbar" class="progress-bar progress-bar-<?php echo $database->returnSalesStageColor($pctn);?>">
                                                    <span class="sr-only"><?php echo $pctn;?>% Complete (success)</span>
                                                </div>
                                            </div>

                                           <!-- <div class="progress progress">
                                                <div style="width: <?php echo $pctn;?>%;" class="progress-bar "></div>
                                            </div>-->
                                        </li>

                                         <?php $myCount++; }?>

                    </div>


<br/>

<div class="row">
<div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Orders Collected </h5>

                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">

                            <table class="footable table table-stripped toggle-arrow-tiny dataTables-example">
                                <thead>
                                <tr>

                                    <th data-toggle="true">Lead</th>
                                    <th>Ticket</th>
                                    <th>Amount</th>
                                    <th data-hide="all">Items</th>
                                    <th data-hide="all">Completed</th>

                                    <th>Date</th>
                                    <th>Order</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                    $orders = (array)$database->getTeamAllOrderCollected();
                                    foreach ($orders as $order) {


                                ?>
                                <tr>
                                    <td><?php echo $order['companyName'];?></td>
                                    <td><?php echo $order['ticketNo'];?></td>
                                    <td><?php echo $database->convertToMoney($order['Amount']);?></td>
                                    <td>
                                    <?php

                                $myBills = (array)$database->getLeadProductOrderOnLeadDemand($order['leadID'],$order['ticketID']);
                                foreach ($myBills as $myBill) {

                                    ?>
                                    <?php echo $myBill['productName']; ?>&nbsp;  ---  &nbsp;(<?php echo $myBill['qty']; ?>) &nbsp;  ---  &nbsp;<?php echo $myBill['Code'];?>&nbsp;  ---  &nbsp;<?php echo $database->convertToMoney($myBill['Amount']);?>&nbsp;  ---  &nbsp;<?php echo $database->convertToMoney($myBill['Amount'] * $myBill['qty']);?><br/>

                                    <?php }?>



                                    </td>
                                    <td><span class="pie">100/100</span></td>

                                    <td><?php echo $order['orderCollectedDate'];?></td>
                                    <td><a href="<?php echo $host;?>user-profile/<?php echo $order['assigned'];?>"><?php echo $order['myadmin'];?></a></td>
                                </tr>

                                <?php }?>

                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="5">
                                        <ul class="pagination pull-right"></ul>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>

</div>

<div class="row">
    <div class="col-lg-6">


    </div>
    <div class="col-lg-6"></div>

</div>


<div class="row">
<div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Orders Collected </h5>

                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>

                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">

                            <table class="footable table table-stripped toggle-arrow-tiny">
                                <thead>
                                <tr>

                                    <th data-toggle="true">Month</th>
                                    <th>Year</th>
                                    <!--<th>Amount</th>-->
                                    <th data-hide="all">Items</th>
                                    <th data-hide="all">Completed</th>


                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                        for($i=1; $i < 13; $i++) {
                                            //echo '"'.date('F', mktime(0, 0, 0, $i, 10)).'",';

                                ?>
                                <tr>
                                    <td><?php echo date('F', mktime(0, 0, 0, $i, 10));?></td>
                                    <td><?php echo date('Y');?></td>
                                    <!--<td></td>-->
                                    <td>
                                    <?php

                                $myBills = (array)$database->getLeadProductOrderOnLeadDemandProductRatingMonthly($i,date('Y'));
                                foreach ($myBills as $myBill) {

                                    ?>
                            &nbsp;(<?php echo $myBill['myCount']; ?>) &nbsp; ----- <?php echo $myBill['productName']; ?>&nbsp;  <br/>

                                    <?php }?>



                                    </td>
                                    <td><span class="pie">100/100</span></td>



                                </tr>

                                <?php }?>

                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="5">
                                        <ul class="pagination pull-right"></ul>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>

</div>

<div class="row">
    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Product Analysis </h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                               <!-- <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>-->
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <div id="morris-line-chart"></div>
                        </div>
                    </div>

</div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Activities</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                           <!-- <div class="ibox-content ibox-heading">
                                <h3><i class="fa fa-envelope-o"></i> New messages</h3>
                                <small><i class="fa fa-tim"></i> You have 22 new messages and 16 waiting in draft folder.</small>
                            </div>-->
                            <div class="ibox-content">
                                <div class="feed-activity-list">
                                <?php
                                $n = 0;
                                        $acts = (array)$database->getActivitiesNotifications();
                                        foreach ($acts as $act) {
                                            if($n == 16){break;}

                                ?>
                                    <div class="feed-element">
                                        <div>
                                            <small class="pull-right text-navy"><?php echo $database->time_elapsed_string($act['timeStamp']);?></small>
                                            <strong><?php echo $act['admin'];?></strong>
                                            <div><?php echo $act['activities'];?></div>
                                            <small class="text-muted"><?php echo $act['dateTime'];?></small>
                                        </div>
                                    </div>
<?php  $n++;}?>
    <?php if(count($act) > 10){?>
                                    <a href="" class="btn btn-white col-lg-12"><i class="fa fa-chevron-down"></i> View More Activities</a><?php }?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-8">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Sales Ranking for the month of <?php echo date('F');?></h5>
                                        <div class="ibox-tools">
                                            <a class="collapse-link">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a class="close-link">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="ibox-content">
                                        <table class="table table-hover no-margins">
                                            <thead>
                                            <tr>
                                            <th style="width: 1%" class="text-center">No.</th>
                                                <th>Amount</th>

                                                <th>Admin</th>
                                                <th>Contribution</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php

                                                $ranking = $database->getMonthlyOrderCollectedRanking2($month,$yr);
                                                $n = 1;
                                                foreach ($ranking as $rank) {

                                            ?>
                                            <tr>
                                            <th><?php echo $n;?>.</th>
                                                <td><span class="label label-primary">
                                                <?php echo $database->convertToMoney($rank['totalAmount']);?></span>
                                                </td>

                                                <td><?php echo $rank['admin'];?></td>
                                                <td class="text-navy">

                                                 <i class="fa fa-level-up"></i>


                                                <?php echo $database->calculatePercentage($rank['totalAmount'],$thisMonthAmount_);?>%</td>
                                            </tr>
                                            <?php $n++; }?>

                                            </tbody>
                                        </table>
                                         <a href="<?php echo $host;?>monthly-sales?txtMonth=<?php echo $month;?>&txtYear=<?php echo $yr;?>&Submit=VIEW" class="btn btn-warning col-lg-12"><i class="fa fa-area-chart"></i> View Graph</a>

                                    </div>
                                </div>
                            </div>

                        </div>

                         <div class="row">
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Sales Ranking for the Year of <?php echo date('Y');?></h5>
                                        <div class="ibox-tools">
                                            <a class="collapse-link">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a class="close-link">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="ibox-content">
                                        <table class="table table-hover no-margins">
                                            <thead>
                                            <tr>
                                            <th style="width: 1%" class="text-center">No.</th>
                                                <th>Amount</th>

                                                <th>Admin</th>
                                                <!--<th>Contribution</th>-->
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php

                                                $ranking = $database->getYearlyOrderCollectedRanking($yr);
                                                $n = 1;
                                                foreach ($ranking as $rank) {

                                            ?>
                                            <tr>
                                            <th><?php echo $n;?>.</th>
                                                <td><span class="label label-primary">
                                                <?php echo $database->convertToMoney($rank['Amount']);?></span>
                                                </td>

                                                <td><?php echo $rank['admin'];?></td>

                                            </tr>
                                            <?php $n++; }?>

                                            </tbody>
                                        </table>
                                         <!--<a href="<?php echo $host;?>yearly-sales" class="btn btn-warning col-lg-12"><i class="fa fa-area-chart"></i> View Graph</a>-->
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Top 10 Highest Single Transaction Made</h5>
                                        <div class="ibox-tools">
                                            <a class="collapse-link">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a class="close-link">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="ibox-content">

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table table-hover margin bottom">
                                                    <thead>
                                                    <tr>
                                                        <th style="width: 1%" class="text-center">No.</th>
                                                        <th>CompanyName</th>
                                                        <th class="text-center">Amount</th>
                                                         <th class="text-center">Admin</th>
                                                        <th class="text-center">Date</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php
                                                        $n = 1;
                                                        $trans = (array)$database->getTransactionRanking($yr);
                                                        foreach ($trans as $tran) {
                                                            if($n == 11){break;}
                                                           ?>
                                                    <tr>
                                                        <td class="text-center"><?php echo $n;?></td>
                                                        <td> <?php echo $tran['companyName'];?> </td>
                                                        <td class="text-center">
                                                        <span class="label label-primary">
                                                        <?php echo $database->convertToMoney($tran['Amount']);?>
                                                        </span>
                                                        </td>
                                                        <td class="text-center small"><?php echo $tran['admin'];?></td>
                                                        <td class="text-center small"><?php echo $tran['ocMonth']."-".$tran['ocYear'];?></td>


                                                    </tr>
                                                    <?php $n++;}?>

                                                    </tbody>
                                                </table>

    <?php if(count($trans) > 5){?>
                                    <a href="" class="btn btn-info col-lg-12"><i class="fa fa-chevron-down"></i> View More Transaction ranking</a><?php }?>

                                            </div>

                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>


                </div>
                </div>

        </div>
        <?php //include("includes/chats.php");?>
        <?php //include("includes/activities.php");?>





    <!-- Mainly scripts -->
    <script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo $host;?>js/bootstrap.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Flot -->
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/jquery.flot.symbol.js"></script>
    <script src="<?php echo $host;?>js/plugins/flot/curvedLines.js"></script>

    <!-- Peity -->
    <script src="<?php echo $host;?>js/plugins/peity/jquery.peity.min.js"></script>
    <script src="<?php echo $host;?>js/demo/peity-demo.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo $host;?>js/inspinia.js"></script>
    <script src="<?php echo $host;?>js/plugins/pace/pace.min.js"></script>



 <!-- jQuery UI -->
    <script src="<?php echo $host;?>js/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- FooTable -->
    <script src="<?php echo $host;?>js/plugins/footable/footable.all.min.js"></script>
    <!-- Jvectormap -->
    <script src="<?php echo $host;?>js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- Sparkline -->
    <script src="<?php echo $host;?>js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="<?php echo $host;?>js/demo/sparkline-demo.js"></script>

    <!-- ChartJS-->
    <script src="<?php echo $host;?>js/plugins/chartJs/Chart.min.js"></script>
     <!-- Morris -->
    <script src="<?php echo $host;?>js/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/morris/morris.js"></script>



    <script>

      $(document).ready(function() {


    Morris.Line({
        element: 'morris-line-chart',

        data: [

            { y: '2006', a: 100000, b: 90000 },
            { y: '2007', a: 75000, b: 65000 },
            { y: '2008', a: 50000, b: 45600 },
            { y: '2009', a: 72305, b: 64595 },
            { y: '2010', a: 54440, b: 40394 },
            { y: '2011', a: 75293, b: 29365 },
            { y: '2012', a: 100949, b: 29390 }

            ],
        xkey: 'y',

        ykeys: ['a', 'b'],

        labels: ['Series A', 'Series B'],

        hideHover: 'auto',

        resize: true,

        lineColors: ['#54cdb4','#1ab394'],

    });

});

    </script>

    <script>
        $(document).ready(function() {

            var lineData = {
                labels: [


                <?php

                                    

                                         ?>

                            <?php


                            for ($i=1; $i < 13; $i++) {
                                 echo '"'.date('F', mktime(0, 0, 0, $i, 10)).'",';
                            }?>
                ],
                datasets: [
                    {
                        label: "Sales",
                        backgroundColor: "rgba(26,179,148,0.5)",
                        borderColor: "rgba(26,179,148,0.7)",
                        pointBackgroundColor: "rgba(26,179,148,1)",
                        pointBorderColor: "#fff",
                        data:
                        [
                            <?php

                            if (isset($_POST['yearlySalesGraph'])) {
                                        
                                         $month = 12;

                                         $yr = $_POST['txtYear'];

                                         for ($i=1; $i < $month + 1; $i++) {
                                 echo $database->getTeamSumMonthlySales($i,$yr)+$database->getTeamMPSMonthlySales($i,$yr).",";
                                     }}else{

                                 for ($i=1; $i < date('m')+1; $i++) {
                                 echo $database->getTeamSumMonthlySales($i,$yr)+$database->getTeamMPSMonthlySales($i,$yr).",";

                                     }

                                
                            }?>
                        ]
                    },
                    {
                        label: "Target",
                        backgroundColor: "rgba(220,220,220,0.5)",
                        borderColor: "rgba(220,220,220,1)",
                        pointBackgroundColor: "rgba(220,220,220,1)",
                        pointBorderColor: "#fff",
                        data: [
                                 <?php
                                 if (isset($_POST['yearlySalesGraph'])) {
                                        
                                         $month = 12;

                                         $yr = $_POST['txtYear'];

                                 for ($i=1; $i < $month+1; $i++) {
                                     echo $database->getMonthlyTarget($i,$yr).",";

                                 }
                                  }else{

                                   for ($i=1; $i < date('m')+1; $i++) {
                                     echo $database->getMonthlyTarget($i,$yr).",";

                                  }
                              }
                                  ?>

                        ]
                    }

                ]
            };

            var lineOptions = {
                responsive: true
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});

        });
    </script>
    <script>
        $(document).ready(function() {

            $('.footable').footable();
            $('.footable2').footable();

        });

    </script>
</body>
</html>
