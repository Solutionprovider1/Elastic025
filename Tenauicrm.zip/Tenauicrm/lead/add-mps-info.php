<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
   $getLeadID ="";
if(isset($_GET['id'])){$getLeadID = $_GET['id'];}else{$database->redirect_to($host."view-my-lead");}
//if(isset($_GET['demandID'])){$getDemandID = $_GET['demandID'];}else{$database->redirect_to($host."view-my-lead");}
$leadData = $database->getLeadData($getLeadID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}

?>

<style type="text/css">
  
#wrapper
{
 margin:0 auto;
 padding:0px;
/* text-align:center;*/
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:#9A7D0A;
}
#wrapper h1 p
{
 font-size:18px;
}
#employee_table input[type="text"]
{
 width:120px;
 height:35px;
 padding-left:10px;
}
#form_div input[type="button"]
{
 width:110px;
 height:35px;
 background-color:#D4AC0D;
 border:none;
 border-bottom:3px solid #B7950B;
 border-radius:3px;
 color:white;
}
#form_div input[type="submit"]
{
 margin-top:10px;
 width:110px;
 height:35px;
 background-color:#D4AC0D;
 border:none;
 border-bottom:3px solid #B7950B;
 border-radius:3px;
 color:white;
}
</style>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
    <link href="<?php echo $host;?>css/plugins/dualListbox/bootstrap-duallistbox.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/select2/select2.min.css" rel="stylesheet">
</head>
<script src="<?php echo $host;?>js/jquery.min.js"></script>
<?php include("../includes/header.php");?>

<script type="text/javascript">
var parent = <?php echo $database->getArrayStates();?>;
var child = <?php echo $database->getLGAofStates();?>;
var gchild = <?php echo $database->getAreasofLGA();?>;
    function LoadChild(){
        var i = document.getElementById("parent").selectedIndex ;
       // var dp = document.getElementById("child");
        var dp2 = document.getElementById("gchild");
      //  var count = child[i-1].length;
        var count2 = gchild[i-1].length;

        //var html = "<option value=\"\" disabled selected hidden>- select -</option>";
       // for(var k = 0 ; k < count ; k ++){
       //     html += "<option value=\""+child[i-1][k][0]+"\">"+child[i-1][k][1]+"</option>";
       // }

        var html2 = "<option value=\"\" disabled selected hidden>- select -</option>";
        for(var k = 0 ; k < count2 ; k ++){
            html2 += "<option value=\""+gchild[i-1][k][0]+"\">"+gchild[i-1][k][1]+"</option>";
        }
        
       // dp.innerHTML = html;
        dp2.innerHTML = html2;
    }
    
</script>

<?php 
$productsName = "";
       $products = (array)$database->getAllProducts();
                                        foreach ($products as $dpt) {
                                            if($dpt['ProductType'] == 2){break;}
                                            $value = "";
                                            if($dpt['ProductType'] == 1){
                                                $value = $dpt['productName'];
                                            }
                                       
                                         $productsName.='<option value="'. $dpt['id'].'">'. $value.'</option>';
                                         }

                                         ?>

                                         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>



<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Creating MPS for <?php echo $leadData['companyName'];?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Create Managed Printing Service</strong>
                        </li>
                    </ol>
                </div>
               <div class="col-lg-2">
               <a href="<?php echo $host;?>lead-profile/<?php echo $getLeadID;?>" class="btn btn-success">Back</a>

                </div>
            </div>

  <div class="wrapper wrapper-content">
  <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        

                        <?php 
                        $err = "";
                        $msg = "";
                       
                        		if(isset($_POST['btnCreateLead'])){
                        			
                                   // $phone = $database->test_input($_POST['txtPhone']);
                                    $leadID = $getLeadID;
                                    $productID = $database->test_input($_POST['txtProduct']);
                                    $qty = $database->test_input($_POST['txtQty']);
                                    $rentalcharge = $database->test_input($_POST['txtRentalCharge']);
                                    $costMono = $database->test_input($_POST['txtCostMono']);
                                    $costColor = $database->test_input($_POST['txtCostColor']);
                                    $minVolMono = $database->test_input($_POST['txtVolMono']);
                                    $minVolColor = $database->test_input($_POST['txtVolColor']);
                                    $contractDuration = $database->test_input($_POST['txtContractDuration']);
                                    $BillingType = $database->test_input($_POST['txtBillingType']);
                                    $description =$database->test_input($_POST['txtDescription']);

                                    $accessories = "";
                                    if(isset($_POST['txtCC'])){
                                        if (is_array($_POST['txtCC'])) {
                                                foreach($_POST['txtCC'] as $value){
                                                  $accessories = $accessories.",".$value;
                                                }
                                            }else {
                                                $value = $_POST['txtCC'];
                                                $accessories =  $value;
                                              }
                                        }



                                    

                                 if($leadID!= "" && $productID != "" && $qty != "" && $rentalcharge!= "" && $costMono != "" 
                                    && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $contractDuration !="" && $BillingType != ""){

                                        
                                        $database->createMPFTicket($leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories);
                                       
                                            $msg = "your lead MPS ticket has been created successfully!.";
                                           // $_POST['txtFname']="";
                                            unset($_POST);

                                                                          
                                    
                                   }else{
                                            if($productID == ""){$err.="<li>please select product</li>";}
                                            if($qty == ""){$err.="<li>please enter quantity of product</li>";}
                                            if($rentalcharge == ""){$err.="<li>please enter rental charge</li>";}
                                            if($costMono == ""){$err.="<li>please enter the cost of printing Mono</li>";}
                                            if($costColor == ""){$err.="<li>please enter the cost of printing Color</li>";}
                                            if($minVolColor == ""){$err.="<li>please enter the minimum printing Mono</li>";}
                                            if($minVolMono == ""){$err.="<li>please enter the minimum printing Color</li>";}
                                            if($contractDuration == ""){$err.="<li>please select the Contract duration</li>";}
                                            if($BillingType == ""){$err.="<li>please select the Billing type</li>";}
                                    }
                        		
                                }

                        ?>

                        <div class="ibox-content">
                            <form method="post" name="lead-registration" class="form-horizontal">

                             <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	<?php if($err!= ""){$database->showMsg('Error',$err,1);}
                                    	 else if($msg!=""){$database->showMsg('Success',$msg,2);}?>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">Company Name</label>
                                   <div class="col-sm-10">
                                        <input name="txtCompany" value="<?php echo $leadData['companyName'];?>" type="text" placeholder="Enter company Name" required class="form-control required" disabled>
                                       
                                    </div>
                                    
                                </div>
<script type="text/javascript">

function add_row()
{
 $rowno=$("#employee_table tr").length;
 $rowno=$rowno+1;
 $("#employee_table tr:last").after("<tr id='row"+$rowno+"'> <td>  <label style='font-size: 14px;' class='col-sm-2 control-label'></label></td><td><div class='col-sm-3'><select class='chosen form-control m-b' style='width: 230px;' name='txtProduct[]' required=''> <?php

          $getMachineProduct = $database->getAllMachineProducts();
                                        foreach ($getMachineProduct as $machinepPoduct) {
                                                    
                                            $getMechineId = $machinepPoduct['id'];
                                            $getMechineProductName = $machinepPoduct['productName'];

                                          ?> <option value=''></option><option value='<?php echo $getMechineId;?>'><?php echo $getMechineProductName;?></option><?php } ?> </select></div></td><td><label style='font-size: 13px;' class='col-sm-2'>Qty </label></td> <td> <div class='col-sm-1'><input style='width: 50px;' type='text' name='txtQty[]' placeholder='QTY.' required onKeyPress='return isNumberKey(event)'  class='form-control' value='1'/></div></td><div class='col-sm-2'><td><label style='font-size: 13px;' class='col-sm-2'>Rental Charge</label></td><td><input type='text' name='txtRentalCharge[]' placeholder='AMOUNT' onKeyPress='return isNumberKey(event)''  class='form-control' onkeyup = 'javascript:this.value=Comma(this.value);' required /></div></td><td style='padding:20px;'><input type='button' value='DELETE' onclick=delete_row('row"+$rowno+"')></td></tr>");

 $(".chosen").chosen();}


function delete_row(rowno)


{
 $('#'+rowno).remove();

}



</script>

</script>

<div class="hr-line-dashed"></div>
                                 <div class="form-group">

                                <div id="wrapper">

<div id="form_div">

  <table style="float: left; padding: 0px; margin: 0px;" id="employee_table">
   <tr id="row1">
   
      <td>  <label style="font-size: 14px; " class="col-sm-2 control-label">Machine</label></td>
                                
    <td>
    
      <div class="col-sm-3">
         <select style="width: 230px;" class="chosen form-control m-b"  name="txtProduct[]" required="">
                                        <?php

          $getMachineProduct = $database->getAllMachineProducts();
                                        foreach ($getMachineProduct as $machinepPoduct) {
                                                    
                                            $getMechineId = $machinepPoduct['id'];
                                            $getMechineProductName = $machinepPoduct['productName'];

                                          ?>
                                          <option value=""></option>
                                         <option value="<?php echo $getMechineId;?>"><?php echo $getMechineProductName;?></option>
                                          <?php } ?> 
                                         </select> 
      
          </div>
    </td>


     <td><label style="font-size: 13px;" class="col-sm-2">Qty </label></td>
                                  
    <td>
       <div class="col-sm-1">
        <input style="width: 50px;" type="text" name="txtQty[]" placeholder="QTY." required onKeyPress="return isNumberKey(event)"  class="form-control" value="1" />
        </div>
</td>
<td><label style="font-size: 13px;" class="col-sm-2">Rental Charge</label></td>
      <div class="col-sm-2">
    <td><input type="text" name="txtRentalCharge[]" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)"  class="form-control" onkeyup = "javascript:this.value=Comma

(this.value);" required />
        </div>
    </td>
   </tr>
  </table>

   <div style='margin-right: 40px;' class="form-group">

  <input style="float: right;" type="button" onclick="add_row();" value="ADD Machine">
  <!-- <input type="submit" name="submit_row" value="SUBMIT">
 -->
</div>
<br><br>

                                

                 
<!-- 
                                <div class="form-group">
                                <label class="col-sm-2 control-label">Accessories</label>
                                    <div class="col-sm-10">
                                     <select data-placeholder="Choose Accessories for this Machine" name="txtCC[]" class="form-control chosen-select" multiple style="width:350px;" tabindex="4">
                            
                                         <?php 
                                               $acces_ = (array)$database->getAllProducts();
                                               foreach ( $acces_ as  $acceso) {
                                                if($acceso['ProductType'] != 4){continue;}
                                          ?>
                                               
                                             <option value="<?php echo $acceso['id'];?>"><?php echo strtoupper(($acceso['productName']));?></option>      

                                         <?php   } ?>
                        </select>
                                      

                                      
                                </div>
<script type="text/javascript">
$(".chosen").chosen();
</script>
                                </div> -->
                               
                                 <div class="form-group">
                                 </div>

 
                <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Mono</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostMono" class="form-control" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Mono</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" onKeyPress="return isNumberKey(event)" name="txtVolMono" class="form-control" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">Total:</label>
                                     <div class="col-sm-3">
                                  
                                                                                
                                    </div>
                                </div>
                        <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Color</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostColor" class="form-control" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Color</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" onKeyPress="return isNumberKey(event)" name="txtVolColor" class="form-control" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">Total:</label>
                                     <div class="col-sm-3">
                                  
                                                                                
                                    </div>
                                </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Contract Duration</label>
                                <div class="col-sm-3">
                                       <select class="chosen form-control m-b" name="txtContractDuration">
                                         <?php for($i = 4;$i <12;$i++){?>
                                         <option value="<?php echo $i;?>"><?php echo strtoupper($database->convert_number_to_words($i));?> YEARS</option>
                                         <?php }?>
                                         </select>   
                                       
                                    </div>
                                    <script type="text/javascript">
$(".chosen").chosen();
</script>
                                    <label class="col-sm-2 control-label">Billing Type</label>
                                <div class="col-sm-3">
                                       <select class="chosen form-control m-b" name="txtBillingType">

                                       <?php 
                                            $bt = (array)$database->getBillingType();
                                            foreach ($bt as $bts) {
                                               ?>
                                        
                                         <option value="<?php echo $bts['value'];?>"><?php echo $bts['BillingType'];?></option>
                                         
                                         <?php }?>
                                         </select>   
                                       
                                    </div>

                                    <script type="text/javascript">
$(".chosen").chosen();
</script>
                                  
                                </div>
                                
                            <div class="hr-line-dashed"></div>
                             <div class="form-group">
                                <label class="col-sm-2 control-label">Description</label>
                                   <div class="col-sm-10">
                                   <textarea class="form-control" name="txtDescription" placeholder="Describe this MPS Contract"><?php if(isset($_POST['txtDescription'])){echo $_POST['txtDescription'];}?></textarea>
                                    </div>
                                    
                                </div>
<div class="hr-line-dashed"></div>
                                

							<div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	 <button name="btnCreateLead" class="btn btn-primary col-lg-12" type="submit">
                                         <i class="fa fa-user"></i>&nbsp;Create Managed Print Service</button>
                           
                                    </div>
                                </div>
                                </form>

                                                                                  
  </div>
  
  <?php include("../includes/js.php");?>
  <script type="text/javascript">
     $('#trucated').inputmask("numeric", {
    radixPoint: ".",
    groupSeparator: ",",
    digits: 2,
    autoGroup: true,
    prefix: 'N', //No Space, this will truncate the first character
    rightAlign: false,
   oncleared: function(){self.Value('');}
   });
    
  </script>
