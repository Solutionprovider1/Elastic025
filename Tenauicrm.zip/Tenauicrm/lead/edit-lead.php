<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
   $getID ="";
if(isset($_GET['id'])){$getID = $_GET['id'];}else{$database->redirect_to($host."view-my-lead");}?>



<?php 
$err = $err2 = $msg2 = $msg = "";
if(isset($_POST['btnUpdateLead'])){
                                    $name = $database->test_input($_POST['txtFname']);
                                    $phone = $database->test_input($_POST['txtPhone']);
                                    $email = $database->test_input($_POST['txtEmail']);
                                    $country = $database->test_input($_POST['txtCountry']);
                                    $city = $database->test_input($_POST['txtState']);
                                    $address = $database->test_input($_POST['txtAdd']);
                                    $companyName = $database->test_input($_POST['txtCompany']);
                                    $designation = $database->test_input($_POST['txtDesignate']);
                                    $rDate = $database->test_input($_POST['txtRDate']);
                                    $ecDate = $database->test_input($_POST['txtECDate']);
                                    $salesStage = $database->test_input($_POST['txtSalesStage']);
                                    $LeadSource = $database->test_input($_POST['txtleadSource']);
                                    //$assign = $database->test_input($_POST['txtStaff']);
                                    $description = $database->test_input($_POST['txtDescription']);
                                    $lga = $database->test_input($_POST['txtLga']);

                                    if($name!= "" && $phone != "" && $companyName!= ""){

                                        if($database->ValidateCompanyAgainst($companyName,$getID)){
                                            $err = "This company Name has been registered previously";
                                        }else{
                                            $database->EditLeadProfile($name,$phone,$email,$country,$city,$address,$companyName,$designation,$rDate,$ecDate,$salesStage,$LeadSource,$myData['id'],$description,$lga,$getID);
                                            $msg = "your lead has been updated successfully!.";

                                         
                                        }                                      
                                    
                                    }else{
                                            if($name == ""){$err.="<li>please enter name</li>";}
                                            if($phone == ""){$err.="<li>please enter phone number</li>";}
                                            //if($assign == ""){$err.="<li>please assign this lead to a sales person</li>";}
                                            if($companyName == ""){$err.="<li>please enter the company name</li>";}
                                            //if($designation == ""){$err.="<li>please enter the contact person designation</li>";}
                                            //if($rDate == ""){$err.="<li>please enter Revisit date</li>";}
                                            //if($description == ""){$err.="<li>please describe this lead</li>";}
                                    }
                                    
                        }



?>

<?php
$leadData = $database->getLeadData($getID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}



?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>

</head>
<script src="<?php echo $host;?>js/jquery.min.js"></script>
<?php include("../includes/header.php");?>

<script type="text/javascript">
var parent = <?php echo $database->getArrayStates();?>;
var child = <?php echo $database->getLGAofStates();?>;

   var gchild = <?php echo $database->getAreasofLGA();?>;
    function LoadChild(){
        var i = document.getElementById("parent").selectedIndex ;
       // var dp = document.getElementById("child");
        var dp2 = document.getElementById("gchild");
      //  var count = child[i-1].length;
        var count2 = gchild[i-1].length;

        //var html = "<option value=\"\" disabled selected hidden>- select -</option>";
       // for(var k = 0 ; k < count ; k ++){
       //     html += "<option value=\""+child[i-1][k][0]+"\">"+child[i-1][k][1]+"</option>";
       // }

        var html2 = "<option value=\"\" disabled selected hidden>- select -</option>";
        for(var k = 0 ; k < count2 ; k ++){
            html2 += "<option value=\""+gchild[i-1][k][0]+"\">"+gchild[i-1][k][1]+"</option>";
        }
        
       // dp.innerHTML = html;
        dp2.innerHTML = html2;
    }

    
</script>



<?php 
$productsName = "";
       $products = (array)$database->getAllProducts();
                                        foreach ($products as $dpt) {
                                            $value = "";
                                            if($dpt['ProductType'] != 1){
                                                $value = $dpt['productName'].' - '.$dpt['color'];
                                            }else{
                                                $value = $dpt['productName'];
                                            }
                                       
                                         $productsName.='<option value="'. $dpt['id'].'">'. $value.'</option>';
                                         }

                                         ?>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>

       




<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">

    


                    <h2>Edit your Lead</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Editing Lead information for <?php echo ucwords(strtolower($leadData['companyName'])) ;?></strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">
               <a href="<?php echo $host;?>lead-profile/<?php echo $leadData['id'];?>" class="btn btn-success">Back</a>

                </div>
            </div>

  <div class="wrapper wrapper-content">
  <div class="tabs-container">
  <?php 
    if($leadData['assigned'] != $myData['id']){?>
    <div class="wrapper wrapper-content">
                <div class="middle-box text-center animated fadeInRightBig">
                    <h3 class="font-bold">Hello <?php echo ucwords($myData['fullname']); ?></h3>
                    <div class="error-desc">
                        You are trying to access information of a lead that is not assigned to you.:) Click the button below to access your own leads.
                        <br/><a href="<?php echo $host;?>view-my-lead" class="btn btn-primary m-t">View My Leads</a>
                    </div>
                </div>
            </div><?php die(); } ?>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#tab-1">Basic Details</a></li>
                         <!--   <li class=""><a data-toggle="tab" href="#tab-2">Products Information</a></li> -->
                        </ul>
                        <div class="tab-content">
                            <div id="tab-1" class="tab-pane active">
                                <div class="panel-body">
                                   <!-- <strong>Lorem ipsum dolor sit amet, consectetuer adipiscing</strong>-->

                                    <div class="ibox-content">
                                   
                            <form method="post" name="lead-registration" class="form-horizontal">
                            <div id="myDiv" class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    
                                      <?php if($err!= ""){$database->showMsg('Error',$err,1);}
                                       else if($msg!=""){$database->showMsg('Success',$msg,2);}?>
                                         
                                       
                                    </div>
                                </div>

                             <div class="form-group">
                                <label class="col-sm-2 control-label">Sales Stage</label>
                                   <div class="col-sm-3">
                                       <select class="chosen form-control m-b" name="txtSalesStage">
                                     <?php 
                                        $dpts = (array)$database->getSalesStages();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if($dpt['percentage'] ==$leadData['salesStage']){ ?>
                                             <option value="<?php echo $dpt['percentage'];?>" <?php echo "selected";?>><?php echo $dpt['stage'];?></option>
                                            <?php }else{ ?>
                                            <option value="<?php echo $dpt['percentage'];?>"><?php echo $dpt['stage'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select>   
                                       
                                    </div>



    <script type="text/javascript">
      $(".chosen").chosen();
</script>


 


                                     <label class="col-sm-1 control-label">LeadSource</label>
                                   <div class="col-sm-2">
                                    <select class="chosen form-control m-b" name="txtleadSource">
                                         <?php 
                                        $dpts = (array)$database->getLeadSource();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if($dpt['source'] ==$leadData['leadSource']){ ?>
                                             <option <?php echo "selected";?>><?php echo $dpt['source'];?></option>
                                            <?php }else{ ?>
                                            <option><?php echo $dpt['source'];?></option>
                                        <?php }}?>
                                        </select>
                                       
                                    </div>


    <script type="text/javascript">
      $(".chosen").chosen();
</script>

                                     
                                </div>

 <div class="form-group">
                                <label class="col-sm-2 control-label">Company Name</label>
                                   <div class="col-sm-10">
                                        <input name="txtCompany" value="<?php echo $leadData['companyName'];?>" type="text" placeholder="Enter company Name" required class="form-control required">
                                       
                                    </div>
                                    
                                </div>
<div class="form-group">
                                <label class="col-sm-2 control-label">Country</label>
                                   <div class="col-sm-2">
                                       <select class="chosen form-control m-b" name="txtCountry">
                                     <?php 
                                        $dpts = (array)$database->getAllCountries();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if($dpt['name'] =='Nigeria'){ ?>
                                             <option <?php echo "selected";?>><?php echo $dpt['name'];?></option>
                                            <?php }else{ ?>
                                            <option><?php echo $dpt['name'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select>    
                                    </div>


    <script type="text/javascript">
      $(".chosen").chosen();
</script>
                                     <label class="col-sm-1 control-label">State</label>
                                   <div class="col-sm-3">
                                   
                                       <select class="chosen form-control m-b" id="parent" name="txtState" onChange="LoadChild();" required data-validation-required-message="State is required">
                                        <option value="" disabled selected hidden>- select -</option>
                                        <script type="text/javascript">
                                            for(var i = 0 ; i < parent.length ; i ++){
                                              if(parent[i][0] == <?php echo $leadData['stateID'];?>){
                                                document.write('<option value="'+parent[i][0]+'" selected>'+parent[i][1]+'</option>');

                                                continue;
                                              }
                                                document.write('<option value="'+parent[i][0]+'">'+parent[i][1]+'</option>');

                                              }
                                          
                                        </script>
                                        
                                    </select>

                                        
                                    </div>


    <script type="text/javascript">
      $(".chosen").chosen();
</script>
                                    <label class="col-sm-1 control-label">Area</label>
                                   <div class="col-sm-3">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="gchild">

                                     
                                           <option value="<?php echo $leadData['areaID'] ?>"><?php echo $leadData['areaname'] ?></option>
                                      

                                    </select>
                                                                                
                                    </div>

<!-- 
    <script type="text/javascript">
      $(".chosen").chosen();
</script> -->
                                </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Address</label>
                                   <div class="col-sm-10">
                                        <input name="txtAdd" value="<?php echo $leadData['address'];?>" type="text" class="form-control required" required placeholder="Enter company address with area. Eg: 14, shogunle street, oshodi">
                                       
                                    </div>
                                </div>
                                
                            <div class="hr-line-dashed"></div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">Contact Person</label>
                                    <div class="col-sm-10">
                                      <input type="text" value="<?php echo $leadData['fullname'];?>" 
                                        name="txtFname" placeholder="Enter contact person firstname"
                                       required class="form-control">
                                    </div>

                                     
                                </div>
                                
                                <div class="form-group">
                                <label class="col-sm-2 control-label">Phone No.</label>
                                   <div class="col-sm-4">
                                        <input type="text" value="<?php echo $leadData['phoneNo'];?>" name="txtPhone" class="form-control" placeholder="Enter contact person Phone number" onKeyPress="return isNumberKey(event)" maxlength="11"  required>
                                    </div>
                                    <label class="col-sm-2 control-label">Email Address</label>
                                   <div class="col-sm-4">
                                        <input type="email" id="txtEmail" value="<?php echo $leadData['email'];?>" name="txtEmail" placeholder="Enter contact person email address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                 <label class="col-sm-2 control-label">Designation</label>
                                   <div class="col-sm-4">
                                        <input name="txtDesignate" value="<?php echo $leadData['designation'];?>" type="text" class="form-control" placeholder="Enter contact person Designation">
                                       
                                    </div>
                                    </div>

                                
                             <div class="hr-line-dashed"></div>

                            
                          

                                  <div class="form-group" id="data_2">
                                <label class="col-sm-2 control-label">Revisit Date</label>
                                   <div class="col-sm-4">
                                              <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input name="txtRDate" type="datetime-local" class="form-control" value="<?php echo $leadData['rDate'];?>">
                                                 </div> 
                                       
                                    </div>
                                     <label class="col-sm-2 control-label">Expected Close Date</label>
                                   <div class="col-sm-4">
                                            <div class="input-group date">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input name="txtECDate" type="text" class="form-control" value="<?php echo $leadData['ecDate'];?>" readonly>
                                            </div>
                                       
                                    </div>
                                </div>                             
                          
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Description</label>
                                   <div class="col-sm-10">
                                   <textarea class="form-control" name="txtDescription" placeholder="Describe this lead"><?php echo $leadData['description'];?></textarea>
                                    </div>
                                    
                                </div>

              <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                       <button name="btnUpdateLead" class="btn btn-info col-lg-12" type="submit">
                                         <i class="fa fa-user"></i>&nbsp;UPDATE LEAD INFORMATION</button>
                           
               </div>
                                </div>
                                </form>
                                </div>
                                </div>
                            </div>
                            


                    </div>

  </div>
<script type="text/javascript">
        $(document).ready( function() {
            
            $('.delete_product').click( function() {   
                var id = $(this).attr("id");
         
                if(confirm("Are you sure you want to delete this Product?")){
                    $.ajax({
                        type: "POST",
                        url: "<?php echo $host;?>lead/delete-lead-product.php",
                        data: ({id: id}),
                        cache: false,
                        success: function(html){
                          $("#myDiv").fadeTo(5000,1).fadeOut(3000);

                            $(".del"+id).fadeOut('slow'); 
                        } 
                    }); 
                }else{
                    return false;}
            });       
        });
    </script>
  <script>
  $("#myDiv").fadeTo(5000,1).fadeOut(3000);
  $("#myDiv2").fadeTo(5000,1).fadeOut(400);

    $(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
           $(wrapper).append('<div class="form-group"><label class="col-sm-2 control-label">Products :</label>'+
            '<div class="col-sm-3"><select class="form-control m-b" id="field_'+ x +'" name="txtProduct[]"><?php echo  $productsName;?> </select></div>'+
            '<label class="col-sm-1 control-label">Qty</label>'+
            '<div class="col-sm-1"><input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" id="field_'+ x +'" name="txtProductQty[]" class="form-control required" value="1" /></div>'+
            '<label class="col-sm-1 control-label">Amount</label>'+
            '<div class="col-sm-2"><input type="text"  onKeyPress="return isNumberKey(event)" onkeyup = "javascript:this.value=Comma'+'(this.value);" placeholder="AMOUNT" id="field_'+ x +'" value="0" name="txtProductAmount[]" class="form-control required" /></div>'+
            '<a href="#" class="remove_field"><label class="col-sm-1 control-label">Remove</label></a></div>'); //add input box

        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});

</script>
  
  <?php include("../includes/js.php");?>
  <script type="text/javascript">
     $('#trucated').inputmask("numeric", {
    radixPoint: ".",
    groupSeparator: ",",
    digits: 2,
    autoGroup: true,
    prefix: 'N', //No Space, this will truncate the first character
    rightAlign: false,
   oncleared: function(){self.Value('');}
   });
    
  </script>
