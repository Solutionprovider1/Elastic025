<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
   if($myData['AccessLevel'] < 5){
        $database->redirect_to($host);
   }
?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
</head>

<?php include("../includes/header.php");?>



<?php $myleads = (array)$database->getAllLeads();?>
<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>All Leads</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>

                        <li class="active">
                            <strong><?php echo sizeof($myleads);?> Registered Leads</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>

 <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Dear <?php echo ucwords(strtolower($myData['fullname'])) ;?>, this is the list of all the leads. Make the best out of it</h5>
                        <div class="ibox-tools">
                        <select onChange="if(this.value != '0'){window.location.href=this.value}">
                        <option value="0">--select--</option>
                            <option value="<?php echo $host;?>view-all-leads/1">All Leads</option>
                            <!--<option value="<?php echo $host;?>view-my-lead/2">All Suspects</option>
                            <option value="<?php echo $host;?>view-my-lead/3">All Prospects</option>
                             <option value="<?php echo $host;?>view-my-lead/4">All Dead Leads</option>  -->
                              <option value="<?php echo $host;?>view-all-leads/5">All Orders Collected</option>
                        </select>
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                            <li>Company Name <input type="checkbox" checked="" id="myCheck1"></li>
                            <li><a class="toggle-vis" data-column="1">Contact person</a></li>
                            <li><a class="toggle-vis" data-column="2">Phone No.</a></li>
                            <li><a class="toggle-vis" data-column="3">Email</a></li>
                            <li><a class="toggle-vis" data-column="4">Quote Amount</a></li>
                            <li><a class="toggle-vis" data-column="5">Exp. Close Date</a></li>
                            <li><a class="toggle-vis" data-column="6">Revist Date</a></li>
                            <li><a class="toggle-vis" data-column="7">Sales Stage</a></li>

                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">

                        <div class="table-responsive">


                    <table id="myExample" style="font-size: 12px;" class="table table-striped table-bordered table-hover dataTables-example" cellspacing="0" width="100%">
               <?php if(isset($_GET['id']) && $_GET['id'] == 5){?>

               <thead>
                     <th data-toggle="true">Lead</th>
                    <th>Ticket</th>
                    <th>Amount</th>
                    <th data-hide="all">Items</th>
                    <th data-hide="all">Completed</th>
                    <th>Date</th>
                    <th>Order</th>
             </thead>

             <tfoot>
                    <th data-toggle="true">Lead</th>
                    <th>Ticket</th>
                    <th>Amount</th>
                    <th data-hide="all">Items</th>
                    <th data-hide="all">Qty</th>
                    <th>Date</th>
                    <th>Order</th>

            </tfoot>

        <tbody>
          <?php
                                    $orders = (array)$database->getTeamAllOrderCollected();
                                    foreach ($orders as $order) {


                                ?>
                                <tr>
                                    <td><?php echo $order['companyName'];?></td>
                                    <td><?php echo $order['ticketNo'];?></td>
                                    <td><?php echo $database->convertToMoney($order['Amount']);?></td>
                                    <td><?php
                                    $dQty = 0;

                                $myBills = (array)$database->getLeadProductOrderOnLeadDemand($order['leadID'],$order['ticketID']);
                                foreach ($myBills as $myBill) {
                                    $dQty = $myBill['qty'];
                                         echo $myBill['productName']; ?>&nbsp;, <?php }?></td>
                                    <td><?php echo $dQty;?></td>

                                    <td><?php echo $order['ocYear']."-".$order['ocMonth']."-".$order['ocDay'];?></td>
                                    <td><a href="<?php echo $host;?>user-profile/<?php echo $order['assigned'];?>"><?php echo $order['myadmin'];?></a></td>
                                </tr>

                                <?php }?>

                                </tbody>


               <?php }else{?>
        <thead>
           <th>Company Name</th>
           <th>Area</th>
                        <th>Contact Person</th>
                        <th>Phone No.</th>
                        <th>Email</th>
                        <th>Sales Stage</th>
                        <th>Assigned</th>
                        <th>Quote Amount</th>
                        <th>Exp. Close Date</th>
                        <th>Revist Date</th>


        </thead>
        <tfoot>
            <th>Company Name</th>
            <th width="3%">Area</th>
                        <th>Contact Person</th>
                        <th>Phone No.</th>
                        <th>Email</th>
                        <th>Sales Stage</th>
                        <th>Assigned</th>
                        <th>Quote Amount</th>
                        <th>Exp. Close Date</th>
                        <th>Revist Date</th>


        </tfoot>

        <tbody>
             <?php
                        foreach ((array)$myleads as $leads) {


                    ?>

                    <tr class="gradeX">
                        <td><a href="<?php echo $host;?>lead-profile/<?php echo $leads['id'];?>"><?php echo $leads['companyName'];?></a></td>
                        <td><?php echo $leads['areaname'];?>, <?php echo ucfirst(strtolower($leads['state']));?></td>
                        <td><?php echo $leads['fullname'];?></td>
                        <td><?php echo $leads['phoneNo'];?></td>
                        <td><?php echo $leads['email'];?></td>
                        <td><?php echo $database->getSalesStage($leads['salesStage']);?>-<?php echo $leads['salesStage']."%";?></td>
                        <td><?php echo $leads['admin'];?> </td>
                        <td><?php echo $database->convertToMoney($database->getLeadQuoteAmount($leads['id']));?></td>
                       <td><?php echo $leads['ecDate'];?></td>
                        <td><?php echo $leads['rDate'];?></td>



                        </tr>



                    <?php }?>
                   </tbody>
                   <?php }?>
    </table>
                 </div>

                    </div>
                </div>
            </div>
            </div>
        </div>
   <!-- Mainly scripts -->



  </div>

   <script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo $host;?>js/bootstrap.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <script src="<?php echo $host;?>js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo $host;?>js/inspinia.js"></script>
    <script src="<?php echo $host;?>js/plugins/pace/pace.min.js"></script>





    <!-- Peity demo data -->


  <script>
        $(document).ready(function(){
            $('.dataTables-example').DataTable({
                pageLength: 100,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'Leads-Information'},
                    {extend: 'pdf', title: 'Leads-Information'},

                    {extend: 'print',
                     customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');
                            $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                    }
                    }
                ]

            });
        });

    $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#myExample tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" size="10" placeholder="'+title+'" />' );
    } );

    // DataTable
    var table = $('#myExample').DataTable();
    // table.colReorder: { realtime: false }

// table.colReorder: true;

    // Apply the search
    table.columns().every( function () {
        var that = this;

        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );

    //hide columns
   // table.column(0).visible(false);

   $('#myCheck1').change(function() {
      table.columns(0).visible($(this).is(':checked'))
    });


    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );

} );


    </script>