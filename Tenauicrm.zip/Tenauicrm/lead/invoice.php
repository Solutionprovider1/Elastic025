
<?php
  include("../data/DBConfig.php");
  //include_once("../data/sessioncheck.php");
//getLeadID=$1&getDemandID=$2&vat=$3&sof=$4
$getLeadID ="";
$getDemandID = "";
$vat = 0;
$sof = 1;
if(isset($_GET['getLeadID'])){$getLeadID = $_GET['getLeadID'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['getDemandID'])){$getDemandID = $_GET['getDemandID'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['vat'])){$vat = $_GET['vat'];}
if(isset($_GET['sof'])){$sof = $_GET['sof'];}

$leadData = $database->getLeadData($getLeadID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}
$salesorder = (array)$database->getLeadProductOrderOnLeadDemand($leadData['id'],$getDemandID);


?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tenaui + | We speak by Images</title>

    <link href="<?php echo $host;?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo $host;?>css/animate.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/style.css" rel="stylesheet">

</head>

<body class="white-bg">
<a id="printpagebutton2" href="<?php echo $host;?>ticket/<?php echo $salesorder[0]['ticketNo'];?>/<?php echo $vat;?>" class="btn btn-success buttonshow">Convert to PDF </a> 


                                <input id="printpagebutton" type="button" value="Print this page" class="btn btn-success buttonshow" onclick="printpage()"/>
                <div class="wrapper wrapper-content p-xl">
                    <div class="ibox-content p-xl">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h5>From:</h5>
                                    <address>
                                    &nbsp; &nbsp; &nbsp;
                                    <img src="<?php echo $host;?>img/tenaui-logo.jpg" width="100" height="100"><br/>
                                        <strong>Tenaui Africa Limited.</strong><br>
                                        51, Allen Avenue, Ikeja<br>
                                       Lagos, Nigeria<br>
                                        <abbr title="Phone">P:</abbr> (234) 09072574405, 08023553203<br/>
                                        <span><strong>Invoice Date:</strong><?php if($sof == 1){ echo $salesorder[0]['orderCollectedDate'];}else{echo date("d-M-Y");} ?></span><br/>
                                       <strong> Prepared by: <?php echo $leadData['admin'];?></strong><br/>
                                    </address>
                                </div>

                                <div class="col-sm-6 text-right">
                                    <h4><?php if($sof == 1){ echo 'SOF';}else{echo 'PFI';} ?> No.</h4>
                                    <h4 class="text-navy"><?php echo $salesorder[0]['ticketNo'];?></h4>
                                    <span>To:</span>
                                    <address>
                                        <strong>
                                        <?php  
                                                $comp = strtoupper($leadData['companyName']);
                                                echo wordwrap($comp, 50, "<br />\n");
                                        ?>
                                            
                                        </strong><br>
                                        <?php 
                                        $address = $leadData['address'].", ". $leadData['areaname'];
                                        echo wordwrap($address, 50, "<br />\n");
                                        ?><br>
                                        <?php echo $leadData['lga'];?> L.G.A<br/>
                                        <?php echo $leadData['state'];?>, <?php echo $leadData['country'];?><br>
                                        <abbr title="Phone">P:</abbr> <?php echo $leadData['phoneNo'];?><br/>
<strong>SALES TYPE :</strong> <?php echo $salesorder[0]['salestype'];?><br/>
<strong>PROMO CODE :</strong><?php echo $salesorder[0]['promocode'];?><br/>
<strong>PAYMENT MODE :</strong><?php echo $salesorder[0]['paymentmode'];?><br/>
<strong>DELIVERY DATE :</strong><?php echo $salesorder[0]['deliveryDay'];?>
                                    </address>
                                    
                                </div>


                                <div class="col-sm-12">
                                        <table align="center" width="80%" >
                                        <tr>
                                       
                                            <td> <span><strong>Contact Person:</strong>&nbsp;<?php echo $leadData['fullname'];?></span></td>
                                             <td><span><strong>Contact Phone:</strong>&nbsp;<?php echo $leadData['phoneNo'];?></span></td>
                                              <td><span><strong>Contact Email:</strong>&nbsp; <?php echo $leadData['email'];?></span></td>
                                        </tr>
                                    </table>

                                </div>
                            </div>

                            <div class="table-responsive m-t">
                                <table class="table invoice-table">
                                    <thead>
                                
                                       <tr>
                                       <th style="width:10px; ">S/N</th>
                                        <th>Item List</th>
                                        <th>Code</th>
                                        <th>Qty</th>
                                        <th>Unit Price</th>
                                        
                                        <th>Total Price</th>
                                   
                                    </tr>
                                    </thead>
                                    <tbody>
                                      <?php 
                                        $n = 1;
                                        $amounted = 0;
                                        
                                   
                                        foreach ($salesorder as $order) {
                                          

                                    ?>
                                   <tr>
                                   <td><?php echo $n;?>.</td>
                                        <td><div><strong><?php echo $order['productName'];?><?php if($order['ProductType']>1){echo " - ".$order['color'];}?></strong></div>
                                          <!--  <small>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</small>--></td>
                                          <td><?php echo $order['Code'];?></td>
                                        <td><?php echo $order['qty'];?></td>
                                        <td>
                                        <?php echo $database->convertToMoney($order['Amount']);?>
                                       </td>
                                        
                                        <td><?php 
                                                $amount_ = $order['qty'] * $order['Amount'];
                                        echo $database->convertToMoney($amount_);?></td>
                                    </tr>
                                    <?php $n++; $amounted += $amount_;}?>

                                    </tbody>
                                </table>
                            </div><!-- /table-responsive -->

                            <table class="table invoice-total">
                                <tbody>
                                <tr>
                                    <td><strong>Sub Total :</strong></td>
                                    <td><?php
                                    //getLeadID=$1&getDemandID=$2&vat=$3&sof=$4
                                    $sub_total =$amounted;

                                     echo  $database->convertToMoney($sub_total);?></td>
                                </tr>
                                <tr>
                                    <td><strong><?php if($vat == 1){echo "VAT (5%)";}else{ echo "NO VAT";}?> :</strong></td>
                                    <td><?php
                                    $vat_ = 0; 
                                    if($vat ==1){
                                            $vat_ = 0.05 * $sub_total;
                                        }
                                    echo $database->convertToMoney($vat_);?></td>
                                </tr>
                                <tr>
                                    <td><strong>GRAND TOTAL :</strong></td>
                                    <td><?php 
                                    $Total = $sub_total + $vat_;

                                   echo $database->convertToMoney($Total);?></td>
                                </tr>
                                </tbody>
                            </table>
                            <div class="well m-t"><p style="text-align: center;"><strong>Amount in words:</strong>
                               <?php echo ucwords(strtolower($database->convert_number_to_words($Total)));?> Naira Only</p>
                            </div>

                            <?php if($sof == 1){?>
                                    <div class="well m-t">
<table width="100%" border="3">
                                            <tr>
                                                <th colspan="2">SPECIAL NOTES AND TERMS OF SALES</th>
                                            </tr>
                                            <tr>
                                                <th>DELIVERY TERMS</th>
                                                <td>All price are valid for 4 weeks and subject to change without prior notice</td>
                                            </tr>
                                             
                                        </table>
                                        <ul style="color: black; padding-left: 0px; border: 2px solid black; list-style: none;">
                                            <li style="font-size: 14px;border-bottom:1px solid black;border-top:0px;">Direct Sales </li>
                                        <li style="font-size: 14px;border-bottom:1px solid black;">Payment After Delivery 2days</li>
                                             <li style="font-size: 14px;border-bottom:1px solid black;border-top:0px;">Payment After installation 4days</li>
                             <li style="font-size: 14px;border-bottom:1px solid black;border-top:0px;">Payment After installation & training 6days</li>
                                              
                                        </ul>
                                        <br/><br/>



                                   <!--  <div class="col-md-12">
                                    <div class="col-xs-4">
                                    <strong>BUSINESS CONTROLLER:</strong>
                                      </div>
                                       <div class="col-xs-4">
                                    <strong>BUSINESS HEAD:</strong>
                                      </div>
                                       <div class="col-xs-4">
                                    <strong>MANAGEMENT:</strong>
                                      </div>
</div> -->
                                       
                                             
                                    </div>
                            
                            <?php }else{?>
                                
                                        <table width="100%" border="3">
                                            <tr>
                                                <th colspan="2">SPECIAL NOTES AND TERMS OF SALES</th>
                                            </tr>
                                            <tr>
                                                <th>VALIDITY</th>
                                                <td>All price are valid for 4 weeks and subject to change without prior notice</td>
                                            </tr>
                                             <tr>
                                                <th>PAYMENT TERMS</th>
                                                <td>100 % advance.</td>
                                            </tr>
                                            <tr>
                                                <th>DELIVERY TERMS</th>
                                                <td>Delivery prior to confirmation of payment</td>
                                            </tr>
                                            <tr>
                                                <th>SALES TAX</th>
                                                <td>Total Amount Inclusive V.A.T</td>
                                            </tr>
                                            <tr>
                                                <th>BANK ACCOUNT</th>
                                                <td>
 <table width="100%" border="1">
                                                <tr>
                                                        <th width="30%">ACCOUNT NAME</th>
                                                        <th  width="40%">DIAMOND BANK</th>
                                                        
                                                       
                                                        <th  width="30%">GTBANK</th>
                                                        
                                                        
                                                  </tr> 

                                                  <tr>
                                                    <td>TENAUI AFRICA LTD.</td>
                                                      <td>0040386839</td>
                                                     
                                                     
                                                      <td>0139423438</td>
                                                     
                                                            
                                                  </tr>

                                            </table>




                                                </td>
                                            </tr>
                                           <tr>
                                                <th colspan="2"> I declare that the information mentioned above is true and correct to the best of my knowledge.</th>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><p style="text-align: center;">Any information regarding this pro forma invoice please contact <b><?php echo $leadData['admin'];?> on <?php echo $leadData['adminPhone'];?></b></p></td>
                                            </tr>
                           <?php } ?>
                                   

                                </table>
                               
                        </div>


    </div>


    <!-- Mainly scripts -->
    <script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo $host;?>js/bootstrap.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo $host;?>js/inspinia.js"></script>

    <script type="text/javascript">
       //window.print();
    </script>
<script type="text/javascript">
    function printpage() {
        //Get the print button and put it into a variable
        var printButton = document.getElementById("printpagebutton");
        //Set the print button visibility to 'hidden' 
        printButton.style.visibility = 'hidden';
        //Print the page content
        var printButton2 = document.getElementById("printpagebutton2");
        printButton2.style.visibility = 'hidden';
        window.print()
        //Set the print button to 'visible' again 
        //[Delete this line if you want it to stay hidden after printing]
        printButton.style.visibility = 'visible';
        printButton2.style.visibility = 'visible';
    }
</script>

</body>

</html>
