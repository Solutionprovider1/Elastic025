<?php
    include("data/DBConfig.php");
 //   include_once("data/sessioncheck.php");
 $database->upDateLeadDemandAdminID();
?>