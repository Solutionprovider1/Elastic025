
<?php

// require_once "Mail.php"; // PEAR Mail package
// require_once ('Mail/mime.php'); // PEAR Mail_Mime packge

 class MySQLDatabase{

   private $db;


   //public $host = "http://localhost/TenauiCRM/";
   public $companyEmailImage = "";
   public $userRegisterImage = "";

   public $defaultImage = "";
    function __construct($DB_con){
         $this->db = $DB_con;
    }
 

    public function getException($errorMessage){
        //$_SERVER['REMOTE_ADDR'],date("d-m-Y h:i:s A"),time()
        return $this->showMsg("Error!","A system error has occured, we will fix it<br/>".$errorMessage, 1);

    }

    function test_input($data){
          // $data = trim($data);
          // $data = stripslashes($data);
          // $data = htmlspecialchars($data);
          return $data;
    }

    function returnSalesStageColor($stage){
        if($stage <30){
            return "danger";
        }else if($stage >=30 && $stage <= 59){
            return "warning";
        }else if($stage >=60 && $stage <= 79){
            return "info";
        }else if($stage >=80 && $stage <=90){
            return "primary";
        }else{
            return "success";
        }

    }

    function calculatePercentage($up, $down){
        if($down >0){
          return round(($up/$down) * 100,2);

        }else{
            return 0;
        }
    }

    public function ValidateCompany($companyName){
        $sql = "select * from leads where companyName = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$companyName);
        $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return true;
            }else{
                    return false;
            }


    }



    public function ValidateCompanyAgainst($companyName,$companyID){
        $sql = "select * from leads where companyName = ? and id != ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$companyName);
        $handle->bindValue(2,$companyID);
        $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return true;
            }else{
                    return false;
            }


    }

    function getAllDeadLeads(){
        $myArray = array();
        $sql = "select ld.*, st.fullname as admin, ar.areaname, sta.state from leads ld join staff st on st.id = ld.assigned left join area_location ar on ld.areaID = ar.id left join states sta on ld.stateID =sta.id where salesStage = 0 order by ld.id desc";
        $handle = $this->db->prepare($sql);
        $handle->execute();

        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }


    function addAnEvent($user_id,$eventTitle,$startDate,$startTime,$endDate="",$endTime=""){
        $sql = "insert into `events` (user_id,`event`,startDate,startTime,endDate,endTime) values (?,?,?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->bindValue(2,$eventTitle);
        $handle->bindValue(3,$startDate);
        $handle->bindValue(4,$startTime);
        $handle->bindValue(5,$endDate);
        $handle->bindValue(6,$endTime);
        $handle->execute();

    }

    function getAllMyEvents($id){
        $myArray = array();
        $sql = "select * from `events` where user_id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

    function getAllMyEventsFromTo($id,$fromDate,$toDate){
        $myArray = array();
        $sql = "select * from `events` where user_id = ? and startDate between '$fromDate' and '$toDate'";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

    function getAllEvents(){
        $myArray = array();
        $sql = "select * from `events`";
        $handle = $this->db->prepare($sql);
        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }


    function updateDateStamp($id,$date){
        $sql = "update `leads` set rDateStamp = ? where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$date);
        $handle->bindValue(2,$id);
        $handle->execute();
    }

    function getLeadRevisitDates($id = ""){
        $myArray = array();
        $handle = "";
        $sql = "";
        if($id == ""){
            $sql = "select * from `leads` where rDate != ''";
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$id);

        }else{
            $sql = "select * from `leads` where assigned = ? and rDate != ''";
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$id);
        }

        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }

    }

    function getLeadRevisitDatesRange($id = "",$dateFrom, $dateTo){
        $myArray = array();
        $handle = "";
        $sql = "";
        if($id == ""){
            $sql = "select * from `leads` where rDate != ''";
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$id);

        }else{
            $sql = "select * from `leads` where user_id = ? and rDate != ''";
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$id);
        }

        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }

    }

    function getAllLeads(){
        $myArray = array();
        $sql = "select ld.*, st.fullname as admin, ar.areaname, sta.state from leads ld join staff st on st.id = ld.assigned left join area_location ar on ld.areaID = ar.id left join states sta on ld.stateID =sta.id where salesStage > 1 order by ld.id desc";
        $handle = $this->db->prepare($sql);
        $handle->execute();

        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

    function getSalesStage($percentage){
        $sql = "select * from salesstage where percentage = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$percentage);
        $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['stage'];
            }else{
                    return 'Unknown Stage';
            }
    }

    function getMonthlyOrderCollected($user_id,$month,$year){
         $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where l.assigned = ?
        and ld.orderCollect = 1
        and ld.ocMonth = ?
        and ocYear = ? GROUP BY ld.ticketNo ";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id, PDO::PARAM_INT);
        $handle->bindValue(2,$month,PDO::PARAM_INT);
        $handle->bindValue(3,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }

    function getMonthlyMPS($user_id,$month,$year){
        $myArray = array();
        $sql = "select * from `mps_amount` where user_id = ? and ocMonth = ? and ocYear = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->bindValue(2,$month);
        $handle->bindValue(3,$year);
        $handle->execute();
        if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){

                 $myArray[] = $row;
            }
            return $myArray;
        }else{
            return null;
        }
    }



function getMyAllOrderCollected($user_id){
         $myArray = array();
        $sql = "select l.id as leadID, l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocDay, ld.orderCollectedDate, ld.ocMonth, ocYear, s.fullname as admin, ld.id as ticketID
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where l.assigned = ?
        and ld.orderCollect = 1
         GROUP BY ld.ticketNo order by ocYear desc, ocMonth desc, ocDay desc";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id, PDO::PARAM_INT);

        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }

function getTeamAllOrderCollected(){
         $myArray = array();
        $sql = "select l.id as leadID,l.assigned, l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocDay, ld.orderCollectedDate, ld.ocMonth, ocYear, s.fullname as myadmin, ld.id as ticketID
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where ld.orderCollect = 1
         GROUP BY ld.ticketNo order by ocYear desc, ocMonth desc, ocDay desc";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);


        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }





function getYearSalesRanking($id,$yr){
        $myArray = array();

        $sql = "select SUM(Amount) as myAmount from lead_product where
leadDemandID in(SELECT id FROM lead_demand ld WHERE ld.orderCollect = 1 and ld.ocYear = ? and sales_type_id = 1 and adminID = ?)";

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$yr);
       // $handle->bindValue(2,$month);
        $handle->bindValue(2,$id);
        $handle->execute();

        if($handle->rowCount()>0){
           $row = $handle->fetch(PDO::FETCH_ASSOC);
            return $row['myAmount'];
             //   $myArray[] = $row;
           // }
          //  return $myArray;

        }else{
                return null;
        }


    }

    function getMonthlySalesRanking($id,$month,$yr){
        $myArray = array();

        $sql = "select SUM(Amount) as myAmount from lead_product where
leadDemandID in(SELECT id FROM lead_demand ld WHERE ld.orderCollect = 1 and ld.ocYear = ? and ld.ocMonth = ? and sales_type_id = 1 and adminID = ?)";

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$yr);
        $handle->bindValue(2,$month);
        $handle->bindValue(3,$id);
        $handle->execute();

        if($handle->rowCount()>0){
           $row = $handle->fetch(PDO::FETCH_ASSOC);
            return $row['myAmount'];
             //   $myArray[] = $row;
           // }
          //  return $myArray;

        }else{
                return null;
        }


    }



    function getMonthlyOrderCollectedRanking2($month,$year){
        $sql = "select stf.id,stf.id as staffId, stf.fullname as admin,
(select SUM(lp.qty * lp.Amount)
 	from lead_product lp
 	join lead_demand ld on lp.leadDemandID = ld.id
 	where ld.adminID = stf.id
 		  and ld.orderCollect = 1
          and ld.ocMonth = ?
          and ocYear = ? ) as totalAmount

    from staff stf order by totalAmount desc";
    $handle = $this->db->prepare($sql);
        //$handle->bindValue(1,$user_id, PDO::PARAM_INT);
        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }

    function getMonthlyOrderCollectedRanking($month,$year){
        $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id

        and ld.orderCollect = 1
        and ld.ocMonth = ?
        and ocYear = ? GROUP BY l.assigned order by SUM(lp.qty * lp.Amount) desc";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        //$handle->bindValue(1,$user_id, PDO::PARAM_INT);
        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }

     function getYearlyOrderCollectedRanking($year){
        $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id

        and ld.orderCollect = 1


        and ocYear = ? GROUP BY l.assigned order by SUM(lp.qty * lp.Amount) desc";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        //$handle->bindValue(1,$user_id, PDO::PARAM_INT);
        //$handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(1,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }


    function getAllOrderCollectedRanking(){
        $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id

        and ld.orderCollect = 1

        GROUP BY l.assigned order by SUM(lp.qty * lp.Amount) desc";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        //$handle->bindValue(1,$user_id, PDO::PARAM_INT);
        //$handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(1,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }

    function updateOrderCollected($id,$leadID,$oDate,$ocDay,$ocMonth,$ocYear,$promocode,$paymode = "",$deliveryDay){
        $sql = "update lead_demand set orderCollect = 1, orderCollectedDate = ?, ocDay = ?, ocMonth = ?, ocYear = ?, promocode = ?,paymentmode = ?, deliveryDay = ? where id = ? and leadID = ?";

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$oDate);
        $handle->bindValue(2,$ocDay,PDO::PARAM_INT);
        $handle->bindValue(3,$ocMonth,PDO::PARAM_INT);
        $handle->bindValue(4,$ocYear,PDO::PARAM_INT);
        $handle->bindValue(5, $promocode);
        $handle->bindValue(6, $paymode);
         $handle->bindValue(7, $deliveryDay);
        
        
        $handle->bindValue(8,$id,PDO::PARAM_INT);
        $handle->bindValue(9,$leadID,PDO::PARAM_INT);
        $handle->execute();

        $sql = "update leads set salesStage = 100 where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->execute();
        $leadCompanyName = $this->getLeadData($leadID)['companyName'];
        $msg = " successfully collected an order from ".$leadCompanyName;
        $this->createActivityNotifications($msg);
         $user_id  = $_SESSION['user_id'];

            $person = $this->getMyUserInformation($user_id)['fullname'];
            $subj = "Order collected";
            $message = $person.$msg;
           $this->sendEmail("crm_solutions@tenaui.com",$subj,$message, $message, "");

    }
    function getTeamMonthlyOrderCollected($month,$year){
         $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where ld.orderCollect = 1
        and ld.ocMonth = ?
        and ocYear = ? GROUP BY ld.ticketNo ";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }
function getUserSumMonthlySales($id,$month,$year){
        // $myArray = array();
        $sql = "select SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where ld.orderCollect = 1
        and ld.ocMonth = ?
        and ocYear = ? and l.assigned = ?";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->bindValue(3,$id,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                return $row['Amount'];
            }


        }else{
                return null;
        }

    }

    function getTeamMPSMonthlySales($month,$year){
        $sql = "select SUM(amount) as Amount from mps_amount where ocMonth =? and ocYear = ?";
         $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                return $row['Amount'];
            }


        }else{
                return null;
        }

    }

    function getTeamSumMonthlySales($month,$year){
        // $myArray = array();
        $sql = "select SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where ld.orderCollect = 1
        and ld.ocMonth = ?
        and ocYear = ?";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                return $row['Amount'];
            }


        }else{
                return null;
        }

    }


    function getYearlyOrderCollected($user_id,$year){
         $myArray = array();
        $sql = "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        where l.assigned = ?
        and ld.orderCollect = 1
        and ocYear = ? GROUP BY ld.ticketNo ";
// echo $user_id." m: ".$month." Y: ".$year;

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id, PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }

    }
    function getYearlyMPS($user_id,$year){
        $myArray = array();
        $sql = "select * from `mps_amount` where user_id = ? and ocYear = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->bindValue(2,$year);
        $handle->execute();
        if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){

                 $myArray[] = $row;
            }
            return $myArray;
        }else{
            return null;
        }
    }

    function getAllMPS($user_id){
        $myArray = array();
        $sql = "select * from `mps_amount` where user_id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->execute();
        if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){

                 $myArray[] = $row;
            }
            return $myArray;
        }else{
            return null;
        }
    }

    function getRevisitDate($from, $to){
        $myArray = array();
        $sql = "select ld.*, st.fullname as admin, ar.areaname, sta.state from leads ld join staff st on st.id = ld.assigned left join area_location ar on ld.areaID = ar.id left join states sta on ld.stateID =sta.id where salesStage > 1 and (rDateStamp between ? and ?)  order by rDateStamp asc";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$from);
        $handle->bindValue(2,$to);
        $handle->execute();

        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                $myArray[] = $row;
            }
            return $myArray;
        }
    }


    public function getMyLeads($id,$getID){
        $sql = "";
         if($getID == 1){$sql = "select * from leads where assigned = ? order by id desc";}
         else if($getID == 2){$sql = "select * from leads where assigned = ? and salesStage < 30 and salesStage >0 order by id desc";}
         else if($getID == 3){$sql = "select * from leads where assigned = ? and salesStage > 29 and salesStage < 100 order by id desc";}
         else if($getID == 4){$sql = "select * from leads where assigned = ? and salesStage = 0 order by id desc";}
         else if($getID == 5){$sql = "select * from leads where assigned = ? and salesStage >=100 order by id desc";}

        $myArray = array();
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

            }else{
                    return null;
            }
    }

    function deleteLeadProduct($id){
        $sql = "delete from lead_product where id =?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        $message = "";
        $this->createActivityNotifications($message);
    }

    function getLeadAllProductOrder($id){
        $myArray = array();
        $sql = "SELECT lp.id,lp.productID, p.productName, p.Code, p.color, p.ProductType, lp.qty, lp.Amount, ld.ticketNo,
                    ld.orderCollect, ld.orderCollectedDate, ld.ocDay, ld.ocMonth,ld.ocYear
                    FROM lead_product lp
                    JOIN products p ON lp.productID = p.id
                    JOIN lead_demand ld on lp.leadDemandID = ld.id
                    WHERE lp.leadID = ? ";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }

    function getLeadDemandWithTicketNo($ticketNo){
        $sql = "select * from lead_demand where ticketNo = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $ticketNo);
        $handle->execute();
        if($handle->rowCount() > 0){
            return $handle->fetch(PDO::FETCH_ASSOC);
        }

    }
     function getLeadDemandWithID($id){
        $sql = "select * from lead_demand where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $id);
        $handle->execute();
        if($handle->rowCount() > 0){
            return $handle->fetch(PDO::FETCH_ASSOC);
        }

    }

    function getLeadDemandWithIDTicket($id){
        $myArray = array();
      $sql = "select * from lead_demand where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $id);
        $handle->execute();
       
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }




    function getProductInformationWithID($id){
        $sql = "select * from products where id = ?";
         $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $id);
        $handle->execute();
        if($handle->rowCount() > 0){
            return $handle->fetch(PDO::FETCH_ASSOC);
        }

    }

    function getLeadMPSWithID($leadID,$mpsID){
        $sql = "SELECT mps.id,mps.productID, p.productName, p.Code, p.color, p.ProductType, mps.product_qty, mps.rentalCharge,
             mps.cost_mono, mps.cost_color, mps.min_vol_mono, mps.min_vol_color,mps.contract_duration,mps.billingType,ld.ticketNo,
                    ld.orderCollect, ld.orderCollectedDate, ld.ocDay, ld.ocMonth,ld.ocYear, st.salestype, st.st, ld.description, mps.accesories
                    FROM mps_info mps
                    JOIN products p ON mps.productID = p.id
                    JOIN lead_demand ld on mps.lead_demand_id = ld.id
                    JOIN sales_type st on ld.sales_type_id = st.id
                    where mps.leadID = ? and mps.id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->bindValue(2,$mpsID);
        $handle->execute();
        if($handle->rowCount()>0){
           return $handle->fetch(PDO::FETCH_ASSOC);

         }
    }

    function getLeadMPSOrderOnLeadDemand($leadID,$leadDemandID){
        $myArray = array();
            $sql = "SELECT mps.id,mps.productID, p.productName, p.Code, p.color, p.ProductType, mps.product_qty, mps.rentalCharge,
             mps.cost_mono, mps.cost_color, mps.min_vol_mono, mps.min_vol_color,mps.contract_duration,mps.billingType,ld.ticketNo,
                    ld.orderCollect, ld.orderCollectedDate, ld.ocDay, ld.ocMonth,ld.ocYear, st.salestype, st.st, ld.description, mps.accesories
                    FROM mps_info mps
                    JOIN products p ON mps.productID = p.id
                    JOIN lead_demand ld on mps.lead_demand_id = ld.id
                    JOIN sales_type st on ld.sales_type_id = st.id
                    where mps.leadID = ? and ld.id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->bindValue(2,$leadDemandID);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }


       function getLeadMPSOrderOnLeadDemandPro($leadID,$leadDemandID){
        $myArray = array();
            $sql = "SELECT mps.id,mps.productID, p.productName, p.Code, p.color, p.ProductType, mps.product_qty, mps.rentalCharge,
             mps.cost_mono, mps.cost_color, mps.min_vol_mono, mps.min_vol_color,mps.contract_duration,mps.billingType,ld.ticketNo,
                    ld.orderCollect, ld.orderCollectedDate, ld.ocDay, ld.ocMonth,ld.ocYear, st.salestype, st.st, ld.description, mps.accesories
                    FROM mps_info mps
                    JOIN products p ON mps.productID = p.id
                    JOIN lead_demand ld on mps.lead_demand_id = ld.id
                    JOIN sales_type st on ld.sales_type_id = st.id
                    where mps.leadID = ? and ld.id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->bindValue(2,$leadDemandID);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }

    function getBillingType($id=""){
        $myArray = array();
        $sql = "";
        if($id==""){
            $sql = "select * from billingtype";
        }else{
            $sql = "select * from billingtype where `value` = {$id}";
        }
        $handle = $this->db->prepare($sql);
        $handle->execute();
        if($handle->rowCount()>0){
            if($id!= ""){
                return $handle->fetch(PDO::FETCH_ASSOC);
            }else{
                while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $myArray[] = $row;
                }
                return $myArray;
             }

         }

    }


    function getMPSForIndividuals($id=""){
        $myArray = array();
        $sql = "select * from mps_amount where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() > 0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)) {
                # code...
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

function getLeadProductCategoryRating(){
        $myArray = array();
            $sql = "select SUM(lp.qty) as myCount, lp.productID, p.productName,p.productCategoryID,pc.category from lead_product lp
            JOIN products p ON lp.productID = p.id
            JOIN productcategory pc on p.productCategoryID = pc.id
            where p.productType = 1 and leadDemandID in
            (select id from lead_demand where orderCollect = 1)
            group by pc.id";

        $handle = $this->db->prepare($sql);
        //$handle->bindValue(1,$month);
        //$handle->bindValue(2,$year);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }


    function getLeadProductOrderOnLeadDemandProductRatingMonthly($month,$year){
        $myArray = array();
            $sql = "select SUM(qty) as myCount, productID, productName from lead_product lp
            JOIN products p ON lp.productID = p.id
            where p.productType = 1 and leadDemandID in
            (select id from lead_demand where orderCollect = 1 and ocMonth = ? and ocYear = ?)
            group by productID";

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$month);
        $handle->bindValue(2,$year);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }

    function getLeadProductOrderOnLeadDemandProductRatingYearly($year){
        $myArray = array();
            $sql = "select count(*) as myCount, productID, productName from lead_product lp
            JOIN products p ON lp.productID = p.id
            where leadDemandID in
            (select id from lead_demand where orderCollect = 1 and ocYear = ?)
            group by productID";

        $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$year);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }







    function getLeadProductOrderOnLeadDemand($leadID,$leadDemandID){
        $myArray = array();
            $sql = "SELECT lp.id,lp.productID, p.productName, p.Code, p.color, p.ProductType, lp.qty, lp.Amount, ld.ticketNo,
                    ld.orderCollect, ld.orderCollectedDate, ld.ocDay, ld.ocMonth,ld.ocYear, ld.promocode, ld.paymentmode, ld.deliveryDay, st.salestype, st.st, ld.description
                    FROM lead_product lp
                    JOIN products p ON lp.productID = p.id
                    JOIN lead_demand ld on lp.leadDemandID = ld.id
                    JOIN sales_type st on ld.sales_type_id = st.id
                    where lp.leadID = ? and ld.id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->bindValue(2,$leadDemandID);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }
         
    function getSalesType($id){
        $sql = "select * from sales_type where id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() > 0){
            return $handle->fetch(PDO::FETCH_ASSOC);
        }
    }

    function getLeadDemand($id){
        $myArray = array();
        $sql = "select * from lead_demand where leadID = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() >0){
             while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }

    }

    /*function getLeadProductOrder($id){
        $myArray = array();
        $sql = "SELECT lp.id,lp.productID, p.productName, p.Code, p.color, p.ProductType, lp.qty, lp.Amount FROM lead_product lp JOIN products p ON lp.productID = p.id where lp.leadID = ? ";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
         }

    }*/

    function getLeadData($id){
        $sql = "select ld.*,lg.lga, al.areaname, st.state, stf.id as stfID, stf.fullname as admin, stf.phoneNo as adminPhone from leads ld

                left join states st on ld.stateID = st.id
                left join area_location al on al.id = ld.areaID
                left join lga lg on al.lgaID = lg.id
                join staff stf on ld.assigned = stf.id
                 where ld.id = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount()>0){
            return  $handle->fetch(PDO::FETCH_ASSOC);
         }

    }




    public function createTicketNo(){
        $leadName = "TENAFR-";
        $leadName.= $this->generateRandomString(5);
        return $leadName;
    }

    public function enterLeadDemand($leadID,$salestypeID,$description=""){
        $sql = "insert into lead_demand (adminID,leadID,ticketNo,sales_type_id,description) values(?,?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$_SESSION['user_id']);
        $handle->bindValue(2,$leadID);
        $handle->bindValue(3, $this->createTicketNo());
        $handle->bindValue(4,$salestypeID);
        $handle->bindValue(5,$description);
        $handle->execute();
        return $this->db->lastInsertId();
    }



    public function addNewLead($name,$phone,$email,$country,$city,$address,$companyName,$designation,$rDate,$ecDate,$salesStage,$LeadSource,$assign,$description,$areaID,$product,$qty,$amount){
        $sql = "insert into leads(fullname,phoneNo,email,country,stateID,address,companyName,designation,rDate,ecDate,salesStage,leadSource,assigned,description,dateTime,timeStamp,areaID)
        values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$name);
        $handle->bindValue(2,$phone);
        $handle->bindValue(3,$email);
        $handle->bindValue(4,$country);
        $handle->bindValue(5,$city);
        $handle->bindValue(6,$address);
        $handle->bindValue(7,$companyName);
        $handle->bindValue(8,$designation);
        $handle->bindValue(9,$rDate);
        $handle->bindValue(10,$ecDate);
        $handle->bindValue(11,$salesStage);
        $handle->bindValue(12,$LeadSource);
        $handle->bindValue(13,$assign);
        $handle->bindValue(14,$description);
        $handle->bindValue(15,date("l jS \of F Y h:i:s A"));
        $handle->bindValue(16,time());
        $handle->bindValue(17,$areaID);
        $handle->execute();
        $lasID = $this->db->lastInsertId();
        $this->addLeadDemandProduct($lasID,$product,$qty,$amount);




         $message = "created a new lead";
        $this->createActivityNotifications($message);

            $user_id  = $_SESSION['user_id'];

            $person = $this->getMyUserInformation($user_id)['fullname'];
            $subj = "Created a new Lead";
            $msg = " created a new lead, ".$companyName;
            $message = $person.$msg;
            $this->sendEmail("crm_solutions@tenaui.com",$subj,$message, $message, "");






    }

    public function addLeadDemandProduct($lasID,$product,$qty,$amount){
        $leadDemandID = $this->enterLeadDemand($lasID,1,"");
        $count = count($product);
            if ($count >0 && !empty($product)) {
                    for ($i=0; $i< $count; $i++) {
                        $productID = $product[$i];
                        $qty1 = $qty[$i];
                        $amount1 = str_replace(',','',$amount[$i]);
                        $this->insertLeadProducts($lasID,$product[$i],$qty[$i],$amount1,$leadDemandID);
                    }
                }
        $message = "added a new order for a lead";
        $this->createActivityNotifications($message);
    }




    public function EditLeadProfile($name,$phone,$email,$country,$city,$address,$companyName,$designation,$rDate,$ecDate,$salesStage,$LeadSource,$user_id,$description,$lga,$id){
        $sql = "update leads set fullname = ?,phoneNo = ?,email = ?,country =?, stateID = ?, address =?,companyName = ?, designation = ?, rDate =?, ecDate= ?,salesStage = ?,leadSource = ?,description = ?,areaID =? where id = ?";

        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$name);
        $handle->bindValue(2,$phone);
        $handle->bindValue(3,$email);
        $handle->bindValue(4,$country);
        $handle->bindValue(5,$city);
        $handle->bindValue(6,$address);
        $handle->bindValue(7,$companyName);
        $handle->bindValue(8,$designation);
        $handle->bindValue(9,$rDate);
        $handle->bindValue(10,$ecDate);
        $handle->bindValue(11,$salesStage);
        $handle->bindValue(12,$LeadSource);
        $handle->bindValue(13,$description);
        $handle->bindValue(14,$lga);
        $handle->bindValue(15,$id);
        $handle->execute();
        $message = "edited ".$companyName." profile";
        $this->createActivityNotifications($message);

        $user_id  = $_SESSION['user_id'];

            $person = $this->getMyUserInformation($user_id)['fullname'];
            $subj = "Edited a lead";
            $msg = " Edited a lead, ".$companyName."";
            $message = $person.$msg;
            $this->sendEmail("crm_solutions@tenaui.com",$subj,$message, $message, "");



    }

    function convertToMoney($amount){
        return '₦'.number_format($amount,2);
    }
    function convertToMoney2($amount){
        return 'N '.number_format($amount,2);
    }

    function getLeadQuoteAmount($id){
        $handle = $this->db->prepare("select SUM(qty * Amount) as TotalSum from lead_product where leadID = ?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['TotalSum'];
         }else{
            return 0;
         }

    }
    function getUserMonthlyTarget($id,$month,$year){
        $handle = $this->db->prepare("select `amount` from monthly_target where user_id = ? and tmonth =? and tyear = ?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
        $handle->bindValue(2,$month,PDO::PARAM_INT);
        $handle->bindValue(3,$year,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['amount'];
         }else{
            return 0;
         }

    }
    function getUserAllCurrentTarget($id){
        $handle = $this->db->prepare("select SUM(`amount`) as myAmount from monthly_target where user_id = ?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);

        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['myAmount'];
         }else{
            return 0;
         }

    }
    function getUserYearlyTarget($id,$year){
        $handle = $this->db->prepare("select sum(`amount`) AS amount from monthly_target where user_id = ? and tyear = ?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
       // $handle->bindValue(2,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['amount'];
         }else{
            return 0;
         }

    }
    function getMonthlyTarget($month,$year){
        $handle = $this->db->prepare("select SUM(amount) as teamAmount from monthly_target where tmonth =? and tyear = ?");

        $handle->bindValue(1,$month,PDO::PARAM_INT);
        $handle->bindValue(2,$year,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['teamAmount'];
         }else{
            return 0;
         }

    }
    function getLeadQuoteAmountForDemand($id,$demandID){
        $handle = $this->db->prepare("select SUM(qty * Amount) as TotalSum from lead_product where leadID = ? and leadDemandID =?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
         $handle->bindValue(2,$demandID,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['TotalSum'];
         }else{
            return 0;
         }

    }


      function getLeadMpsQuoteAmountForDemand($id,$demandID){
        $handle = $this->db->prepare("select SUM(product_qty * rentalCharge) as TotalSum from mps_info where leadID = ? and lead_demand_id =?");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
         $handle->bindValue(2,$demandID,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['TotalSum'];
         }else{
            return 0;
         }

    }

     

      function getMachineQtyForMps($id,$demandID){
        $handle = $this->db->prepare("select SUM(product_qty) as TotalSum from mps_info where leadID = ? and lead_demand_id =? and rentalCharge > 0 ");
        $handle->bindValue(1,$id,PDO::PARAM_INT);
         $handle->bindValue(2, $demandID,PDO::PARAM_INT);
        $handle->execute();
        if($handle->rowCount() > 0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['TotalSum'];
         }else{
            return 0;
         }

    }



    function insertLeadProducts($leadID,$productID,$qty,$amount,$leadDemandID){
        $handle = $this->db->prepare("insert into lead_product(leadID,leadDemandID,productID,qty,`Amount`) values(?,?,?,?,?)");
        $handle->bindValue(1,$leadID,PDO::PARAM_INT);
        $handle->bindValue(2,$leadDemandID,PDO::PARAM_INT);
        $handle->bindValue(3,$productID,PDO::PARAM_INT);
        $handle->bindValue(4,$qty,PDO::PARAM_INT);
        $handle->bindValue(5,$amount,PDO::PARAM_INT);
        $handle->execute();

    }

    function getMyInbox($id){
        $myArray = array();
        $handle = $this->db->prepare("select * from private_message where reciever_id = ? and reciever_delete = 0 order by id desc");
        $handle->bindValue(1,$id);
        $handle->execute();
       if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
             return $myArray;
        }
    }

    function getUnreadMessages($id){
        $myArray = array();
        $handle = $this->db->prepare("select * from `private_message` where reciever_id = ? and reciever_delete = 0 and `read` = 0 order by id desc");
        $handle->bindValue(1,$id);
         $handle->execute();
       if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
             return $myArray;
        }
    }

    function getMyInboxDetails($id,$userID){
        //$myArray = array();
        $handle = $this->db->prepare("select * from private_message where reciever_id = ? and id = ? and
         reciever_delete = 0 order by id desc");
        $handle->bindValue(1,$userID);
        $handle->bindValue(2,$id);
        $handle->execute();
       if($handle->rowCount() > 0){
            return  $handle->fetch(PDO::FETCH_ASSOC);

        }
    }

    function getAllAdmins(){
        $myArray = array();
        $sql = "select st.*, dpd.designation from staff st join dpt_designation dpd on dpd.id = st.designationID order by fullname asc";
        $handle = $this->db->prepare($sql);
        $handle->execute();
        if($handle->rowCount() >0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

    public function sendPrivatemessage($senderName, $sender_id,$reciever_id,$msgType,$subject, $msg){
        $sql = "insert into private_message (senderName,sender_id,reciever_id,msgType,subject,message,timestamp,dateTime,date,time,ipAddress)
        values(?,?,?,?,?,?,?,?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$senderName);
        $handle->bindValue(2,$sender_id);
        $handle->bindValue(3,$reciever_id);
        $handle->bindValue(4,$msgType);
        $handle->bindValue(5,$subject);
        $handle->bindValue(6,$msg);
        $handle->bindValue(7,time());
        $handle->bindValue(8,date("l jS \of F Y h:i:s A"));
        $handle->bindValue(9,date("d-m-Y"));
        $handle->bindValue(10,date("h:i A") );
        $handle->bindValue(11, $_SERVER['REMOTE_ADDR']);
        $handle->execute();
        $user_id  = $reciever_id;
            $person = $this->getMyUserInformation($user_id)['fullname'];
            $email_ = $this->getMyUserInformation($user_id)['email'];
            $subj = "Elastic24: ".$subject;
            $message = $senderName." just sent you a message on Elastic24.com<br/> ".$msg;
            $message2 = $senderName." just sent ".$person." a message Elastic24.com<br/> ".$msg;
            $this->sendEmail("crm_solutions@tenaui.com",$subj,$message2, $message2, "");
            $this->sendEmail($email_,$subj,$message, $message, "");

    }


    function getMyUnreadInbox($id){
        $myArray = array();
        $handle = $this->db->prepare("select * from private_message where reciever_id = ? and reciever_delete = 0 and `read` = 0 id desc");
        $handle->bindValue(1,$id);
        $handle->execute();
        if($handle->rowCount() > 0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
        }
    }

    function countTotalMessages($id){
        $handle = $this->db->prepare("select count(*) as mycount from private_message where reciever_id =?");
        $handle->bindValue(1,$id);
        $handle->execute();
        $row = $handle->fetch(PDO::FETCH_ASSOC);
        return $row['mycount'];

    }

     function countTotalUnreadMessages($id){
        $handle = $this->db->prepare("select count(*) as mycount from private_message where reciever_id =? and `read` = 0");
        $handle->bindValue(1,$id);
        $handle->execute();
        $row = $handle->fetch(PDO::FETCH_ASSOC);
        return $row['mycount'];

    }


    function EditLeadProducts($id,$leadID,$productID,$qty,$amount,$leadDemandID)
    {
        if($id >0){
            $sql = "update lead_product set productID = ?, qty = ?, `Amount` = ? where id = ? and leadID = ? and leadDemandID = ?";
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$productID,PDO::PARAM_INT);
            $handle->bindValue(2,$qty,PDO::PARAM_INT);
            $handle->bindValue(3,$amount,PDO::PARAM_INT);
            $handle->bindValue(4,$id,PDO::PARAM_INT);
            $handle->bindValue(5,$leadID,PDO::PARAM_INT);
            $handle->bindValue(6,$leadDemandID,PDO::PARAM_INT);
            $handle->execute();

        }else{
            $this->insertLeadProducts($leadID,$productID,$qty,$amount,$leadDemandID);
        }
    }

    function authenticateStaff($username, $password){

        $sql = "select * from staff where username =? and password = ?";
         $handle = $this->db->prepare($sql);
         $handle->bindValue(1,$username);
         $handle->bindValue(2,$password);
         $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                    return array($row['id'],$row['active']);
            }else{
                return array(0,0);
            }

    }

    function reArrayFiles($file_post) {

                $file_ary = array();
                $file_count = count($file_post['name']);
                $file_keys = array_keys($file_post);

                for ($i=0; $i<$file_count; $i++) {
                    foreach ($file_keys as $key) {
                        $file_ary[$i][$key] = $file_post[$key][$i];
                    }
                }

                return $file_ary;

    }

    function getDepartments(){
        $myArray = array();
        $handle = $this->db->prepare("select * from department");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }

    function getArrayDepartments(){
        $mystring = "";
        $handle = $this->db->prepare("select * from department order by id asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "[".$row['id'].",'".$row['Department']."'],";
                    }
                    return "[".$mystring."]";
                    //return "[[1,\"Agriculture\"],[2,\"Basic Medical Science\"]]";
                }else{
                    return false;
                }
    }

    function getArrayStates(){
        $mystring = "";
        $handle = $this->db->prepare("select * from states order by id asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "[".$row['id'].",'".$row['state']."'],";
                    }
                    return "[".$mystring."]";
                    //return "[[1,\"Agriculture\"],[2,\"Basic Medical Science\"]]";
                }else{
                    return false;
                }
    }

function getDepartmentsDesignation(){
        $mystring = "";
        $handle = $this->db->prepare("select * from department order by id asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "".$this->getDepartmentDesignationByID($row['id']).",";
                       $myArray[] = $row;
                    }
                     return "[".$mystring."]";
                }else{
                    return false;
                }
    }

function getDepartmentDesignationByID($id){
    $mystring = "";
    $handle = $this->db->prepare("select * from dpt_designation where dptID = ?");
    $handle->bindValue(1,$id);
    $handle->execute();
    if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "[".$row['id'].",'".$row['designation']."'],";
                    }
                    return "[".$mystring."]";
                }else{
                    return false;
                }

}
////
function getLGAofStates(){
        $mystring = "";
        $handle = $this->db->prepare("select * from states order by id asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "".$this->getLgaByID($row['id']).",";
                       $myArray[] = $row;
                    }
                     return "[".$mystring."]";
                }else{
                    return false;
                }
    }



function getAreasofLGA(){
        $mystring = "";
        $handle = $this->db->prepare("select * from states order by id asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "".$this->getAreaByID($row['id']).",";
                       $myArray[] = $row;
                    }
                     return "[".$mystring."]";
                }else{
                    return false;
                }
    }


function getLgaByID($id){
    $mystring = "";
    $handle = $this->db->prepare("select * from lga where stateID = ? order by lga asc");
    $handle->bindValue(1,$id);
    $handle->execute();
    if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "[".$row['id'].",'".$row['lga']."'],";
                    }

                }else{
                   // return false;
                }
                 return "[".$mystring."]";

}

function getAreaByID($id){
    $mystring = "";
    $handle = $this->db->prepare("select * from area_location where stateID = ? order by areaname asc");
    $handle->bindValue(1,$id);
    $handle->execute();
    if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $mystring.= "[".$row['id'].",'".$row['areaname']."'],";
                    }

                }else{
                  //  return false;
                }
                return "[".$mystring."]";

}



////



    function getAllProducts(){
        $myArray = array();
        $handle = $this->db->prepare("SELECT * FROM products WHERE active = 1 ORDER BY productName");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }

    }

       function getAllMachineProducts(){
        $myArray = array();
        $handle = $this->db->prepare("SELECT * FROM products WHERE active = 1 ORDER BY productName");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }

    }




     function getAllCountries(){
        $myArray = array();
        $handle = $this->db->prepare("select * from country where active = 1");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }
    function getAllStates(){
        $myArray = array();
        $handle = $this->db->prepare("select * from states");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }

    function getSalesStages(){
        $myArray = array();
        $handle = $this->db->prepare("select * from salesstage");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }

    function getSalesStagesPercentageOrder(){
        $myArray = array();
        $handle = $this->db->prepare("select * from salesstage order by percentage asc");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }
     function getLeadSource(){
        $myArray = array();
        $handle = $this->db->prepare("select * from leadsource");
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }

    function countMySalesStages($id,$salesstage){
        $handle = $this->db->prepare("select count(*) as myCount from leads where assigned = ? and salesStage = ?");
        $handle->bindValue(1,$id);
        $handle->bindValue(2,$salesstage);
        $handle->execute();
        $row = $handle->fetch(PDO::FETCH_ASSOC);
        return $row['myCount'];

    }

    function getAllStaffByDptID($id){
        $myArray = array();
        $handle = $this->db->prepare("select * from staff where DepartmentID = ?");
        $handle->bindValue(1, $id);
        $handle->execute();
        if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }
    }


    function registerStaff($name, $email,$phone,$dpt,$desig,$username){
        $handle = $this->db->prepare("insert into staff(fullname, phoneNo,email,DepartmentID,designationID,username) values
            (?,?,?,?,?,?)");
        $handle->bindValue(1, $name);
        $handle->bindValue(2,$phone);
        $handle->bindValue(3,$email);
        $handle->bindValue(4,$dpt);
        $handle->bindValue(5,$desig);
        $handle->bindValue(6,$username);
        $handle->execute();
        return true;
    }

    function updateStaffUserPassword($id, $password){
    try{
        $sql = "UPDATE staff SET password = ?, changePass = 1 where id = ?";
        $handle = $this->db->prepare($sql);

        $handle->bindValue(1, $password);
        $handle->bindValue(2, $id);
         $handle->execute();

     }catch(PDOException $exp){
                echo $this->getException($exp->getMessage());
            }


    }






    public function getBlogCategory(){
                $myArray = array();
                $handle = $this->db->prepare("select * from category order by id asc");
                $handle->execute();
                if($handle->rowCount() > 0){
                    while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                        $myArray[] = $row;
                    }
                    return $myArray;
                }else{
                    return false;
                }

            }

    function getNotifications($id){
        $myArray = array();
        $sql = "select * from notification where user_id = ? and view = 0 order by id desc";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $id);
        $handle->execute();
        if($handle->rowCount()>0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;
        }else{
            return null;
        }
    }

    function VerifyEmailAddress($email, $check){
    $sql = '';
    if($check == 1){$sql ="SELECT * FROM users WHERE email= ?"; }
    if($check == 2){$sql ="SELECT * FROM ticketbooking WHERE email= ?";}
    if($check == 3){$sql = "SELECT * from job_company where email = ?";}

        $handle = $this->db->prepare($sql);
         $handle->bindValue(1,$email);
         $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return true;
        }else{
                return false;
            }
    }

    function VerifyUsername($username){
         $values = "";
         $handle = $this->db->prepare("SELECT * FROM staff WHERE username= ?");
         $handle->bindValue(1,$username);
         $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return true;
        }else{
                return false;
            }
    }

    function verifyPhoneNumber($phone,$check){

    $sql = '';
    if($check == 1){$sql ="SELECT * FROM staff WHERE phoneNo= ?"; }
    if($check == 2){$sql ="SELECT * FROM ticketbooking WHERE phoneNo= ?";}
    if($check == 3){$sql = "SELECT * from job_company where phoneNo = ?";}

         $handle = $this->db->prepare($sql);
         $handle->bindValue(1,$phone);
         $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return true;
        }else{
                return false;
            }
    }

    public function ValidateEmail($email){
        //$email = htmlentities($email);
        if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
                return false;
        }else{
                return true;
            }
    }

    public function getObjectValue($name, $email, $phone,$gender, $res, $des){
        $TravelInfo = new travelInfo();
            $TravelInfo->fullname = $name;
            $TravelInfo->email = $email;
            $TravelInfo->gender = $gender;
            $TravelInfo->phone = $phone;
            $TravelInfo->res = $res;
            $TravelInfo->des = $des;
            return $TravelInfo;
    }

    public function getTravelInfo($email, $phone){
        $myArray = array();
        $sql = "select * from ticketbooking where phone = ? and email = ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1, $phone);
        $handle->bindValue(2, $email);
        $handle->execute();
            if($handle->rowCount()>0){
                while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $myArray[] = $row;
                    }
                    return $myArray;
            }else{
                return false;
            }

    }

    public function getGender($id){
        if(is_numeric($id)){
        if($id == 1){return "MALE";}
        else if($id ==2){return "FEMALE";}
        }else{ return $id;}

    }

    public function getStateName($state_id){

         $handle = $this->db->prepare("SELECT * FROM state_resident WHERE id= ?");
         $handle->bindValue(1,$state_id);
         $handle->execute();
         if($handle->rowCount()>0){
            $row = $handle->fetch(PDO::FETCH_ASSOC);
                return $row['state'];
        }else{
                return false;
            }

    }

    public function updateReadMessage($id){
         $handle = $this->db->prepare("select * from private_message where id = ?");
         $handle->bindValue(1,$id);
         $handle->execute();
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $read = $row['read'] + 1;
                $handle2 = $this->db->prepare("update private_message set `read` =? where id = ?");
                $handle2->bindValue(1,$read);
                $handle2->bindValue(2,$id, PDO::PARAM_INT);
                $handle2->execute();
            }
            $user_id  = $_SESSION['user_id'];
            $person = $this->getMyUserInformation($user_id)['fullname'];
            $subj = "Message reading";

            $message = $person." just read a message with message id: ".$id;
            $this->sendEmail("crm_solutions@tenaui.com",$subj,$message, $message, "");

    }



    function sendEmail($to,$subject,$text, $htmlVersion, $file=""){
        $from = "Elastic24 <no-reply@elastic24.com>";
            global $host;
            $headers = array ('From' => $from,'To' => $to, 'Subject' => $subject);
            $htmlHeader = '
                <style>/* -------------------------------------
    GLOBAL
    A very basic CSS reset
------------------------------------- */
* {
    margin: 0;
    padding: 0;
    font-family: "Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif;
    box-sizing: border-box;
    font-size: 14px;
}

img {
    max-width: 100%;
}

body {
    -webkit-font-smoothing: antialiased;
    -webkit-text-size-adjust: none;
    width: 100% !important;
    height: 100%;
    line-height: 1.6;
}


table td {
    vertical-align: top;
}

body {
    background-color: #f6f6f6;
}

.body-wrap {
    background-color: #f6f6f6;
    width: 100%;
}

.container {
    display: block !important;
    max-width: 600px !important;
    margin: 0 auto !important;
    /* makes it centered */
    clear: both !important;
}

.content {
    max-width: 600px;
    margin: 0 auto;
    display: block;
    padding: 20px;
}

/* -------------------------------------
    HEADER, FOOTER, MAIN
------------------------------------- */
.main {
    background: #fff;
    border: 1px solid #e9e9e9;
    border-radius: 3px;
}

.content-wrap {
    padding: 20px;
}

.content-block {
    padding: 0 0 20px;
}

.header {
    width: 100%;
    margin-bottom: 20px;
}

.footer {
    width: 100%;
    clear: both;
    color: #999;
    padding: 20px;
}
.footer a {
    color: #999;
}
.footer p, .footer a, .footer unsubscribe, .footer td {
    font-size: 12px;
}

/* -------------------------------------
    TYPOGRAPHY
------------------------------------- */
h1, h2, h3 {
    font-family: "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
    color: #000;
    margin: 40px 0 0;
    line-height: 1.2;
    font-weight: 400;
}

h1 {
    font-size: 32px;
    font-weight: 500;
}

h2 {
    font-size: 24px;
}

h3 {
    font-size: 18px;
}

h4 {
    font-size: 14px;
    font-weight: 600;
}

p, ul, ol {
    margin-bottom: 10px;
    font-weight: normal;
}
p li, ul li, ol li {
    margin-left: 5px;
    list-style-position: inside;
}

/* -------------------------------------
    LINKS & BUTTONS
------------------------------------- */
a {
    color: #1ab394;
    text-decoration: underline;
}

.btn-primary {
    text-decoration: none;
    color: #FFF;
    background-color: #1ab394;
    border: solid #1ab394;
    border-width: 5px 10px;
    line-height: 2;
    font-weight: bold;
    text-align: center;
    cursor: pointer;
    display: inline-block;
    border-radius: 5px;
    text-transform: capitalize;
}

/* -------------------------------------
    OTHER STYLES THAT MIGHT BE USEFUL
------------------------------------- */
.last {
    margin-bottom: 0;
}

.first {
    margin-top: 0;
}

.aligncenter {
    text-align: center;
}

.alignright {
    text-align: right;
}

.alignleft {
    text-align: left;
}

.clear {
    clear: both;
}

/* -------------------------------------
    ALERTS
    Change the class depending on warning email, good email or bad email
------------------------------------- */
.alert {
    font-size: 16px;
    color: #fff;
    font-weight: 500;
    padding: 20px;
    text-align: center;
    border-radius: 3px 3px 0 0;
}
.alert a {
    color: #fff;
    text-decoration: none;
    font-weight: 500;
    font-size: 16px;
}
.alert.alert-warning {
    background: #f8ac59;
}
.alert.alert-bad {
    background: #ed5565;
}
.alert.alert-good {
    background: #1ab394;
}

/* -------------------------------------
    INVOICE
    Styles for the billing table
------------------------------------- */
.invoice {
    margin: 40px auto;
    text-align: left;
    width: 80%;
}
.invoice td {
    padding: 5px 0;
}
.invoice .invoice-items {
    width: 100%;
}
.invoice .invoice-items td {
    border-top: #eee 1px solid;
}
.invoice .invoice-items .total td {
    border-top: 2px solid #333;
    border-bottom: 2px solid #333;
    font-weight: 700;
}

/* -------------------------------------
    RESPONSIVE AND MOBILE FRIENDLY STYLES
------------------------------------- */
@media only screen and (max-width: 640px) {
    h1, h2, h3, h4 {
        font-weight: 600 !important;
        margin: 20px 0 5px !important;
    }

    h1 {
        font-size: 22px !important;
    }

    h2 {
        font-size: 18px !important;
    }

    h3 {
        font-size: 16px !important;
    }

    .container {
        width: 100% !important;
    }

    .content, .content-wrap {
        padding: 10px !important;
    }

    .invoice {
        width: 100% !important;
    }
}
</style>



           <table class="body-wrap">
    <tr>
        <td></td>
        <td class="container" width="600">
            <div class="content">
                <table class="main" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td class="content-wrap">
                            <table  cellpadding="0" cellspacing="0">
                                <tr>
                                    <td>
                                        <img class="img-responsive" src="http://www.elastic24.com/img/header_.jpg"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="content-block">
                                        ';

            $htmlFooter = '</td>

            <tr><td class="content-block">
                                        Thanks for choosing Tenaui Africa Ltd.
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                </div>
        </td>
        <td></td>
    </tr>
</table>';
            $html = $htmlHeader.$htmlVersion.$htmlFooter;

            $crlf = "\n";

            $mime = new Mail_mime($crlf);
            $mime->setTXTBody($text);
            $mime->setHTMLBody($html);
            if($file != ""){
                $mime->addAttachment($file);
            }
            //do not ever try to call these lines in reverse order
            $body = $mime->get();
            $headers = $mime->headers($headers);

             $host_ = "localhost"; // all scripts must use localhost
             $username = "no-reply@elastic24.com"; //  your email address (same as webmail username)
             $password = "1234567890"; // your password (same as webmail password)

            $smtp = Mail::factory('smtp', array ('host' => $host_, 'auth' => true,
            'username' => $username,'password' => $password));

            $mail = $smtp->send($to, $headers, $body);

            if (PEAR::isError($mail)) {
            //echo("<p>" . $mail->getMessage() . "</p>");
            }
            else {
            //echo("<p>Message successfully sent!</p>");
            // header("Location: http://www.example.com/");
            }

    }

    function generateRandomString($length = 10) {
        $characters = '3456789BCDGHIJKLMPQSUVWXY';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
     }

    public function redirect_to($url){
        header("location:".$url);
    }



  function checkUsernameValidity($username){
        if (!preg_match("/^[a-zA-Z0-9_]*$/",$username)) {
             return false;
            }else{
            return true;
        }
    }




   function LoginInLogs($userID){
            try{
                $handle = $this->db->prepare("INSERT INTO users_loginlog (user_id, timeStamp, date, ipAddress) values(?,?,?,?)");

                                 $handle->bindValue(1,$userID);
                                 $handle->bindValue(2, time());
                                 $handle->bindValue(3,date("d-m-Y h:i:s A"));
                                 $handle->bindValue(4, $_SERVER['REMOTE_ADDR']);
                                 $handle->execute();

                }catch(PDOException $exp){
                echo $this->getException($exp->getMessage());
            }
    }

    public function selectNewsID($value){
         $values = "";
         $handle = $this->db->prepare("select id from news where linkHeadline = ?");
         $handle->bindValue(1,$value);
         $handle->execute();

            while($row = $handle->fetch(PDO::FETCH_ASSOC)){

                if($row['id']){$values = $row['id'];}else{$values = 0;}
            }
        return $values;
    }






    public function updateReadForum($id){
         $handle = $this->db->prepare("select * from forum_post where forum_subject_link = ?");
         $handle->bindValue(1,$id);
         $handle->execute();
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $read = $row['views'] + 1;
                $handle2 = $this->db->prepare("update forum_post set `views` =? where forum_subject_link = ?");
                $handle2->bindValue(1,$read);
                $handle2->bindValue(2,$id);
                $handle2->execute();
            }

    }



    public function AddEmail($email){
        //$email = htmlentities($email);
        if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
                return '<p style="color: #FF0000">INVALID EMAIL FORMAT</p>';
        }else{
                return $this->addEmail2($email);
            }
    }



    public function statistics($ip_address, $time_stamp, $web_page, $time, $date, $user_id = 0){

        try{
            $handle = $this->db->prepare("SELECT * FROM hits WHERE ip_address = ? and date = ? and user_id = ?");
            $handle->bindValue(1,$ip_address);
            $handle->bindValue(2,$date);
            $handle->bindValue(3,$user_id);
            $handle->execute();
             $handle->rowCount();
                if($handle->rowCount() == 0){
                 $handle2 = $this->db->prepare("INSERT INTO `hits` (ip_address, time_stamp, date, time, user_id) VALUES (?,?,?,?,?)");
                 $handle2->bindValue(1, $ip_address);
                 $handle2->bindValue(2, $time_stamp);
                 $handle2->bindValue(3, $date);
                 $handle2->bindValue(4, $time);
                 $handle2->bindValue(5,$user_id,PDO::PARAM_INT);
                 $handle2->execute();

                }else if($handle->rowCount() > 0){
                 $handle2 = $this->db->prepare("UPDATE `hits` SET time_stamp =?, time =? WHERE ip_address =? and date =? and user_id =?");
                 $handle2->bindValue(1, $time_stamp);
                 $handle2->bindValue(2, $time);
                 $handle2->bindValue(3, $ip_address);
                 $handle2->bindValue(4, $date);
                 $handle2->bindValue(5,$user_id,PDO::PARAM_INT);
                 $handle2->execute();

                }
                $handle3 = $this->db->prepare("INSERT INTO pagerequest (ip_address, webpage, date, time, user_id) VALUES (?,?,?,?,?)");
                 $handle3->bindValue(1, $ip_address);
                 $handle3->bindValue(2, $web_page);
                 $handle3->bindValue(3, $date);
                 $handle3->bindValue(4, $time);
                 $handle3->bindValue(5,$user_id,PDO::PARAM_INT);
                 $handle3->execute();

        }catch(PDOException $exp){
            echo $exp->getMessage();
            return false;
        }

    }

    public function getUniqueBlog($news_id, $headline){
        try{
        $handle = $this->db->prepare("SELECT * FROM news WHERE id = ? and linkHeadline = ?");
            $handle->bindValue(1,$news_id,PDO::PARAM_INT);
            $handle->bindValue(2,$headline);
            $handle->execute();
            if($handle->rowCount()>0){
                $row = $handle->fetch(PDO::FETCH_ASSOC);
                      return $row;
                }
            }catch(Exception $exp){echo $this->getException($exp->getMessage());}
    }





    public function displayUserText($text){
        $text =nl2br($text);

        $text = preg_replace("/@(\w+)/i", "<a href=\"{$this->host}$1\">$0</a>", $text);//replaces the @
        $text = preg_replace("/#(\w+)/i", "<a href=\"{$this->host}hashtags/$1\">$0</a>", $text);//replaces the #

        return $text;

    }

    function mentionNotification($username,$myuserID, $link,$subj){
        foreach($username as $val){
            foreach($val as $val){
                $linkHost = "http:www.ajuwaya.org";
                  $mention_id = $this->getUserID(substr($val, 1));
                  if($mention_id > 0 && $mention_id != $myuserID){
                          $msg = "@".$this->getMyUserInformation($myuserID)['username']." mentioned you on new post &#34".$subj."&#34; ";

                          $this->createNotifications($mention_id,$myuserID,$msg,$link);
                   }
                  }
          }
    }

    public function postForumComment($user_id,$cat_id, $post_id,$post,$choose){

        if($choose == 1){
            //forum post
            //if($this->verifyPostFirst($user_id, $cat_id, $post_id,$post,1)){
                    $handle = $this->db->prepare("insert into forum_comments (cat_id, user_id, post_id, post, timestamp,datetime,ipAddress) values(?,?,?,?,?,?,?)");
                    $handle->bindValue(1, $cat_id);
                    $handle->bindValue(2, $user_id);
                    $handle->bindValue(3, $post_id);
                    $handle->bindValue(4, $post);
                    $handle->bindValue(5, time());
                    $handle->bindValue(6,date("d-m-Y h:i:s A"));
                    $handle->bindValue(7, $_SERVER['REMOTE_ADDR']);
           // }
        }
        else if($choose == 2){
            //blog post
           // if($this->verifyPostFirst($user_id, $cat_id, $post_id,$post,2)){

                $handle = $this->db->prepare("insert into blog_comments (news_id, user_id, comments, timestamp,datetime,ipAddress) values(?,?,?,?,?,?)");
                $handle->bindValue(1, $post_id);
                $handle->bindValue(2, $user_id);
                $handle->bindValue(3, $post);
                $handle->bindValue(4, time());
                $handle->bindValue(5,date("d-m-Y h:i:s A"));
                $handle->bindValue(6, $_SERVER['REMOTE_ADDR']);
            // }
        }
        $handle->execute();
        return $this->db->lastInsertId();
    }

    public function verifypasswordmatch($id,$password){
        $sql = "select * from `users` where id = ? and password =?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);
        $handle->bindValue(2,$password);
        $handle->execute();
        if($handle->rowCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    public function getForumCategoryID($category){
        $sql = "select * from forum_category where category =?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$category);

        $handle->execute();
        if($handle->rowCount() > 0){
           return $handle->fetch(PDO::FETCH_ASSOC)['id'];
        }else{
            return false;
        }
    }

    public function upDatePassword($id,$password){

        $sql = "update users set password =? where id = ?";
        $handle = $this->db->prepare($sql);

       $handle->bindValue(1,$password);
        $handle->bindValue(2,$id,PDO::PARAM_INT);
       $handle->execute();
      //  $this->showMsg($sql,$id." psswor: ".$password,2);

    }

    public function getMyUserInformation($id){
        $sql = "select st.*,
        ds.dptID,ds.dptaccessLevel,ds.designation,d.Department

        from staff st
        join dpt_designation ds on st.designationID = ds.id
        join department d on st.DepartmentID = d.id
        where st.id =  ?";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$id);

        $handle->execute();
        if($handle->rowCount() > 0){
            return $row = $handle->fetch(PDO::FETCH_ASSOC);
        }else{
            return false;
        }

    }

    public function selectAllForumCategory(){
        $MyArray = array();
         $handle = $this->db->prepare("select * from forum_category");
         $handle->execute();
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $MyArray[] = $row;
                }
        return $MyArray;

    }

    public function createForumTopic($user_id,$cat,$subj,$subj2,$msg,$file,$uploadpath){
           if($this->getForumTopic($subj2)){
               $this->showMsg('','A similar conversation with this topic has been created, you have to start a new conversation',1);
           }else{
                 try{
                     $img = "";
                     if($file['size'] > 0){
                         $img = $this->uploadImages('../'.$uploadpath,$file['tmp_name'],$file['size'],$file['type'],500,250,100);
                     }
                                $handle = $this->db->prepare("INSERT INTO forum_post (user_id,category,forum_subject,forum_subject_link,forum_post, timestamp, date, time, ipAddress,image) values(?,?,?,?,?,?,?,?,?,?)");
                                 $handle->bindValue(1,$user_id);
                                 $handle->bindValue(2,$cat);
                                 $handle->bindValue(3,$subj);
                                 $handle->bindValue(4,$subj2);
                                 $handle->bindValue(5,$msg);
                                 $handle->bindValue(6, time());
                                 $handle->bindValue(7,date("d-m-Y"));
                                 $handle->bindValue(8,date("h:i:s A"));
                                 $handle->bindValue(9, $_SERVER['REMOTE_ADDR']);
                                 $handle->bindValue(10, $img);

                                 $handle->execute();

                                 $this->showMsg('','you topic has been created it will be featured on front page if it has more comments and views',2);
                                 $this->showMsg('',"click your post <a href='".$this->host."forum-post/".$subj2."'>".$subj."</a>",2);
                                 return true;
                }catch(PDOException $exp){
                    echo $this->getException($exp->getMessage());
                }
           }
    }

    public function getForumTopic($subj2){
       $MyArray = array();
         $handle = $this->db->prepare("select * from forum_post where forum_subject_link = ?");
         $handle->bindValue(1,$subj2);
         $handle->execute();
            if($handle->rowCount()>0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $MyArray[] = $row;
                }
                return $MyArray;
             }else{
                 return false;
             }

    }



    function createNotifications($user_id,$sender_id,$message,$url){
        $sql = "insert into notification (user_id,sender_id,message, url,timestamp) values (?,?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->bindValue(2, $sender_id);
        $handle->bindValue(3, $message);
        $handle->bindValue(4, $url);
        $handle->bindValue(5, time());
        $handle->execute();

    }

    function createMPFTicket($leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories){
         $leadDemandID = $this->enterLeadDemand($leadID,2,$description);


        
       $this->AddMPFTicketMachine($leadDemandID,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories);
    }

    

//($getLeadDemand,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories)

    function updateMPSMachineInfo($id,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories){
        $sql = "update mps_info set productID =?, product_qty = ?, rentalCharge = ?,cost_mono =?, cost_color = ?, min_vol_mono = ?, min_vol_color = ?, contract_duration =?,billingType =?, accesories = ? where id = ? and leadID = ?";

        $handle = $this->db->prepare($sql);

        $handle->bindValue(1,$productID);
        $handle->bindValue(2,$qty);
        $handle->bindValue(3,str_replace(',','',$rentalcharge));
        $handle->bindValue(4, str_replace(',','',$costMono));
        $handle->bindValue(5, str_replace(',','',$costColor));
        $handle->bindValue(6,$minVolMono);
        $handle->bindValue(7,$minVolColor);
        $handle->bindValue(8,$contractDuration);
        $handle->bindValue(9,$BillingType);
        $handle->bindValue(10,$accessories);
        $handle->bindValue(11,$id);
        $handle->bindValue(12,$leadID);
        $handle->execute();



    }






    function AddMPFTicketMachine($leadDemandID,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories){
         //$leadDemandID = $this->enterLeadDemand($leadID,2,$description);
         
for($i=0;$i<count($productID);$i++){
  if($productID[$i]!="" && $qty[$i]!="" && $rentalcharge[$i]!=""){

        $sql = "insert into mps_info (leadID,lead_demand_id,productID,product_qty,rentalCharge,cost_mono,cost_color,min_vol_mono,min_vol_color,contract_duration,billingType,accesories) values(?,?,?,?,?,?,?,?,?,?,?,?)";
        //str_replace(',','',$amount[$i]);
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$leadID);
        $handle->bindValue(2,$leadDemandID);
        $handle->bindValue(3,$productID[$i]);
        $handle->bindValue(4,$qty[$i]);
        $handle->bindValue(5,str_replace(',','',$rentalcharge[$i]));
        $handle->bindValue(6, str_replace(',','',$costMono));
        $handle->bindValue(7, str_replace(',','',$costColor));
        $handle->bindValue(8,$minVolMono);
        $handle->bindValue(9,$minVolColor);
        $handle->bindValue(10,$contractDuration);
        $handle->bindValue(11,$BillingType);
        $handle->bindValue(12,$accessories);
        $handle->execute();
         }
         else{
    echo "<h1>Query Failed</h1>";
  }

     }
    }

    function getTransactionRanking($year){
        $sql= "select l.companyName, l.email, ld.ticketNo, SUM(lp.qty * lp.Amount) as Amount, ld.ocMonth, ocYear, s.fullname as admin
        from lead_product lp
        join lead_demand ld on lp.leadDemandID = ld.id
        join leads l on lp.leadID = l.id
        join staff s on l.assigned = s.id
        where ld.orderCollect = 1

        and ocYear = ? GROUP BY ld.ticketNo order by SUM(lp.qty * lp.Amount) desc";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$year,PDO::PARAM_INT);
        $handle->execute();

        if($handle->rowCount()>0){
            while ($row = $handle->fetch(PDO::FETCH_ASSOC)){
                $myArray[] = $row;
            }
            return $myArray;

        }else{
                return null;
        }




    }

    function createActivityNotifications($message){
        $user_id = $_SESSION['user_id'];
        $sql = "insert into `activities` (user_id,activities,timeStamp, dateTime) values (?,?,?,?)";
        $handle = $this->db->prepare($sql);
        $handle->bindValue(1,$user_id);
        $handle->bindValue(2, $message);
        $handle->bindValue(3, time());
        $handle->bindValue(4, date("d-m-Y h:i:s A"));
        $handle->execute();
    }

    function getActivitiesNotifications($id = ""){
        $handle = "";
        $MyArray = array();
        if($id == ""){
            $sql = "select st.fullname as admin, act.activities, act.timeStamp, act.dateTime  from `activities` act
            join staff st on st.id = act.user_id order by act.id desc";
             $handle = $this->db->prepare($sql);
             $handle->execute();
        }else{
            $sql = "select st.fullname as admin, act.activities, act.timeStamp, act.dateTime  from `activities` act
            join staff st on st.id = act.user_id where act.user_id = ? order by act.id desc";
             $handle = $this->db->prepare($sql);
             $handle->bindValue(1,$id);
             $handle->execute();
        }

         if($handle->rowCount()>0){
            while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $MyArray[] = $row;
                }
                return $MyArray;
             }else{
                 return false;
             }

    }

    public function showMsg($header, $msg, $num){
        if($num == 1){

            echo '<div class="alert alert-danger alert-dismissable" role="alert">
            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <strong>'.$header.'</strong> '.$msg.'.
               </div>';
        }   else if($num == 2){
        echo '<div class="alert alert-success alert-dismissable" role="alert">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <strong>'.$header.'</strong> '.$msg.'.
               </div>';
        }
    }

    public function paging($query, $records_per_page){
        $start_pos = 0;
        if(isset($_GET["page_no"])){
            $start_pos = ($_GET["page_no"] - 1) * $records_per_page;
        }
        $query =$query." limit $start_pos, $records_per_page";
        return $query;
    }

    public function check(){
        $s = time();
        echo $s;
    }

    public function getString($my_string, $num){
        if (strlen($my_string)> $num){return substr($my_string,0,$num)."...";}
        else{return $my_string;}
    }

    public function getQueriesArray($query){
        $myArray = array();
        try{
            $handle = $this->db->prepare($query);
            $handle->execute();
            if($handle->rowCount()>0){
                while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                    $myArray[] = $row;

                }
                return $myArray;
            }else{
                    return false;
                }
        }catch(PDOException $ex){ echo $this->getException($ex->getMessage());}
    }




    function time_elapsed_string($ptime){
        $etime = time() - $ptime;
        if($etime <1){
            return 'a moment ago';
        }

        $a = array( 365*24*60*60=>'year', 30*24*60*60=>'month', 7*24*60*60=>'week', 24*60*60=>'day', 60*60=>'hr', 60=>'min',1=>'second');
        $a_plural = array('year'=>'years', 'month'=>'months','week'=>'weeks', 'day'=>'days','hr'=>'hrs','min'=>'mins','second'=>'seconds');

        foreach($a as $secs=>$str){
            $d = $etime/$secs;
            if($d>=1){
                $r =  round($d);
                return $r.' '.($r >1 ? $a_plural[$str] : $str).' ago';
            }
        }
    }

    public function getComments($id,$choose){
        $sql = "";
        if($choose == 1){
            //forum comments
            $sql = "select * from forum_comments where post_id =?";

        }  else{
            //blog comments
            $sql = "select * from blog_comments where news_id = ?";
        }
           $myArray = array();
        try{
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1, $id);
            $handle->execute();
            if($handle->rowCount()>0){
                while($row = $handle->fetch(PDO::FETCH_ASSOC)){
                   $myArray[] = $row;
                }
                return $myArray;
            }else{

                }
        }catch(PDOException $ex){ $this->getException($ex->getMessage());}
    }

    public function likeSettings($id, $tpye, $user_id, $ipAddress){

    }

    public function sendSMS($cell_number, $send_message){

        // SCRIPTS TO SEND SMS

        $sender = "AJUWAYA.ORG";    //It can be a $_POST or $_GET;
        $sender_id = @preg_replace('/ +/','+',$sender);  // REPLACE SPACE WITH +. URL ENCODED
        $cell_number =@preg_replace('/ +/','+',$cell_number);  // REPLACE SPACE WITH +. URL ENCODED

        $breaks = array("\r\n", "\n", "\r");    // ARRAY OF BREAKS
        $msg = str_replace($breaks, " ", $send_message);    // REMOVE BREAKS
        $message = @preg_replace('/ +/','+',$msg);               // REPLACE SPACE WITH +. URL ENCODED

        $send_api ="http://customizedsms.net/components/com_spc/smsapi.php?username=erickchidubem&password=chidubemosarume&message=$message&sender=$sender_id&recipient=$cell_number";

        // PLEASE REPLACE YOURUSERNAME with your username

        $cookie = tempnam ("/tmp", "CURLCOOKIE");

        $ch = curl_init();
        curl_setopt( $ch, CURLOPT_COOKIEJAR, $cookie );
        curl_setopt($ch, CURLOPT_URL, $send_api );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
        $results=curl_exec($ch);

        if($results){
             //echo "message sent successfully";
        }
    }

    public function get_OneRow($query){
        $handle = $this->db->prepare($query);
        $handle->execute();
        $row = $handle->fetch(PDO::FETCH_ASSOC);
        return $row;
    }

    public function perform_execution($sql){
        $handle = $this->db->prepare($sql);
        $handle->execute();
    }

    public function countUsersComment($news_id, $choose){
        $sql = "";
        if($choose == 1){
            //count forum comments
            $sql = "select * from forum_comments where post_id = ?";
        }else{
            //count blog comments
            $sql = "SELECT * FROM blog_comments WHERE news_id = ?";

        }
            $handle = $this->db->prepare($sql);
            $handle->bindValue(1,$news_id,PDO::PARAM_INT);
            $handle->execute();
            echo $handle->rowCount();
    }

    public function paginglink($query, $records_per_page, $values=""){
        //$self =substr($_SERVER['PHP_SELF'],0,strrpos($_SERVER['PHP_SELF'], "."));
        //$self =$_SERVER['PHP_SELF'];
        $self = "";
        if($values == ""){
            $self = substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'], "?page_no"));
        }else{
            $self = substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'], "&page_no"));
        }
        try{
            $handle = $this->db->prepare($query);
            $handle->execute();
            $total_no_of_records = $handle->rowCount();

            if($total_no_of_records >0){?>
                    <ul class="pagination pagination-sm">
            <?php
                $total_no_of_pages = ceil($total_no_of_records/$records_per_page);
                $current_page = 1;
                if(isset($_GET["page_no"])){

                    $current_page = $_GET["page_no"];
                }
                $page_no= "";
                if(trim($values)==""){$page_no = "?page_no=";}else{ $page_no = "&page_no=";}
                $link = $self.$values.$page_no;
                if($current_page !=1){
                    $previous = $current_page - 1;
                    ?>
                    <li><a href="<?php echo $link."1";?>">&lt;&lt;</a></li>
                    <li><a href="<?php echo $link.$previous; ?>">&lt;</a></li>
                <?php }

                for($i =1 ; $i < $total_no_of_pages; $i++){
                    if($i == $current_page){?>
                        <li class='active'><a href="<?php echo $link.$i;?>"><?php echo $i;?></a></li>
                    <?php }else{?>
                        <li><a href="<?php echo $link.$i;?>"><?php echo $i;?></a></li>
                        <?php
                    }
                }
                if($current_page != $total_no_of_pages){
                    $next = $current_page+1;
                    ?><li><a href="<?php echo $link.$next;?>">&gt;</a></li>
                     <li><a href="<?php echo $link.$total_no_of_pages;?>">&gt;&gt;</a></li>
                     <?php
                }?>
                </ul>
                <?php


            }

            }catch(PDOException $ex){
                    echo $ex->getMessage();
                    return false;
        }
    }

    public function paginglink_2($total_no_of_records, $records_per_page, $values=""){
        //$self =substr($_SERVER['PHP_SELF'],0,strrpos($_SERVER['PHP_SELF'], "."));
        //$self =$_SERVER['PHP_SELF'];
        $self = "";
        if($values == ""){
            $self = substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'], "?page_no"));
        }else{
            $self = substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'], "&page_no"));
        }
        try{

            if($total_no_of_records >0){?>
                    <ul class="pagination pagination-sm">
            <?php
                $total_no_of_pages = ceil($total_no_of_records/$records_per_page);
                $current_page = 1;
                if(isset($_GET["page_no"])){

                    $current_page = $_GET["page_no"];
                }
                $page_no= "";
                if(trim($values)==""){$page_no = "?page_no=";}else{ $page_no = "&page_no=";}
                $link = $self.$values.$page_no;
                if($current_page !=1){
                    $previous = $current_page - 1;
                    ?>
                    <li><a href="<?php echo $link."1";?>">&lt;&lt;</a></li>
                    <li><a href="<?php echo $link.$previous; ?>">&lt;</a></li>
                <?php }

                for($i =1 ; $i < $total_no_of_pages; $i++){
                    if($i == $current_page){?>
                        <li class='active'><a href="<?php echo $link.$i;?>"><?php echo $i;?></a></li>
                    <?php }else{?>
                        <li><a href="<?php echo $link.$i;?>"><?php echo $i;?></a></li>
                        <?php
                    }
                }
                if($current_page != $total_no_of_pages){
                    $next = $current_page+1;
                    ?><li><a href="<?php echo $link.$next;?>">&gt;</a></li>
                     <li><a href="<?php echo $link.$total_no_of_pages;?>">&gt;&gt;</a></li>
                     <?php
                }?>
                </ul>
                <?php


            }

            }catch(PDOException $ex){
                    echo $ex->getMessage();
                    return false;
        }
    }

    public function convert_number_to_words($number) {

    $hyphen      = '-';
    $conjunction = ' and ';
    $separator   = ', ';
    $negative    = 'negative ';
    $decimal     = ' point ';
    $dictionary  = array(
        0                   => 'zero',
        1                   => 'one',
        2                   => 'two',
        3                   => 'three',
        4                   => 'four',
        5                   => 'five',
        6                   => 'six',
        7                   => 'seven',
        8                   => 'eight',
        9                   => 'nine',
        10                  => 'ten',
        11                  => 'eleven',
        12                  => 'twelve',
        13                  => 'thirteen',
        14                  => 'fourteen',
        15                  => 'fifteen',
        16                  => 'sixteen',
        17                  => 'seventeen',
        18                  => 'eighteen',
        19                  => 'nineteen',
        20                  => 'twenty',
        30                  => 'thirty',
        40                  => 'fourty',
        50                  => 'fifty',
        60                  => 'sixty',
        70                  => 'seventy',
        80                  => 'eighty',
        90                  => 'ninety',
        100                 => 'hundred',
        1000                => 'thousand',
        1000000             => 'million',
        1000000000          => 'billion',
        1000000000000       => 'trillion',
        1000000000000000    => 'quadrillion',
        1000000000000000000 => 'quintillion'
    );

    if (!is_numeric($number)) {
        return false;
    }

    if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
        // overflow
        trigger_error(
            'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
            E_USER_WARNING
        );
        return false;
    }

    if ($number < 0) {
        return $negative . $this->convert_number_to_words(abs($number));
    }

    $string = $fraction = null;

    if (strpos($number, '.') !== false) {
        list($number, $fraction) = explode('.', $number);
    }

    switch (true) {
        case $number < 21:
            $string = $dictionary[$number];
            break;
        case $number < 100:
            $tens   = ((int) ($number / 10)) * 10;
            $units  = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
            break;
        case $number < 1000:
            $hundreds  = $number / 100;
            $remainder = $number % 100;
            $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
            if ($remainder) {
                $string .= $conjunction . $this->convert_number_to_words($remainder);
            }
            break;
        default:
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int) ($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= $this->convert_number_to_words($remainder);
            }
            break;
    }

    if (null !== $fraction && is_numeric($fraction)) {
        $string .= $decimal;
        $words = array();
        foreach (str_split((string) $fraction) as $number) {
            $words[] = $dictionary[$number];
        }
        $string .= implode(' ', $words);
    }

    return $string;
}

   //IMAGE UPLOAD AND RESIZE STARTS HERE
     function validateImageFile($fileName){
        $allowed =  array('gif','png' ,'jpg');
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if(!in_array($ext,$allowed) ) {
           return false;
        }else{
            return true;
        }
    }

    function validateImageSize($fileTemp, $theWidth){
        if(isset($fileTemp) || !empty($fileTemp)){
        @list($w, $h) = getimagesize($fileTemp);
            if($theWidth >= $w){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }


    function uploadImages($upload_dir,$fileTemp, $fileSize,$fileType,$size1,$size2,$size3){

    if(isset($fileTemp) || !empty($fileTemp)){
       list($w, $h) = getimagesize($fileTemp);
       $wid = $w;

    }
        if (isset($fileSize) && ($fileSize > 0)){

            $rand = rand(0, 999999999);
            $path1 = "ajuwaya.org_".date("Y-").time()."-$rand.jpg";
            $u_filename =   $path1 ; ///basename($_FILES['file']['name']);
            move_uploaded_file($fileTemp, $upload_dir.'/'.$u_filename);

    //dimension proper
        if($size1 >= $wid){$size1 = $wid;}
        if($size2 >= $wid){$size2 = $wid;}
        if($size3 >= $wid){$size3 = $wid;}
    //end dimension proper

    // Setting params array for thumbnail_generator
      $params = array(array('size' => $size1,'file' => $upload_dir.'/big-'.$u_filename),
                      array('size' => $size2,'file' => $upload_dir.'/mid-'.$u_filename),
                      array('size' => $size3,'file' => $upload_dir.'/small-'.$u_filename));

    if ($this->thumbnail_generator($upload_dir.'/'.$u_filename, $params,$u_filename,$fileType) == false){ echo " "; }

            ///DELETE UPLOADED FILE
            if(file_exists($upload_dir.'/'.$u_filename)){unlink($upload_dir.'/'.$u_filename);}

        return $path1;
        }
    }

    function thumbnail_calcsize($w, $h, $square){
        $k = $square / max($w, $h);
        return array($w*$k, $h*$k);
    }

    function thumbnail_generator($srcfile,$params,$filename,$f_types){
        // getting source image size
        @list($w, $h) = getimagesize($srcfile);
        if ($w == false)
            return false;

        // checking params array
        if (!(is_array($params)&&is_array($params[0])))
            return false;

      //  $src = ImageCreateFromJpeg($srcfile);

         /*$filename = $filename;

          $f_types = $fileType;*/

             if($f_types == "image/jpeg" || $f_types == "image/JPEG") {
              $src = ImageCreateFromJpeg($srcfile);
              }

        if($f_types == "image/gif" || $f_types == "image/GIF") {
           $src = ImageCreateFromGif($srcfile);
             }

            if($f_types == "image/png" || $f_types == "image/PNG") {
          $src = ImageCreateFromPng($srcfile);
        }



        list($s1_w, $s1_h) = $this->thumbnail_calcsize($w, $h, $params[0]['size']);

        // Create first thumbnail
        // Remember, first thumbnail should be largest thumbnail
        $img_s1 = imagecreatetruecolor($s1_w, $s1_h);
        imagecopyresampled($img_s1, $src, 0, 0, 0, 0, $s1_w, $s1_h, $w, $h);
        imagedestroy($src); // Destroy source image


        // Other thumbnails are just downscaled copies of the first one
        for($i=1; $i<sizeof($params); $i++)
        {
            list($cur_w, $cur_h) = $this->thumbnail_calcsize($w, $h, $params[$i]['size']);
            $img_cur = imagecreatetruecolor($cur_w, $cur_h);
            imagecopyresampled($img_cur, $img_s1, 0, 0, 0, 0, $cur_w, $cur_h, $s1_w, $s1_h);
            imagejpeg($img_cur, $params[$i]['file'], 90);
            imagedestroy($img_cur);
        }

        // Saving first thumbnail
        imagejpeg($img_s1, $params[0]['file'], 90);
        imagedestroy($img_s1);
        return true;
    }
    //IMAGE UPLOAD ENDS HERE



    
    public function getUsersMonthlyTarget($user_id,$month,$year){
    $sql = "SELECT * FROM monthly_target WHERE user_id = ? AND tmonth = ? AND tyear = ?";
      $myArray = array();
      $handle = $this->db->prepare($sql);
      $handle->bindValue(1,$user_id);
      $handle->bindValue(2,$month);
      $handle->bindValue(3,$year);
      $handle->execute();
      if ($handle->rowCount() > 0) {
            while($row = $handle->fetch(PDO::FETCH_ASSOC))
            {
                   $myArray[] = $row;
            }
            return $myArray;
        } else {
            return false;
        }

    }

}



?>

