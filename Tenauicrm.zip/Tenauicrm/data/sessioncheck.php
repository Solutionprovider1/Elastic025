 <?php 
 
 if(isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0){

	$user_id = $_SESSION['user_id'];
if($user_id == 3){$database->redirect_to($host."logout");}
    $myData = $database->getMyUserInformation($user_id);

  }else{
  	$database->redirect_to($host."login");
  }

?>