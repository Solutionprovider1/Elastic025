<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Year Sales</title>
        <link rel="stylesheet" href="style.css" type="text/css">
        <script src="../amcharts/amcharts.js" type="text/javascript"></script>
        <script src="../amcharts/serial.js" type="text/javascript"></script>

        <script>
            var chart;

            var chartData = [

        {
            "country": "<?php echo $database->getMyUserInformation(3)['fullname'];?>",
            "visits":"<?php echo $database->getYearSalesRanking(3,2017);?>",
            "color":"<?php $rand = dechex(rand(0x000000, 0xFFFFFF)); echo('#' . $rand);?>"
        },
        {
            "country": "<?php echo $database->getMyUserInformation(7)['fullname'];?>",
            "visits":"<?php echo $database->getYearSalesRanking(7,2017);?>",
            "color":"<?php $rand = dechex(rand(0x000000, 0xFFFFFF)); echo('#' . $rand);?>"
        },
        {
            "country": "<?php echo $database->getMyUserInformation(10)['fullname'];?>",
            "visits":"<?php echo $database->getYearSalesRanking(10,2017);?>",
            "color":"<?php $rand = dechex(rand(0x000000, 0xFFFFFF)); echo('#' . $rand);?>"
        },
        {
            "country": "<?php echo $database->getMyUserInformation(9)['fullname'];?>",
            "visits":"<?php echo $database->getYearSalesRanking(9,2017);?>",
            "color":"<?php $rand = dechex(rand(0x000000, 0xFFFFFF)); echo('#' . $rand);?>"
        },
                
                
            ];


            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "country";
                chart.startDuration = 1;
                chart.depth3D = 50;
                chart.angle = 30;
                chart.marginRight = -45;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.axisAlpha = 0;
                valueAxis.gridAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPH
                var graph = new AmCharts.AmGraph();
                graph.valueField = "visits";
                graph.colorField = "color";
                graph.balloonText = "<b>[[category]]: [[value]]</b>";
                graph.type = "column";
                graph.lineAlpha = 0.5;
                graph.lineColor = "#FFFFFF";
                graph.topRadius = 1;
                graph.fillAlphas = 0.9;
                chart.addGraph(graph);

                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chartCursor.cursorAlpha = 0;
                chartCursor.zoomable = false;
                chartCursor.categoryBalloonEnabled = false;
                chartCursor.valueLineEnabled = true;
                chartCursor.valueLineBalloonEnabled = true;
                chartCursor.valueLineAlpha = 1;
                chart.addChartCursor(chartCursor);

                chart.creditsPosition = "top-right";

                // WRITE
                chart.write("chartdiv");
            });
        </script>
    </head>

    <body>
        <h1 style="color:green">YEARLY GRAPH </h1>
        <div id="chartdiv" style="width: 100%; height: 400px;"></div>
    </body>

    <form method="post">



    </form>

</html>