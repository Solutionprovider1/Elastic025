<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
  $month = $database->test_input($_GET['txtMonth']);
  $year = $database->test_input($_GET['txtYear']);
?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
</head>
<?php include("../includes/header.php");?>
<div class="wrapper wrapper-content">
        <div class="row">
         <h2>Welcome, <?php echo ucwords(strtolower($myData['fullname']));?></h2>
         <div class="row">
        <link rel="stylesheet" href="style.css" type="text/css">
        <script src="../amcharts/amcharts.js" type="text/javascript"></script>
        <script src="../amcharts/serial.js" type="text/javascript"></script>

        <script>
            var chart;

            var chartData = [
            <?php

                $ranking = $database->getMonthlyOrderCollectedRanking2($month,$year);
                $n = 1;
                foreach ($ranking as $rank) {

            ?>

        {
            "country": "<?php echo $rank['admin'];?>",
            "visits":"<?php echo $rank['totalAmount'];?>",
            "color":"<?php $rand = dechex(rand(0x000000, 0xFFFFFF)); echo('#' . $rand);?>"
        },
        <?php }?>



            ];


            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "country";
                chart.startDuration = 1;
                chart.depth3D = 50;
                chart.angle = 30;
                chart.marginRight = -45;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.gridAlpha = 0;
                categoryAxis.axisAlpha = 0;
                categoryAxis.gridPosition = "start";

                // value
                var valueAxis = new AmCharts.ValueAxis();
                valueAxis.axisAlpha = 0;
                valueAxis.gridAlpha = 0;
                chart.addValueAxis(valueAxis);

                // GRAPH
                var graph = new AmCharts.AmGraph();
                graph.valueField = "visits";
                graph.colorField = "color";
                graph.balloonText = "<b>[[category]]: [[value]]</b>";
                graph.type = "column";
                graph.lineAlpha = 0.5;
                graph.lineColor = "#FFFFFF";
                graph.topRadius = 1;
                graph.fillAlphas = 0.9;
                chart.addGraph(graph);

                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chartCursor.cursorAlpha = 0;
                chartCursor.zoomable = false;
                chartCursor.categoryBalloonEnabled = false;
                chartCursor.valueLineEnabled = true;
                chartCursor.valueLineBalloonEnabled = true;
                chartCursor.valueLineAlpha = 1;
                chart.addChartCursor(chartCursor);

                chart.creditsPosition = "top-right";

                // WRITE
                chart.write("chartdiv");
            });
        </script>
    </head>

    <body>
        <h1 style="text-align: center">Sales Performance for <?php echo  date('F', mktime(0, 0, 0, $month, 10)).", ".$year;?></h1>
        <div id="chartdiv" style="width: 100%; height: 400px;"></div>
    </body>

    <form method="get">

            <div class="row">
                <div class="col-md-2"><label>&nbsp;</label></div>

                <div class="col-md-3"><select name="txtMonth" class="form-control" id="">
                    <?php for ($i=1; $i < 13; $i++) {?>
                                <option value="<?php echo $i;?>" <?php if(isset($_GET['txtMonth']) && ($_GET['txtMonth'] == $i) ){echo "selected";}?>> <?php echo strtoupper(date('F', mktime(0, 0, 0, $i, 10))); ?>   </option>
                    <?php  }?>
                    <option></option>
                </select></div>


                <div class="col-md-2"><select name="txtYear" class="form-control" id="">
                    <?php
                    $yr = date("Y");
                            for ($i=$yr; $i > $yr - 2; $i--) {?>
                                <option value="<?php echo $i;?>" <?php if(isset($_GET['txtYear']) && ($_GET['txtYear'] == $i) ){echo "selected";}?>> <?php echo $i; ?>   </option>
                    <?php  }?>
                    <option></option>
                </select>
            </div>
                <div class="col-md-3"><input type="submit" name="Submit" value="VIEW" class="btn btn-success col-md-12" /></div>
            </div>

    </form>
</div>
</div>

</html>