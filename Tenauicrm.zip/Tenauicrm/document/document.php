<?php
  include("../data/DBConfig.php");
  //include_once("../data/sessioncheck.php");
//getLeadID=$1&getDemandID=$2&vat=$3&sof=$4
$getLeadID ="";
$getDemandID = "";
$vat = 0;
$sof = 1;
if(isset($_GET['getLeadID'])){$getLeadID = $_GET['getLeadID'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['getDemandID'])){$getDemandID = $_GET['getDemandID'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['vat'])){$vat = $_GET['vat'];}
if(isset($_GET['sof'])){$sof = $_GET['sof'];}

$leadData = $database->getLeadData($getLeadID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}
$salesorder = (array)$database->getLeadProductOrderOnLeadDemand($leadData['id'],$getDemandID);


?>

<!DOCTYPE html>
<html>
<head>
<title>Tenaui Africa | We speak by Image</title>
    <style>
        *
        {
            margin:0;
            padding:0;
            font-family:Arial;
            font-size:10pt;
            color:#000;
        }
        body
        {
            width:100%;
            font-family:Arial;
            font-size:10pt;
            margin:0;
            padding:0;
        }
         
        p
        {
            margin:0;
            padding:0;
        }
         
        #wrapper
        {
            width:180mm;
            margin:0 10mm;
        }
         
        .page
        {
            height:297mm;
            width:210mm;
            page-break-after:always;
        }
 
        table
        {
            border-left: 1px solid #ccc;
            border-top: 1px solid #ccc;
             
            border-spacing:0;
            border-collapse: collapse; 
             
        }
         
        table td 
        {
            border-right: 1px solid #ccc;
            border-bottom: 1px solid #ccc;
            padding: 2mm;
        }
         
        table.heading
        {
            height:40mm;
        }
         
        h1.heading
        {
            font-size:12pt;
            color:#000;
            font-weight:normal;
        }
         
        h2.heading
        {
            font-size:9pt;
            color:#000;
            font-weight:normal;
        }
         
        hr
        {
            color:#ccc;
            background:#ccc;
        }
         
        #invoice_body
        {
            height: 100mm;
        }
         
        #invoice_body , #invoice_total
        {   
            width:100%;
        }
        #invoice_body table , #invoice_total table
        {
            width:100%;
            border-left: 1px solid #ccc;
            border-top: 1px solid #ccc;
     
            border-spacing:0;
            border-collapse: collapse; 
             
            margin-top:3mm;
        }
         
        #invoice_body table td , #invoice_total table td
        {
            text-align:center;
            font-size:9pt;
            border-right: 1px solid #ccc;
            border-bottom: 1px solid #ccc;
            padding:2mm 0;
        }
         
        #invoice_body table td.mono  , #invoice_total table td.mono
        {
            font-family:monospace;
            text-align:right;
            padding-right:3mm;
            font-size:10pt;
        }
        #invoice_body table td.mono_  , #invoice_total table td.mono_
        {
            
            text-align:right;
            padding-right:3mm;
            font-size:10pt;
        }
         
        #footer
        {   
            width:180mm;
            margin:0 15mm;
            padding-bottom:3mm;
        }
        #footer table
        {
            width:100%;
            border-left: 1px solid #ccc;
            border-top: 1px solid #ccc;
             
            background:#eee;
             
            border-spacing:0;
            border-collapse: collapse; 
        }
        #footer table td
        {
            width:25%;
            text-align:center;
            font-size:9pt;
            border-right: 1px solid #ccc;
            border-bottom: 1px solid #ccc;
        }
    </style>
</head>
<body>
<div id="wrapper">
     
    <p style="text-align:center; font-weight:bold; padding-top:5mm;"><?php if($sof == 1){?>SALES ORDER FORM<?php }else{?>PRO FORMA INVOICE<?php }?></p>
    <br />
    <table class="heading" style="width:100%; font-size:small">
        <tr>
            <td height="168" style="width:80mm;">
                <h1 class="heading"><img src="../img/tenaui-logo.jpg" width="100" height="100"></h1>
                <h1 class="heading">TENAUI AFRICA LTD. </h1>
                <h2 class="heading">
                    51, Allen Avenue, Ikeja,<br />
                    Lagos Nigeria<br />
                    Phone: 09072574405, 08023553203<br />
                    Website : www.tenauiafrica.com<br />
                    <strong> Prepared by: <?php echo $leadData['admin'];?></strong>
                </h2>
          </td>
            <td valign="top" align="right" style="padding:3mm;">
            <h6><?php if($sof == 1){ echo 'SOF';}else{echo 'PFI';} ?> No.: <?php echo $salesorder[0]['ticketNo'];?></h6>

                <b>BUYER</b> :<br />
 <h1 class="heading"><?php  
                                                $comp = strtoupper($leadData['companyName']);
                                                echo wordwrap($comp, 50, "<br />\n");
                                        ?></h1>
<?php 
                                        $address = $leadData['address'].", ". $leadData['areaname'];
                                        echo $address;//wordwrap($address, 50, "<br />\n");
                                        ?><br>
                                        <?php echo $leadData['lga'];?> L.G.A<br/>
                                        <?php echo $leadData['state'];?>, <?php echo $leadData['country'];?> <br />
<strong>Contact Person:</strong> &nbsp;<?php echo $leadData['fullname'];?><br/>
<strong>Contact Phone No.:</strong>&nbsp;<?php echo $leadData['phoneNo'];?><br/>
<strong>Contact Email:</strong> &nbsp; <?php echo $leadData['email'];?><br/>
<strong>Invoice Date: </strong><?php  if($sof == 1){echo $salesorder[0]['orderCollectedDate'];}else{echo date("d-M-Y");}?><br/>

<strong>SALES TYPE :</strong> <?php echo $salesorder[0]['salestype'];?><br/>
<strong>PROMO CODE :</strong><?php echo $salesorder[0]['promocode'];?><br/>
<strong>PAYMENT MODE :</strong><?php echo $salesorder[0]['paymentmode'];?>
</td>
        </tr>
        
    </table>
         
         
    <div id="content">
         
        <div id="invoice_body">
            <table>
            <tr style="background:#eee;">
                <td style="width:5%;"><b>S/N.</b></td>
                <td><b>Item</b></td>
                <td style="width:20%;"><b>Code</b></td>
                <td style="width:8%;"><b>Qty</b></td>
                <td style="width:15%;"><b>Unit</b></td>
                <td style="width:15%;"><b>Total</b></td>
            </tr>
            <?php 
                    $n = 1;
                    $amounted = 0;
                    foreach ($salesorder as $order) {                                          
              ?>
            <tr>
                <td style="width:3%;"><b><?php echo $n;?></b></td>
                <td><b><?php echo $order['productName'];?><?php if($order['ProductType']>1){echo " - ".$order['color'];}?></b></td>
                <td style="width:15%;"><b><?php echo $order['Code'];?></b></td>
                <td class="mono" style="width:5%;"><b><?php echo $order['qty'];?></b></td>
                <td class="mono_" style="width:17%;"><b><?php echo $database->convertToMoney2($order['Amount']);?></b></td>
                <td class="mono_" style="width:18%;"><b>
                                        <?php 
                                        $amount_ = $order['qty'] * $order['Amount'];
                                        echo $database->convertToMoney2($amount_);
                                        ?>
                                            
                                        </b></td>
            </tr>
            <?php $n++; $amounted += $amount_;}?>
           <!-- <tr>
                <td style="width:8%;">1</td>
                <td style="text-align:left; padding-left:10px;">Software Development<br />Description : Upgradation of telecrm</td>
                <td class="mono" style="width:15%;">1</td><td style="width:15%;" class="mono">157.00</td>
                <td style="width:15%;" class="mono">157.00</td>
            </tr> --> 
             
            <tr>
                <td colspan="4"></td>
                <td>Sub Total :</td>
                <td class="mono_"><?php
                                    //getLeadID=$1&getDemandID=$2&vat=$3&sof=$4
                                    $sub_total =$amounted;

                                     echo  $database->convertToMoney2($sub_total);?></td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td><strong><?php if($vat == 1){echo "VAT (5%)";}else{ echo "NO VAT";}?> :</strong></td>
                                    <td><?php
                                    $vat_ = 0; 
                                    if($vat ==1){
                                            $vat_ = 0.05 * $sub_total;
                                        }
                                    echo $database->convertToMoney2($vat_);?></td>
            </tr>
            
        </table>
        </div>
        <div id="invoice_total">
            
            <table>
                <tr>
                <?php 
                                    $Total = $sub_total + $vat_;?>
                 <td style="width:15%;">Total Amount :</td>
                    <td style="text-align:left; padding-left:10px;"><?php echo ucwords(strtolower($database->convert_number_to_words($Total)));?> Naira Only</td>
                   
                    <td style="width:20%;" class="mono_">

                                  <?php echo $database->convertToMoney2($Total);?></td>
                </tr>
            </table>
        </div>
      <hr/>
      <?php if($sof == 1){?>
      <table style="width:100%; height:35mm;">
      <tr>
      
          <td width="33%"><strong>BUSINESS CONTROLLER</strong></td>
          <td width="33%"><strong>BUSINESS HEAD</strong></td>
          <td width="33%"><strong>MANAGEMENT</strong></td>

      </tr>
      <tr>
      
          <td width="33%">&nbsp;</td>
          <td width="33%">&nbsp;</td>
          <td width="33%">&nbsp;</td>

      </tr>


      </table>

      <?php }else{?>
        <table style="width:100%; height:35mm;">
            <tr>
                <td style="width:55%;" valign="top">
                    <div align="center"><strong>SPECIAL NOTES AND TERMS OF SALES :</strong>
                    </div>
                    <table width="100%" border="0" style="font-size:9px;">
  <tr>
    <td>VALIDITY:</td>
    <td>All Prices are valid for 4 weeks and subject to change withoutprior notice </td>
  </tr>
  <tr>
    <td>PAYMENT TERMS </td>
    <td>100% ADVANCE </td>
  </tr>
  <tr>
    <td>DELIVERY TERMS </td>
    <td>Delivery prior to confirmation of payment </td>
  </tr>
  <tr>
    <td>SALES TAX </td>
    <td>Total Amount Inclusive V.A.T </td>
  </tr>
</table>
                    <div align="center">Any information regarding this pro forma invoice please contact <strong><?php echo $leadData['admin'];?> on <?php echo $leadData['adminPhone'];?>
                       
              </strong></div></td>
                <td>
                  <div align="center"><strong>ACCOUNT NAME : TENAUI AFRICA LTD.</strong></div>
                  <table width="105%" border="0" style="font-size:9px;">
  <tr>
    <td width="58%">DIAMOND BANK </td>
    <td width="42%">004036839</td>
  </tr>
  
  <tr>
    <td>GTBANK</td>
    <td>0139423438</td>
  </tr>
  
 
</table>
              </td>
            </tr>
        </table><?php }?>
    </div>
     
    <br />
     
    </div>
     
  
     
</body>
</html>