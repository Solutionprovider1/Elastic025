<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
</head>
<script src="<?php echo $host;?>js/jquery.min.js"></script>
<?php include("../includes/header.php");?>

<script type="text/javascript">
var parent = <?php echo $database->getArrayStates();?>;
var child = <?php echo $database->getLGAofStates();?>;
var gchild = <?php echo $database->getAreasofLGA();?>;
    function LoadChild(){
        var i = document.getElementById("parent").selectedIndex ;
       // var dp = document.getElementById("child");
        var dp2 = document.getElementById("gchild");
      //  var count = child[i-1].length;
        var count2 = gchild[i-1].length;

        //var html = "<option value=\"\" disabled selected hidden>- select -</option>";
       // for(var k = 0 ; k < count ; k ++){
       //     html += "<option value=\""+child[i-1][k][0]+"\">"+child[i-1][k][1]+"</option>";
       // }

        var html2 = "<option value=\"\" disabled selected hidden>- select -</option>";
        for(var k = 0 ; k < count2 ; k ++){
            html2 += "<option value=\""+gchild[i-1][k][0]+"\">"+gchild[i-1][k][1]+"</option>";
        }
        
       // dp.innerHTML = html;
        dp2.innerHTML = html2;
    }
    
</script>

<?php 
$productsName = "";
       $products = (array)$database->getAllProducts();
                                        foreach ($products as $dpt) {
                                            $value = "";
                                            if($dpt['ProductType'] == 1){
                                                $value = $dpt['productName'];
                                            }else if($dpt['ProductType'] == 2 || $dpt['ProductType'] == 3){
                                                $value = $dpt['productName'].' - '.$dpt['color'];
                                            }
                                            else if($dpt['ProductType'] == 4){
                                                $value = $dpt['productName'].' - '.$dpt['Code'];
                                            }
                                       
                                         $productsName.='<option value="'. $dpt['id'].'">'. $value.'</option>';
                                         }

                                         ?>



<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Create your Lead</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Create Lead</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">
               

                </div>
            </div>

  <div class="wrapper wrapper-content">
  <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        

                        <?php 
                        $err = "";
                        $msg = "";
                       
                        		if(isset($_POST['btnCreateLead'])){
                        			$name = $database->test_input($_POST['txtFname'])." ".$database->test_input($_POST['txtLname']);
                                    $phone = $database->test_input($_POST['txtPhone']);
                                    $email = $database->test_input($_POST['txtEmail']);
                                    $country = $database->test_input($_POST['txtCountry']);
                                    $city = $database->test_input($_POST['txtState']);
                                    $address = $database->test_input($_POST['txtAdd']);
                                    $companyName = $database->test_input($_POST['txtCompany']);
                                    $designation = $database->test_input($_POST['txtDesignate']);
                                    $rDate = $database->test_input($_POST['txtRDate']);
                                    $ecDate = $database->test_input($_POST['txtECDate']);
                                    $salesStage = $database->test_input($_POST['txtSalesStage']);
                                    $LeadSource = $database->test_input($_POST['txtleadSource']);
                                    $assign = $database->test_input($_POST['txtStaff']);
                                    $description = $database->test_input($_POST['txtDescription']);
                                    $areaID = $database->test_input($_POST['txtAreaID']);
                                    $product=$qty=$amount=array();
                                    if(isset($_POST['txtProduct'])){
                                        $product = $_POST['txtProduct'];
                                        $qty = $_POST['txtProductQty'];
                                        $amount = $_POST['txtProductAmount'];
                                    }


                                    if($name!= "" && $phone != "" && $assign != "" && $companyName!= "" && $designation != "" && $areaID!= ""){

                                        if($database->ValidateCompany($companyName)){
                                            $err = "This company Name has been registered previously";
                                        }else{
                                            $database->addNewLead($name,$phone,$email,$country,$city,$address,$companyName,$designation,$rDate,$ecDate,$salesStage,$LeadSource,$assign,$description,$areaID,$product,$qty,$amount);
                                            $msg = "your lead has been created successfully!.";
                                           // $_POST['txtFname']="";
                                            unset($_POST);

                                        }                                      
                                    
                                    }else{
                                            if($name == ""){$err.="<li>please enter name</li>";}
                                            if($phone == ""){$err.="<li>please enter phone number</li>";}
                                            if($assign == ""){$err.="<li>please assign this lead to a sales person</li>";}
                                            if($companyName == ""){$err.="<li>please enter the company name</li>";}
                                            if($designation == ""){$err.="<li>please enter the contact person designation</li>";}
                                            if($rDate == ""){$err.="<li>please enter Revisit date</li>";}
                                            //if($description == ""){$err.="<li>please describe this lead</li>";}
                                            if($areaID == ""){$err.="<li>please select the area</li>";}
                                    }
                        		
                                }

                        ?>

                        <div class="ibox-content">
                            <form method="post" name="lead-registration" class="form-horizontal">

                             <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	<?php if($err!= ""){$database->showMsg('Error',$err,1);}
                                    	 else if($msg!=""){$database->showMsg('Success',$msg,2);}?>
                                    </div>
                                </div>
                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Sales Stage</label>
                                   <div class="col-sm-3">
                                       <select class="form-control m-b" name="txtSalesStage">
                                     <?php 
                                        $dpts = (array)$database->getSalesStages();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if(isset($_POST['txtSalesStage']) && $dpt['percentage'] ==$_POST['txtSalesStage']){ ?>
                                             <option value="<?php echo $dpt['percentage'];?>" <?php echo "selected";?>><?php echo $dpt['stage'];?></option>
                                            <?php }else{ ?>
                                            <option value="<?php echo $dpt['percentage'];?>"><?php echo $dpt['stage'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select>   
                                       
                                    </div>
                                     <label class="col-sm-1 control-label">LeadSource</label>
                                   <div class="col-sm-2">
                                    <select class="form-control m-b" name="txtleadSource">
                                         <?php 
                                        $dpts = (array)$database->getLeadSource();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if( isset($_POST['txtleadSource']) && $dpt['source'] ==$_POST['txtleadSource']){ ?>
                                             <option <?php echo "selected";?>><?php echo $dpt['source'];?></option>
                                            <?php }else{ ?>
                                            <option><?php echo $dpt['source'];?></option>
                                        <?php }}?>
                                        </select>
                                       
                                    </div>

                                     <label class="col-sm-1 control-label">Assigned  </label>
                                   <div class="col-sm-3">
                                    <select class="form-control m-b" name="txtStaff">
                                         <?php 
                                         if ($myData['dptaccessLevel'] <2){?>
                                         <option <?php echo "selected";?> value="<?php echo $myData['id'];?>">
                                          <?php echo $myData['fullname'];?></option>

                                        <?php
                                         }else{
                                        $stf = (array)$database->getAllStaffByDptID(1);
                                        foreach ($stf as $stfs) {?>
                                        
                                        <?php if(isset($_POST['txtStaff']) && $stfs['id'] ==$_POST['txtStaff']){ ?>
                                             <option <?php echo "selected";?> value="<?php echo $stfs['id'];?>">
                                             <?php echo $stfs['fullname'];?></option>
                                             <?php } else if($myData['id'] == $stfs['id']){ ?>
                                            <option <?php echo "selected";?> value="<?php echo $stfs['id'];?>"><?php echo $stfs['fullname'];?></option>
                                      
                                            <?php }else{ ?>
                                            <option value="<?php echo $stfs['id'];?>"><?php echo $stfs['fullname'];?></option>
                                        <?php }}}?>
                                        </select>
                                       
                                    </div>
                                </div>

 <div class="form-group">
                                <label class="col-sm-2 control-label">Company Name</label>
                                   <div class="col-sm-10">
                                        <input name="txtCompany" value="<?php if(isset($_POST['txtCompany'])){echo $_POST['txtCompany'];}?>" type="text" placeholder="Enter company Name" required class="form-control required">
                                       
                                    </div>
                                    
                                </div>
<div class="form-group">
                                <label class="col-sm-2 control-label">Country</label>
                                   <div class="col-sm-2">
                                       <select class="form-control m-b" name="txtCountry">
                                     <?php 
                                        $dpts = (array)$database->getAllCountries();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if($dpt['name'] =='Nigeria'){ ?>
                                             <option <?php echo "selected";?>><?php echo $dpt['name'];?></option>
                                            <?php }else{ ?>
                                            <option><?php echo $dpt['name'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select>    
                                    </div>
                                     <label class="col-sm-1 control-label">State</label>
                                   <div class="col-sm-2">
                                   
                                       <select class="form-control m-b" id="parent" name="txtState" onChange="LoadChild();" required data-validation-required-message="State is required">
                                        <option value="" disabled selected hidden>- select -</option>
                                        <script type="text/javascript">
                                            for(var i = 0 ; i < parent.length ; i ++){
                                                document.write('<option value="'+parent[i][0]+'">'+parent[i][1]+'</option>');
                                            }
                                        </script>
                                        
                                    </select>

                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">Area</label>
                                     <div class="col-sm-4">
                                   <select class="form-control m-b" name="txtAreaID" required data-validation-required-message="area is required" id="gchild" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>
                                </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Address</label>
                                   <div class="col-sm-10">
                                        <input name="txtAdd" value="<?php if(isset($_POST['txtAdd'])){echo $_POST['txtAdd'];}?>" type="text" class="form-control required" required placeholder="Enter company address with area. Eg: 14, shogunle street, oshodi">
                                       
                                    </div>
                                </div>
                                
                            <div class="hr-line-dashed"></div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">First Name</label>
                                    <div class="col-sm-4">
                                    	<input type="text" value="<?php if(isset($_POST['txtFname'])){echo $_POST['txtFname'];}?>" 
                                        name="txtFname" placeholder="Enter contact person firstname"
                                    	 required class="form-control">
                                    </div>

                                     <label class="col-sm-2 control-label">Last Name</label>
                                    <div class="col-sm-4">
                                        <input type="text" value="<?php if(isset($_POST['txtLname'])){echo $_POST['txtLname'];}?>" name="txtLname" placeholder="Enter contact person lastname"
                                         class="form-control">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                <label class="col-sm-2 control-label">Phone No.</label>
                                   <div class="col-sm-4">
                                        <input type="text" value="<?php if(isset($_POST['txtPhone'])){echo $_POST['txtPhone'];}?>" name="txtPhone" class="form-control" placeholder="Enter contact person Phone number" onKeyPress="return isNumberKey(event)" maxlength="11"  required>
                                    </div>
                                    <label class="col-sm-2 control-label">Email Address</label>
                                   <div class="col-sm-4">
                                        <input type="email" id="txtEmail" value="<?php if(isset($_POST['txtEmail'])){echo $_POST['txtEmail'];}?>" name="txtEmail" placeholder="Enter contact person email address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                 <label class="col-sm-2 control-label">Designation</label>
                                   <div class="col-sm-4">
                                        <input name="txtDesignate" value="<?php if(isset($_POST['txtDesignate'])){echo $_POST['txtDesignate'];}?>" type="text" required class="form-control" placeholder="Enter contact person Designation">
                                       
                                    </div>
                                    </div>

                                
                             <div class="hr-line-dashed"></div>

                            
                          

                                  <div class="form-group" id="data_2">
                                <label class="col-sm-2 control-label">Revisit Date</label>
                                   <div class="col-sm-4">
                                              <div class="input-group date">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input name="txtRDate" type="text" class="form-control" value="<?php if(isset($_POST['txtRDate'])){echo $_POST['txtRDate'];}?>" required readonly required>
                                                 </div> 
                                       
                                    </div>
                                     <label class="col-sm-2 control-label">Expected Close Date</label>
                                   <div class="col-sm-4">
                                            <div class="input-group date">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input name="txtECDate" type="text" class="form-control" value="<?php if(isset($_POST['txtECDate'])){echo $_POST['txtECDate'];}?>" readonly>
                                            </div>
                                       
                                    </div>
                                </div>


                                  
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-8"></label><button class="add_field_button col-sm-4 btn btn-warning"><i class="fa fa-plus"></i>&nbsp; Add Products</button></div>
                                    
                             <div  class="input_fields_wrap">     
                            <?php 
                                if(isset($_POST['txtProduct'])){
                                    $count = count($_POST['txtProduct']);
                            for($i = 0; $i<$count; $i++){?>
                            <div class="form-group" id="data_2" ng-app>
                            <label class="col-sm-2 control-label">Products :</label>
                                   <div class="col-sm-3">
                                    <select class="form-control m-b" name="txtProduct[]">
                                     <?php 
                                        $dpts = (array)$database->getAllProducts();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if(isset($_POST['txtProduct[$i]']) && $dpt['id'] ==$_POST['txtProduct[$i]']){ ?>
                                             <option value="<?php echo $dpt['id'];?>" <?php echo "selected";?>><?php echo $dpt['productName'];?></option>
                                            <?php }else{ ?>
                                            <option value="<?php echo $dpt['id'];?>"><?php echo $dpt['productName'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select>   
                                      <!-- <input type="text" placeholder="Products name..." name="txtProduct[]" value="<?php if(isset($_POST['txtProduct[$i]'])){echo $_POST['txtProduct[$i]'];}?>"
                                       data-provide="typeahead" data-source='["item 1","item 2","item 3"]' class="form-control" />-->
                                       </div>
                                        <label class="col-sm-1 control-label">Qty</label>
                                   <div class="col-sm-1">
                                       <input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" name="txtProductQty[]" class="form-control" value="1" />
                                       </div>
                                        <label class="col-sm-1 control-label">Amount</label>
                                   <div class="col-sm-2">

                                       <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtProductAmount[]" class="form-control" onkeyup = "javascript:this.value=Comma

(this.value);" required />
                                       </div>
                                      <a href="#" class="remove_field"><label class="col-sm-1 control-label">Remove</label></a>

                                </div>

                           <?php }} ?>
                          
                                        


                                    </div>
                          
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Description</label>
                                   <div class="col-sm-10">
                                   <textarea class="form-control" name="txtDescription" placeholder="Describe this lead" ><?php if(isset($_POST['txtDescription'])){echo $_POST['txtDescription'];}?></textarea>
                                    </div>
                                    
                                </div>

							<div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	 <button name="btnCreateLead" class="btn btn-primary col-lg-12" type="submit">
                                         <i class="fa fa-user"></i>&nbsp;Create Lead</button>
                           
                                    </div>
                                </div>
                                </form>

                               
                                
                       
<script>
    
    $(document).ready(function() {
    var max_fields      = 15; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="form-group"><label class="col-sm-2 control-label">Products :</label>'+
            '<div class="col-sm-3"><select class="form-control m-b" id="field_'+ x +'" name="txtProduct[]"><?php echo  $productsName;?> </select></div>'+
            '<label class="col-sm-1 control-label">Qty</label>'+
            '<div class="col-sm-1"><input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" id="field_'+ x +'" name="txtProductQty[]" class="form-control required" value="1" /></div>'+
            '<label class="col-sm-1 control-label">Amount</label>'+
            '<div class="col-sm-2"><input type="text"  onKeyPress="return isNumberKey(event)" onkeyup = "javascript:this.value=Comma'+'(this.value);" placeholder="AMOUNT" id="field_'+ x +'" value="0" name="txtProductAmount[]" class="form-control required" /></div>'+
            '<a href="#" class="remove_field"><label class="col-sm-1 control-label">Remove</label></a></div>'); //add input box

        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});

</script>

 
  </div>
  
  <?php include("../includes/js.php");?>
  <script type="text/javascript">
     $('#trucated').inputmask("numeric", {
    radixPoint: ".",
    groupSeparator: ",",
    digits: 2,
    autoGroup: true,
    prefix: 'N', //No Space, this will truncate the first character
    rightAlign: false,
   oncleared: function(){self.Value('');}
   });
    
  </script>
