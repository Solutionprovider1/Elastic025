<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");

   $events = (array)$database->getLeadRevisitDates();
             $n = 0;
                foreach ($events as $event) { 

                  $cat = $event['rDate'];
                  $cat = explode("/", $cat);
                  $d = $cat[0];
                  $m = $cat[1];
                  $y = $cat[2];

                  $dateMax = $y."".$m."".$d;
                  $database->updateDateStamp($event['id'],$dateMax);  
                }
?>