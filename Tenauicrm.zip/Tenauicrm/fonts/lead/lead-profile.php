<?php
include("../data/DBConfig.php");
include_once("../data/sessioncheck.php");
$getID ="";
$getOrder = 0;

if(isset($_GET['id'])){$getID = $_GET['id'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['g'])){$getOrder = $_GET['g'];}
$leadDemandID_ = $getOrder;
$leadData = $database->getLeadData($getID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}
if(isset($_POST['btncollectOrder'])){
    $dDay = $_POST['txtDay'];
    $dMonth = $_POST['txtMonth'];
    $dYear = $_POST['txtYear'];
    $dateFormat = date_create($dDay."-".$dMonth."-".$dYear);
    $oDate=date_format($dateFormat,"l jS \of F Y");
    $database->updateOrderCollected($leadDemandID_,$getID,$oDate,$dDay,$dMonth,$dYear);
}
?><?php 
        $err = "";$msg = "";
        if(isset($_POST['btnNewMachine'])){
            $leadID = $getID;
            $leadDemandID = $getOrder;
                                    $productID = $database->test_input($_POST['txtProduct']);
                                    $qty = $database->test_input($_POST['txtQty']);
                                    $rentalcharge = $database->test_input($_POST['txtRentalCharge']);
                                    $costMono = $database->test_input($_POST['txtCostMono']);
                                    $costColor = $database->test_input($_POST['txtCostColor']);
                                    $minVolMono = $database->test_input($_POST['txtVolMono']);
                                    $minVolColor = $database->test_input($_POST['txtVolColor']);
                                    $contractDuration = $database->test_input($_POST['txtContractDuration']);
                                    $BillingType = $database->test_input($_POST['txtBillingType']);
                                    $description =$database->test_input($_POST['txtDescription']);

                                    $accessories = "";
                                    if(isset($_POST['txtCC'])){
                                        if (is_array($_POST['txtCC'])) {
                                                foreach($_POST['txtCC'] as $value){
                                                  $accessories = $accessories.",".$value;
                                                }
                                            }else {
                                                $value = $_POST['txtCC'];
                                                $accessories =  $value;
                                              }
                                        }



                                    

                                 if($leadID!= "" && $productID != "" && $qty != "" && $rentalcharge!= "" && $costMono != "" 
                                    && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $contractDuration !="" && $BillingType != ""){
                                        $database->AddMPFTicketMachine($leadDemandID,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories);
                                       
                                            $msg = "your lead MPS ticket has been created successfully!.";
                                           // $_POST['txtFname']="";
                                           // echo $msg;
                                            unset($_POST);

                                                                          
                                    
                                    }else{
                                           if($productID == ""){$err.="<li>please select product</li>";}
                                            if($qty == ""){$err.="<li>please enter quantity of product</li>";}
                                            if($rentalcharge == ""){$err.="<li>please enter rental charge</li>";}
                                            if($costMono == ""){$err.="<li>please enter the cost of printing Mono</li>";}
                                            if($costColor == ""){$err.="<li>please enter the cost of printing Color</li>";}
                                            if($minVolColor == ""){$err.="<li>please enter the minimum printing Mono</li>";}
                                            if($minVolMono == ""){$err.="<li>please enter the minimum printing Color</li>";}
                                            if($contractDuration == ""){$err.="<li>please select the Contract duration</li>";}
                                            if($BillingType == ""){$err.="<li>please select the Billing type</li>";}
                                    }
                                
                                }
       

?>


<?php 
    $productsName = "";
       $products = (array)$database->getAllProducts();
        foreach ($products as $dpt) {
            if($dpt['ProductType'] == 2){break;}
            $value = "";
            if($dpt['ProductType'] == 1){
                $value = $dpt['productName'];
            }
       
         $productsName.='<option value="'. $dpt['id'].'">'. $value.'</option>';
         }
?>
<!DOCTYPE HTML>
<html>
    <head>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Tenaui+ :: CRM for Tenaui
            </title>
            <?php include("../includes/styles.php");?>
             <link href="<?php echo $host;?>css/plugins/dualListbox/bootstrap-duallistbox.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/select2/select2.min.css" rel="stylesheet">
    <script src="<?php echo $host;?>js/jquery.min.js"></script>
        </head>
        <?php include("../includes/header.php");?>
        <div class="row wrapper border-bottom white-bg page-heading">
            <?php
if($leadData['assigned'] != $myData['id'] && $myData['AccessLevel'] < 5){?>
            <div class="wrapper wrapper-content">
                <div class="middle-box text-center animated fadeInRightBig">
                    <h3 class="font-bold">Hello
                        <?php echo ucwords($myData['fullname']); ?>
                    </h3>
                    <div class="error-desc">
                        You are trying to access information of a lead that is not assigned to you.:) Click the button below to access your own leads.
                        <br/>
                        <a href="<?php echo $host;?>view-my-lead" class="btn btn-primary m-t">View My Leads
                        </a>
                    </div>
                </div>
            </div>
            <?php die(); } ?>
            <div class="col-lg-12">
                <h2>
                    <?php echo strtoupper($leadData['companyName']) ;?>
                </h2>
                <ol class="breadcrumb">
                    <li>
                        <?php echo $leadData['address'];?>,
                        <?php echo $leadData['areaname'];?>
                    </li>
                    <li class="active">
                        <strong>
                            <?php echo $leadData['lga'];?> L.G.A,
                            <?php echo ucwords(strtolower($leadData['state']));?>,
                            <?php echo $leadData['country'];?>.
                        </strong>
                    </li>
                    <li>
                        <?php echo $leadData['salesStage'];?>% &nbsp;
                        <span class="pie">
                            <?php echo $leadData['salesStage'];?>/100
                        </span>&nbsp;
                        <label class="label label-<?php echo $database->returnSalesStageColor($leadData['salesStage']);?>">
                            <?php echo $database->getSalesStage($leadData['salesStage']);?>
                        </label>
                    </li>
                    <li>Created on
                        <?php echo $leadData['dateTime'];?> /
                        <strong>
                            <?php echo $database->time_elapsed_string($leadData['timeStamp']);?>
                        </strong>
                    </li>
                </ol>
            </div>
        </div>
        <?php
$tickets = (array)$database->getLeadDemand($leadData['id']);
?>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-9">
                    <div class="ibox-content table-responsive">
                        <table class="table table-bordered table-stripped">
                            <tbody>
                                <tr>
                                    <td colspan="4">
                                        <b>Company Name :
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['companyName']) ;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <b>Company Address :
                                        </b> &nbsp;
                                        <?php echo $leadData['address'];?>,
                                        <?php echo $leadData['areaname'];?>,
                                        <?php echo $leadData['lga'];?> L.G.A,
                                        <?php echo ucwords(strtolower($leadData['state']));?>,
                                        <?php echo $leadData['country'];?>.
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <b>Contact Person :
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['fullname']) ;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <b>Phone:
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['phoneNo']) ;?>
                                    </td>
                                    <td colspan="2">
                                        <b>Designation:
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['designation']) ;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <b>Email:
                                        </b> &nbsp;
                                        <a href="mailto:<?php echo strtolower(($leadData['email'])) ;?>">
                                            <?php echo strtolower(($leadData['email'])) ;?>
                                        </a>
                                    </td>
                                    <td>
                                        <b>Assigned To:
                                        </b> &nbsp;
                                        <?php echo strtoupper(($leadData['admin'])) ;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <b>Reviste Date:
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['rDate']) ;?>
                                    </td>
                                    <td colspan="2">
                                        <b>Expected Close Date:
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['ecDate']) ;?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <b>Lead Description:
                                        </b> &nbsp;
                                        <?php echo strtoupper($leadData['description']) ;?>
                                    </td>
                                </tr>
                                <?php if($leadData['assigned'] == $myData['id'] || $myData['AccessLevel'] > 5){?>
                                <tr>
                                    <td colspan="4" style="text-align: center;">
                                        <!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal5">
<a href="<?php echo $host;?>invoice/<?php echo $leadData['id'];?>" class="btn btn-primary">
<i class="fa fa-envelope-open"></i>  Send Invoice Link
</a>
<!-- </button>-->
                                        <a href="<?php echo $host;?>edit-lead/<?php echo $leadData['id'];?>" class="btn btn-primary">
                                            <i class="fa fa-pencil">
                                            </i>&nbsp; Edit Lead Information
                                        </a>
                                    </td>
                                </tr>
                                <?php }?>
                                <?php if(isset($_GET['g'])){
                        $ticketInfo = $database->getLeadDemandWithID($leadDemandID_);
                        $salesorder = (array)$database->getLeadProductOrderOnLeadDemand($leadData['id'],$leadDemandID_);
                        $mpsorder = (array)$database->getLeadMPSOrderOnLeadDemand($leadData['id'],$leadDemandID_);
                    ?>
                                <tr>
                                    <td colspan="4">
                                        <h2 style="text-align: center;">
                                            <b>Ticket No:
                                            </b>&nbsp;
                                            <?php echo $ticketInfo['ticketNo'];?>
                                        </h2>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <h4 style="text-align: center;">
                                            <?php echo $database->getSalesType($ticketInfo['sales_type_id'])['salestype'];?>
                                        </h4>
                                    </td>
                                </tr>
                                <?php if($ticketInfo['sales_type_id'] == 1){?>
                                <tr>
                                    <td>
                                        <b>Quote Amount:
                                        </b> &nbsp;
                                        <?php echo $database->convertToMoney($database->getLeadQuoteAmountForDemand($leadData['id'],$leadDemandID_));?>
                                    </td>
                                    <td colspan="3">
                                        <b>Amount in words:
                                        </b> &nbsp;
                                        <?php echo strtoupper($database->convert_number_to_words($database->getLeadQuoteAmountForDemand($leadData['id'],$leadDemandID_)));?> NAIRA ONLY
                                    </td>
                                </tr>
                                <tr>
                                    <table class="table invoice-table">
                                        <thead>
                                            <?php if(isset($_GET['g'])){ ?>
                                            <tr>
                                                <td>
                                                </td>
                                                <?php if($leadData['assigned'] == $myData['id'] || $myData['AccessLevel'] > 5){?>
                                                <th colspan="5">
                                                    <?php
if(!empty($salesorder) && $salesorder[0]['orderCollect'] == 1){?>
                                                    <a href="" class="btn btn-default btn-rounded">
                                                        <i class="fa fa-handshake-o">
                                                        </i>&nbsp;Order-Completed!
                                                    </a>
                                                    <a href="<?php echo $host."invoice/".$leadData['id']."/".$leadDemandID_."/1/1";?>" class="btn btn-primary btn-rounded">
                                                        <i class="fa fa-calculator">
                                                        </i>&nbsp;Generate SOF
                                                    </a>
                                                    <a href="<?php echo $host."invoice/".$leadData['id']."/".$leadDemandID_."/0/1";?>" class="btn btn-primary btn-rounded">
                                                        <i class="fa fa-calculator">
                                                        </i>&nbsp;Generate SOF (No VAT)
                                                    </a>
                                                    <?php }else{ ?>
                                                    <button type="button" class="btn btn-warning btn-rounded" data-toggle="modal" data-target="#myModal5">
                                                        <i class="fa fa-handshake-o">
                                                        </i>&nbsp;Collect Order?
                                                    </button>
                                                    <a href="<?php echo $host."invoice/".$leadData['id']."/".$leadDemandID_."/1/0";?>"  class="btn btn-primary btn-rounded">
                                                        <i class="fa fa-file-powerpoint-o">
                                                        </i>&nbsp;Generate PFI
                                                        <span class="caret">
                                                        </span>
                                                    </a>
                                                    <a href="<?php echo $host."invoice/".$leadData['id']."/".$leadDemandID_."/0/0";?>"  class="btn btn-primary btn-rounded"><i class="fa fa-file-powerpoint-o"></i>&nbsp;Generate PFI (No VAT)<span class="caret"></span></a>
                                                    <a href="<?php echo $host;?>edit-lead-product/<?php echo $leadData['id'];?>/<?php echo $leadDemandID_;?>" class="btn btn-primary btn-rounded"><i class="fa fa-pencil"></i>&nbsp;Edit Product</a>
                                                    <?php }?>
                                                </th>
                                                <?php }?>
                                            </tr>
                                            <tr>
                                                <th></th>
                                                <th>Item List</th>
                                                <th>Code</th>
                                                <th>Qty</th>
                                                <th>Unit Price</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                        $n = 1;
                        $total_amount = 0;
                        foreach ($salesorder as $order) {
                        $img_value = "";
                        if($order['orderCollect'] == 0){$img_value = 'no';}
                      ?>
                                            <tr>
                                                <td>
                                                    <img src="<?php echo $host;?>img/<?php echo $img_value;?>collected.png" width='15' height='15'>
                                                </td>
                                                <td>
                                                    <div>
                                                        <strong>
                                                            <?php echo $order['productName'];?>
                                                            <?php if($order['ProductType']>1){echo " - ".$order['color'];}?>
                                                        </strong>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo $order['Code'];?>
                                                </td>
                                                <td>
                                                    <?php echo $order['qty'];?>
                                                </td>
                                                <td>
                                                    <?php echo $database->convertToMoney($order['Amount']);?>
                                                </td>
                                                <td>
                                                    <?php
$amount = $order['qty'] * $order['Amount'];
echo $database->convertToMoney($amount);?>
                                                </td>
                                            </tr>
                                            <?php $n++;
$total_amount += $amount;
}
?>
                                        </tbody>
                                    </table>
                                    <!-- /table-responsive -->
                                    <table class="table invoice-total">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <strong>TOTAL :
                                                    </strong>
                                                </td>
                                                <td>
                                                    <?php echo $database->convertToMoney($total_amount);?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <strong>
                                            <?php echo ucwords(strtolower($database->convert_number_to_words( $total_amount)));?> Naira Only
                                        </strong>
                                    </td>
                                </tr>

                                <?php }}else if($ticketInfo['sales_type_id'] == 2){
                                    $totalValue = 0;
                                ?>
                                <tr>
                                    <td colspan="4"><p style="text-align: right;">
                                    <?php if($ticketInfo['orderCollect'] == 0){?>
                                    <button type="button" class="btn btn-success btn-rounded" data-toggle="modal" data-target="#myModalStart"><i class="fa fa-calendar-check-o"></i> &nbsp;Start MPS</button>
                                   
                                     <button type="button" class="btn btn-success btn-rounded" data-toggle="modal" data-target="#myModalAddMPS"><i class="fa fa-plus"></i> &nbsp;Add Machine</button>
                                     <?php }?>
                                             

                                    <a href="<?php echo $host;?>ticket-2/<?php echo $ticketInfo['ticketNo'];?>/1" class="btn btn-primary btn-rounded">
                                    <i class="fa fa-file-powerpoint-o"></i>
                                    &nbsp;SOF</a></p></td>
                                    <?php $cduration = 0 ; $cBillType = ""; $cDes = "";?>
                                </tr>


                                <?php
                                 foreach($mpsorder as $mpsorders){
                                    $cduration = $mpsorders['contract_duration'];
                                    $cBillType = $mpsorders['billingType'];
                                    $cDes = $mpsorders['description'];
                                ?>
                                <tr>
                                    <td><b>PRODUCT</b></td>
                                    <td><?php echo $mpsorders['productName'];?></td>
                                     <td><b>CODE</b></td>
                                    <td><?php echo $mpsorders['Code'];?></td>
                                </tr>
                                <tr>
                                    <td colspan="1"><b>RENT</b>: <?php echo $database->convertToMoney($mpsorders['rentalCharge']);?></td>
                                    <td><b>QTY</b>: <?php echo strtoupper($database->convert_number_to_words($mpsorders['product_qty']));?> MACHINE(S)</td>
                                     <td><b>TOTAL RENT PRICE</b></td> 
                                     <td><?php $totalRent =  $mpsorders['rentalCharge']*$mpsorders['product_qty'];echo $database->convertToMoney($totalRent);?></td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                    <b>ACCESSORIES</b>: 
                                        <?php
                                          $cat = $mpsorders['accesories'];
                                          $cat = explode(",", $cat);
                                           foreach($cat as $cats){
                                              echo " - ".$database->getProductInformationWithID($cats)['productName'];
                                         

                                          }?>
                                    </td>

                                </tr>
                                <tr>
                                    <td> <b>COST-MONO</b>: <?php echo $database->convertToMoney($mpsorders['cost_mono']);?></td>

                                    <td><b>MIN-VOL-MONO</b>: <?php echo $mpsorders['min_vol_mono'];?></td>
                                    <td><b>UNIT</b>: 
                                    <?php
                                    $unitMono = $mpsorders['cost_mono'] * $mpsorders['min_vol_mono'];

                                     echo $database->convertToMoney($unitMono);?></td>
                                    <td><b>TOTAL-M</b>: <?php $totalMono = $mpsorders['product_qty']*$unitMono; echo $database->convertToMoney($totalMono);?></td>

                                </tr>
                                 <tr>
                                    <td> <b>COST-COLOR</b>: <?php echo $database->convertToMoney($mpsorders['cost_color']);?></td>

                                    <td><b>MIN-VOL-COLOR</b>: <?php echo $mpsorders['min_vol_color'];?></td>
                                    <td><b>UNIT</b>: <?php 
                                    $unitColor = $mpsorders['cost_color'] * $mpsorders['min_vol_color'];
                                    echo $database->convertToMoney($unitColor);?></td>
                                    <td><b>TOTAL-C</b>: <?php $totalColor = $mpsorders['product_qty']*$unitColor; 
                                    echo $database->convertToMoney($totalColor);?></td>

                                </tr>
                                 <tr>
                                    <td> <b>DURATION</b>: <?php echo strtoupper($database->convert_number_to_words($mpsorders['contract_duration']));?> YEARS</td>

                                    <td><b>BILLING</b>: <?php echo $database->getBillingType($mpsorders['billingType'])['BillingType'];?></td>
                                    <td colspan="2"><b>COLLECTION OCCURENCE</b>: <?php $occurance = $mpsorders['billingType'] * $mpsorders['contract_duration']; echo $occurance;?> TIMES</td>
                                   

                                </tr>
                                 
                                <tr>
                                    <td colspan="2"> <b>Total Per Machine:
                                    <?php 
                                       $total_per_machine = ($unitColor + $unitMono + $mpsorders['rentalCharge']);
                                        echo $database->convertToMoney($total_per_machine);
                                    ?></b></td>
                                    <td colspan="2"><b>Total All Machine(s): 
                                    <?php 
                                    $total_all_machine = $total_per_machine * $mpsorders['product_qty'];
                                    echo $database->convertToMoney($total_all_machine);
                                    ?></b></td>
                                </tr>

                                <tr><td colspan="4"> <h4 style="text-align: center;">TOTAL WORTH: <?php 
                                    $total_worth = $total_all_machine * $occurance;
                                    $totalValue = $totalValue + $total_worth;
                                    echo $database->convertToMoney( $total_worth);
                                    ?></h4></td>

                                    </tr>
                                    <?php if($mpsorders['orderCollect'] == 0){?>
                                    <tr>
                                        <td colspan="4">
                                        <p style="text-align: center;"><a href="<?php echo $host;?>edit-mps/<?php echo $getID;?>/<?php echo $mpsorders['id'];?>" class="btn btn-warning btn-rounded">
                                        <i class="fa fa-file-powerpoint-o"></i>
                                        &nbsp;Edit MPS</a></p>

                                        </td>
                                   </tr>

                                   <?php }?>

                                <?php }?>
                                 <tr>
                                    <td colspan="4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                    <h3 style="text-align: center;">
                                    <b>TOTAL VALUE: <?php echo $database->convertToMoney($totalValue);?></b></h3>
                                    <h4 style="text-align: center;">
                                    <?php echo strtoupper($database->convert_number_to_words($totalValue))?> NAIRA ONLY
                                     </h4>
                                    </td>
                                </tr>

                                <div class="modal inmodal fade" id="myModalStart" tabindex="-1" role="dialog"  aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">&times;
                                        </span>
                                        <span class="sr-only">Close
                                        </span>
                                    </button>
                                    <h4 class="modal-title">
                                        <?php echo $ticketInfo['ticketNo'];?>
                                        
                                    </h4>
                                    <h4>
                                        <?php echo strtoupper($leadData['companyName']) ;?>
                                    </h4>
                                   
                                    <small class="font-bold">
                                        <b>Company Address :
                                        </b> &nbsp;
                                        <?php echo $leadData['address'];?>,
                                        <?php echo $leadData['areaname'];?>,
                                        <?php echo $leadData['lga'];?> L.G.A,
                                        <?php echo ucwords(strtolower($leadData['state']));?>,
                                        <?php echo $leadData['country'];?>.
                                    </small>
                                    <h4> Managed Printing Service Contract with <?php echo $cduration;?> years duration</h4>
                                </div>
                                <div class="modal-body">
                                <form method="post">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <h4>
                                                <b>SELECT ORDER CLOSE DATE :
                                                </b>
                                            </h4>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="txtDay" class="form-control">
                                                <?php for($i=1;$i < 32;$i++){ ?>
                                                <option>
                                                    <?php echo $i;?>
                                                </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select class="form-control" name="txtMonth">
                                                <?php for($i=1;$i < 13;$i++){ ?>
                                                <option value="<?php echo $i;?>">
                                                    <?php echo date('F', mktime(0, 0, 0, $i, 10))?>
                                                </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="txtYear" class="form-control">
                                                <option>
                                                    <?php echo date('Y');?>
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <small class="font-bold">
                                        <b>
                                            <input type="checkbox" name="check" onchange="document.getElementById('btncollectOrder').disabled = !this.checked;"> I agree and accept that this order was successfully collected on the specified date I provided to this system
                                        </b>
                                    </small>
                                    </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close
                                    </button>
                                    <input type="submit" name="btncollectOrder" disabled="" id="btncollectOrder" class="btn btn-primary" value="Collect Order"/>
                                </div>
                                </form>

                                </div>
                            </div>
                        </div>
                        </div>


                <?php }?>

                                <?php }?>
                                <tr>
                                    <td colspan="4">&nbsp;</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

<div class="modal inmodal fade" id="myModalAddMPS" tabindex="-1" role="dialog"  aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">&times;
                                        </span>
                                        <span class="sr-only">Close
                                        </span>
                                    </button>
                                    <h4 class="modal-title">
                                        <?php echo $ticketInfo['ticketNo'];?>
                                        
                                    </h4>
                                    <h4>
                                        <?php echo strtoupper($leadData['companyName']) ;?>
                                    </h4>
                                   
                                    <small class="font-bold">
                                        <b>Company Address :
                                        </b> &nbsp;
                                        <?php echo $leadData['address'];?>,
                                        <?php echo $leadData['areaname'];?>,
                                        <?php echo $leadData['lga'];?> L.G.A,
                                        <?php echo ucwords(strtolower($leadData['state']));?>,
                                        <?php echo $leadData['country'];?>.
                                    </small>
                                    <h4> Managed Printing Service Contract with <?php echo $cduration;?> years duration</h4>
                                </div>
                                <div class="modal-body">
                                     <div class="ibox-content">
                                        <form method="post" name="lead-registration" class="form-horizontal">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">&nbsp;</label>
                                                <div class="col-sm-10">
                                                   <?php ?>
                                                   
                                           <input type="hidden" name="txtContractDuration" value="<?php echo $cduration; ?>">
                                           <input type="hidden" name="txtBillingType" value="<?php echo $cBillType; ?>">
                                           <input type="hidden" name="txtDescription" value="<?php echo $cDes; ?>">
                                                </div>
                                        </div>
                                        <div class="form-group">
                                <label class="col-sm-2 control-label">Machine</label>
                                   <div class="col-sm-3">
                                       <select class="form-control m-b" name="txtProduct">
                                         <?php echo  $productsName;?>
                                         </select>   
                                       
                                    </div>
                                     <label class="col-sm-2 control-label">Qty of Machine</label>
                                   <div class="col-sm-1">
                                       <input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" name="txtQty" class="form-control" value="1" />
                                       </div>
                                        <label class="col-sm-2 control-label">Rental Charge</label>
                                   <div class="col-sm-2">

                                       <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtRentalCharge" class="form-control" onkeyup = "javascript:this.value=Comma

(this.value);" required />
                                       </div>
                                      
                                </div>
                                <div class="form-group">
                                <label class="col-sm-2 control-label">Accessories</label>
                                    <div class="col-sm-10">
                                     <select data-placeholder="Choose Accessories for this Machine" name="txtCC[]" class=" form-control chosen-select" multiple style="width:350px;" tabindex="4">
                            
                                         <?php 
                                               $acces_ = (array)$database->getAllProducts();
                                               foreach ( $acces_ as  $acceso) {
                                                if($acceso['ProductType'] != 4){continue;}
                                          ?>
                                               
                                             <option value="<?php echo $acceso['id'];?>"><?php echo strtoupper(($acceso['productName']));?></option>      

                                         <?php   } ?>
                        </select>
                                      

                                      
                                </div>
                               </div>
                               <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Mono</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostMono" class="form-control" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Mono</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" onKeyPress="return isNumberKey(event)" name="txtVolMono" class="form-control" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">&nbsp;</label>
                                     <div class="col-sm-3">
                                  
                                                                                
                                    </div>
                                </div>
                        <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Color</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostColor" class="form-control" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Color</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" onKeyPress="return isNumberKey(event)" name="txtVolColor" class="form-control" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">&nbsp;</label>
                                     <div class="col-sm-3">
                                 
                                                                                
                                    </div>
                                </div>
                                <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                     <small class="font-bold">
                                        <b>
                                            <input type="checkbox" name="check" onchange="document.getElementById('btnNewMachine').disabled = !this.checked;"> I agree and accept that this new request is tied to this Ticket and Customer
                                        </b>
                                    </small>
                                        
                           
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close
                                    </button>
                                    <input type="submit" name="btnNewMachine" disabled="" id="btnNewMachine" class="btn btn-primary" value="Create additional request"/>
                                </div>



                                        </form>
                                     </div>

                                </div>
                               
                                
                    </div>
                </div>
            </div>



                    <div class="modal inmodal fade" id="myModal5" tabindex="-1" role="dialog"  aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">&times;
                                        </span>
                                        <span class="sr-only">Close
                                        </span>
                                    </button>
                                    <h4 class="modal-title">
                                         <?php echo $ticketInfo['ticketNo'];?>
                                    </h4>
                                    <small class="font-bold">
                                        <?php echo strtoupper($leadData['companyName']) ;?>
                                    </small>
                                    <br/>
                                    <small class="font-bold">
                                        <b>Company Address :
                                        </b> &nbsp;
                                        <?php echo $leadData['address'];?>,
                                        <?php echo $leadData['areaname'];?>,
                                        <?php echo $leadData['lga'];?> L.G.A,
                                        <?php echo ucwords(strtolower($leadData['state']));?>,
                                        <?php echo $leadData['country'];?>.
                                    </small>
                                </div>
                                <div class="modal-body">
                                    <table class="table invoice-table">
                                        <tr>
                                            <th>
                                            </th>
                                            <th>Item List
                                            </th>
                                            <th>Code
                                            </th>
                                            <th>Qty
                                            </th>
                                            <th>Unit Price
                                            </th>
                                            <th>Total Price
                                            </th>
                                        </tr>
                                        </thead>
                                    <tbody>
                                        <?php
                                                $n = 1;
                                                $total_amount = 0;
                                                foreach ($salesorder as $order) {
                                                $img_value = "";
                                                if($order['orderCollect'] == 0){$img_value = 'no';}
                                         ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo $host;?>img/<?php echo $img_value;?>collected.png" width='15' height='15'>
                                            </td>
                                            <td>
                                                <div>
                                                    <strong>
                                                        <?php echo $order['productName'];?>
                                                        <?php if($order['ProductType']>1){echo " - ".$order['color'];}?>
                                                    </strong>
                                                </div>
                                                <!--  <small>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</small>-->
                                            </td>
                                            <td>
                                                <?php echo $order['Code'];?>
                                            </td>
                                            <td>
                                                <?php echo $order['qty'];?>
                                            </td>
                                            <td>
                                                <?php echo $database->convertToMoney($order['Amount']);?>
                                            </td>
                                            <td>
                                                <?php
$amount = $order['qty'] * $order['Amount'];
echo $database->convertToMoney($amount);?>
                                            </td>
                                        </tr>
                                        <?php $n++;
$total_amount += $amount;
}
?>
                                    </tbody>
                                    </table>
                                <table class="table invoice-total">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <strong>TOTAL :
                                                </strong>
                                            </td>
                                            <td>
                                                <?php echo $database->convertToMoney($total_amount);?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <form method="post">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <h4>
                                                <b>SELECT ORDER CLOSE DATE :
                                                </b>
                                            </h4>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="txtDay" class="form-control">
                                                <?php for($i=1;$i < 32;$i++){ ?>
                                                <option>
                                                    <?php echo $i;?>
                                                </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select class="form-control" name="txtMonth">
                                                <?php for($i=1;$i < 13;$i++){ ?>
                                                <option value="<?php echo $i;?>">
                                                    <?php echo date('F', mktime(0, 0, 0, $i, 10))?>
                                                </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <select name="txtYear" class="form-control">
                                                <option>
                                                    <?php echo date('Y');?>
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <small class="font-bold">
                                        <b>
                                            <input type="checkbox" name="check" onchange="document.getElementById('btncollectOrder').disabled = !this.checked;"> I agree and accept that this order was successfully collected on the specified date I provided to this system
                                        </b>
                                    </small>
                                    </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close
                                    </button>
                                    <input type="submit" name="btncollectOrder" disabled="" id="btncollectOrder" class="btn btn-primary" value="Collect Order"/>
                                </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <table class="table table-bordered table-stripped">
                    <tbody>
                        <?php if($leadData['assigned'] == $myData['id']){?>
                        <tr>
                            <th>
                                <p style="text-align: center;">
                                    <a href="<?php echo $host;?>add-lead-product/<?php echo $leadData['id'];?>" class="btn btn-info">
                                        <i class="fa fa-plus">
                                        </i>&nbsp; Add new order
                                    </a></p>
                                    <p style="text-align: center;">
                                    <a href="<?php echo $host;?>add-mps/<?php echo $leadData['id'];?>" class="btn btn-primary">
                                        <i class="fa fa-plus">
                                        </i>&nbsp; Add new mps
                                    </a>
                                </p>
                            </th>
                        </tr>
                        <?php }?>
                        <tr>
                            <th>ORDER TICKETS (
                                <?php echo sizeof($tickets);?>)
                            </th>
                        </tr>
                        <?php
foreach ($tickets as $ticket) {
$img_value = "";
if($ticket['orderCollect'] == 0){$img_value = 'no';}
?>
                        <tr>
                            <td>
                                <a href="<?php echo $host;?>lead-profile/<?php echo $leadData['id'];?>?g=<?php echo $ticket['id'];?>">
                                    <?php echo $database->getSalesType($ticket['sales_type_id'])['st'];?> -
                                    <?php echo $ticket['ticketNo'];?>
                                    <img src="<?php echo $host;?>img/<?php echo $img_value;?>collected.png" width='15' height='15'>
                                    <?php if($getOrder == $ticket['id']){echo ' - (ACTIVE)';}?>
                                </a>
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>
<!-- Mainly scripts -->
 
<script src="<?php echo $host;?>js/jquery-3.1.1.min.js">
</script>
<script src="<?php echo $host;?>js/bootstrap.min.js">
</script>
<script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js">
</script>
<script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js">
</script>
<script src="<?php echo $host;?>js/plugins/dataTables/datatables.min.js">
</script>
<!-- Custom and plugin javascript -->
<script src="<?php echo $host;?>js/inspinia.js">
</script>
<script src="<?php echo $host;?>js/plugins/pace/pace.min.js">
</script>
<script src="<?php echo $host;?>js/plugins/peity/jquery.peity.min.js">
</script>
<!-- Peity demo data -->
<script src="<?php echo $host;?>js/demo/peity-demo.js"></script>
<?php include("../includes/js.php");?>
</div>
