<?php 
include("../MPDF/mpdf.php");
include("../data/DBConfig.php");
ob_clean();
ob_end_flush();

		if($_GET['id'] != ""){
					$ticketNo = $database->test_input($_GET['id']);
					$vat = $database->test_input($_GET['vat']);
					$leadInfo = $database->getLeadDemandWithTicketNo($ticketNo);

						if($leadInfo != null){
							 
							$mpdf=new mPDF('c','A4','','' , 0 , 0 , 0 , 0 , 0 , 0); 
							 
							$mpdf->SetDisplayMode('fullpage');
							 
							$mpdf->list_indent_first_level = 0;  // 1 or 0 - whether to indent the first level of a list
							 
							$mpdf->WriteHTML(file_get_contents($host.'document/mps-sof.php?getLeadID='.$leadInfo['leadID'].'&getDemandID='.$leadInfo['id'].'&sof='.$leadInfo['orderCollect'].'&vat='.$vat));
							
							         
							$mpdf->Output();
							ob_clean();
                            ob_end_flush();
						}else{
							echo "<h1 style='color:red'>INVALID TICKET NUMBER</h1>";
						}
		}else{
			echo "<h1 style='color:red'>YOU DID NOT SPECIFY THE TICKET NUMBER</h1>";
		}

?>
