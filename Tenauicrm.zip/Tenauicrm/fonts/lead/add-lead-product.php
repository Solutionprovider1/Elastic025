<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
   $getLeadID ="";
   $getDemandID = "";
if(isset($_GET['id'])){$getLeadID = $_GET['id'];}else{$database->redirect_to($host."view-my-lead");}
//if(isset($_GET['demandID'])){$getDemandID = $_GET['demandID'];}else{$database->redirect_to($host."view-my-lead");}
$leadData = $database->getLeadData($getLeadID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}

   ?>



<?php 
$err = $err2 = $msg2 = $msg = "";

if(isset($_POST['btnUpdateLeadProduct'])){
        $product=$qty=$amount=array();
        if(isset($_POST['txtProduct'])){
            $product = $_POST['txtProduct'];
            $qty = $_POST['txtProductQty'];
            $amount = $_POST['txtProductAmount'];
            $database->addLeadDemandProduct($getLeadID,$product,$qty,$amount);
            unset($_POST);
            $database->showMsg('Success..','successfully added a ticket for ',2);
        }else{
            $database->showMsg('Error..','Add Items',1);
        }
 
}


?>

<?php



?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
</head>
<script src="<?php echo $host;?>js/jquery.min.js"></script>
<?php include("../includes/header.php");?>

<?php 
$productsName = "";
       $products = (array)$database->getAllProducts();
                                        foreach ($products as $dpt) {
                                            $value = "";
                                            if($dpt['ProductType'] == 1){
                                                $value = $dpt['productName'];
                                            }else if($dpt['ProductType'] == 2 || $dpt['ProductType'] == 3){
                                                $value = $dpt['productName'].'- - '.$dpt['color'];
                                            }
                                            else if($dpt['ProductType'] == 4){
                                                $value = $dpt['productName'].' - '.$dpt['Code'];
                                            }
                                         $productsName.='<option value="'. $dpt['id'].'">'. $value.'</option>';
                                         }
                                    $salesorder = (array)$database->getLeadProductOrderOnLeadDemand($leadData['id'],$getDemandID);
                                         ?>



<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Add new Product for <?php echo ucwords(strtolower($leadData['companyName'])) ;?> </h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Adding new order for <?php echo ucwords(strtolower($leadData['companyName'])) ;?></strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">
               <a href="<?php echo $host;?>lead-profile/<?php echo $leadData['id'];?>?" class="btn btn-success">Back</a>

                </div>
            </div>

  <div class="wrapper wrapper-content">
  <div class="tabs-container">
  <?php 
    if($leadData['assigned'] != $myData['id']){?>
    <div class="wrapper wrapper-content">
                <div class="middle-box text-center animated fadeInRightBig">
                    <h3 class="font-bold">Hello <?php echo ucwords($myData['fullname']); ?></h3>
                    <div class="error-desc">
                        You are trying to access information of a lead that is not assigned to you.:) Click the button below to access your own leads.
                        <br/><a href="<?php echo $host;?>view-my-lead" class="btn btn-primary m-t">View My Leads</a>
                    </div>
                </div>
            </div><?php die(); } ?>
                        <ul class="nav nav-tabs">
                            <!--<li class="active"><a data-toggle="tab" href="#tab-1">Basic Details</a></li>-->
                            <li class="active"><a data-toggle="tab" href="#tab-1">Products Information</a></li>
                        </ul>
                        <div class="tab-content">
                            
                            <div id="tab-1" class="tab-pane active">
                                <div class="panel-body">
                                    <!--<strong>Product Information</strong>-->

                                    <div class="hr-line-dashed"></div>

                                
                                    
                              <div id="myDiv2" class="form-group">     
                                 <?php if($err2!= ""){$database->showMsg('Error',$err,1);}
                                       else if($msg2!=""){$database->showMsg('Success',$msg,2);}?>
                                         
                                       
                                    </div>
                               
                                <form method="post">
                                <div class="form-group"><button class="add_field_button  btn btn-warning"><i class="fa fa-plus"></i>&nbsp; Add Products</button></div><br/>

                               
                                <div class="form-group">
                                     <div  class="input_fields_wrap">     
                            <?php 
                               
                                        foreach ($salesorder as $order){?>
                            <div class="form-group row del<?php echo $order['id']; ?>" >
                            <label class="col-sm-2 control-label">Products :</label>
                                   <div class="col-sm-3">
                                   <input type="hidden" name="recVal[]" value="<?php echo $order['id']; ?>" />
                                    <select class="form-control m-b" name="txtProduct[]">
                                     <?php 
                                        $dpts = (array)$database->getAllProducts();
                                        foreach ($dpts as $dpt) {?>
                                        <?php if($dpt['id'] == $order['productID']){ ?>
                                             <option value="<?php echo $dpt['id'];?>" <?php echo "selected";?>><?php echo $dpt['productName'];?></option>
                                            <?php }else{ ?>
                                            <option value="<?php echo $dpt['id'];?>"><?php echo $dpt['productName'];?></option>
                                        <?php }}?>
                                       
                                       
                                    </select> 
                                     </div>
  
                                     
                                        <label class="col-sm-1 control-label">Qty</label>
                                   <div class="col-sm-1">
                                       <input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" name="txtProductQty[]" class="form-control" value="<?php echo $order['qty'];?>" />
                                       </div>
                                        <label class="col-sm-1 control-label">Amount</label>
                                   <div class="col-sm-2">

                                       <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtProductAmount[]" class="form-control" value="<?php echo $order['Amount'];?>"  onkeyup = "javascript:this.value=Comma

(this.value);" required />
                                       </div>
                                       <a class="delete_product"  id="<?php echo $order['id']; ?>"><i class="icon-trash"></i>&nbsp<label class="col-sm-1 control-label">Delete</label></a>
                                      <a href="#"></a>

                                </div>

                              

                           <?php } ?>

                           </div>
                           </div>

                          <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                       <button name="btnUpdateLeadProduct" class="btn btn-success col-lg-12" type="submit">
                                         <i class="fa fa-cube"></i>&nbsp;UPLOAD LEAD PRODUCT</button>
                           
                                  </div>
                          </div>
                                 

                                 </form>
                            </div>
                        </div>


                    </div>

  </div>
<script type="text/javascript">
        $(document).ready( function() {
            
            $('.delete_product').click( function() {   
                var id = $(this).attr("id");
         
                if(confirm("Are you sure you want to delete this Product?")){
                    $.ajax({
                        type: "POST",
                        url: "<?php echo $host;?>lead/delete-lead-product.php",
                        data: ({id: id}),
                        cache: false,
                        success: function(html){
                          $("#myDiv").fadeTo(5000,1).fadeOut(3000);

                            $(".del"+id).fadeOut('slow'); 
                        } 
                    }); 
                }else{
                    return false;}
            });       
        });
    </script>
  <script>
  $("#myDiv").fadeTo(5000,1).fadeOut(3000);
  $("#myDiv2").fadeTo(5000,1).fadeOut(400);

    $(document).ready(function() {
    var max_fields      = 20; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
           $(wrapper).append('<div class="form-group row del'+ x +'"><label class="col-sm-2 control-label">Products :</label>'+
            '<div class="col-sm-3"><select class="form-control m-b" id="field_'+ x +'" name="txtProduct[]"><?php echo  $productsName;?> </select></div>'+
            '<label class="col-sm-1 control-label">Qty</label>'+
            '<div class="col-sm-1"><input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" id="field_'+ x +'" name="txtProductQty[]" class="form-control required" value="1" /></div>'+
            '<label class="col-sm-1 control-label">Amount</label>'+
            '<div class="col-sm-2"><input type="text"  onKeyPress="return isNumberKey(event)" onkeyup = "javascript:this.value=Comma'+'(this.value);" placeholder="AMOUNT" id="field_'+ x +'" value="0" name="txtProductAmount[]" class="form-control required" /></div>'+
            '<a href="#" class="remove_field"><label class="col-sm-1 control-label">Remove</label></a></div>'); //add input box

        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});

</script>
  
  <?php include("../includes/js.php");?>
  
