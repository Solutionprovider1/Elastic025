<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Elastic24 | Calendar</title>

    <link href="<?php echo $host;?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/fullcalendar/fullcalendar.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/fullcalendar/fullcalendar.print.css" rel='stylesheet' media='print'>
    <link href="<?php echo $host;?>css/animate.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/style.css" rel="stylesheet">

</head>

<body>

<div id="wrapper">

<?php include("../includes/header.php");?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-8">
        <h2>Calendar</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index-2.html">Home</a>
            </li>
            <li>
                Extra pages
            </li>
            <li class="active">
                <strong>Calendar</strong>
            </li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content">
    <div class="row animated fadeInDown">
      <!--  <div class="col-lg-3">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Draggable Events</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-wrench"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#">Config option 1</a>
                            </li>
                            <li><a href="#">Config option 2</a>
                            </li>
                        </ul>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div id='external-events'>
                        <p>Drag a event and drop into callendar.</p>
                        <div class='external-event navy-bg'>Go to shop and buy some products.</div>
                        <div class='external-event navy-bg'>Check the new CI from Corporation.</div>
                        <div class='external-event navy-bg'>Send documents to John.</div>
                        <div class='external-event navy-bg'>Phone to Sandra.</div>
                        <div class='external-event navy-bg'>Chat with Michael.</div>
                        <p class="m-t">
                            <input type='checkbox' id='drop-remove' class="i-checks" checked /> <label for='drop-remove'>remove after drop</label>
                        </p>
                    </div>
                </div>
            </div>
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <h2>FullCalendar</h2> is a jQuery plugin that provides a full-sized, drag & drop calendar like the one below. It uses AJAX to fetch events on-the-fly for each month and is
                    easily configured to use your own feed format (an extension is provided for Google Calendar).
                    <p>
                        <a href="http://arshaw.com/fullcalendar/" target="_blank">FullCalendar documentation</a>
                    </p>
                </div>
            </div>
        </div>-->
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>My Calendar</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-wrench"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#">Config option 1</a>
                            </li>
                            <li><a href="#">Config option 2</a>
                            </li>
                        </ul>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
    </div>
</div>


</div>
</div>

<!-- Mainly scripts -->
<script src="<?php echo $host;?>js/plugins/fullcalendar/moment.min.js"></script>
<script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
<script src="<?php echo $host;?>js/bootstrap.min.js"></script>
<script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<!-- Custom and plugin javascript -->
<script src="<?php echo $host;?>js/inspinia.js"></script>
<script src="<?php echo $host;?>js/plugins/pace/pace.min.js"></script>
<!-- jQuery UI  -->
<script src="<?php echo $host;?>js/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- iCheck -->
<script src="<?php echo $host;?>js/plugins/iCheck/icheck.min.js"></script>

<!-- Full Calendar -->
<script src="<?php echo $host;?>js/plugins/fullcalendar/fullcalendar.min.js"></script>

<script>

    $(document).ready(function() {

            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green'
            });

        /* initialize the external events
         -----------------------------------------------------------------*/


        $('#external-events div.external-event').each(function() {

            // store data so the calendar knows to render an event upon drop
            $(this).data('event', {
                title: $.trim($(this).text()), // use the element's text as the event title
                stick: true // maintain when user navigates (see docs on the renderEvent method)
            });

            // make the event draggable using jQuery UI
            $(this).draggable({
                zIndex: 1111999,
                revert: true,      // will cause the event to go back to its
                revertDuration: 0  //  original position after the drag
            });

        });


        /* initialize the calendar
         -----------------------------------------------------------------*/
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();

        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },
            editable: true,
            droppable: true, // this allows things to be dropped onto the calendar
            drop: function() {
                // is the "remove after drop" checkbox checked?
                if ($('#drop-remove').is(':checked')) {
                    // if so, remove the element from the "Draggable Events" list
                    $(this).remove();
                }
            },
            events: [
            <?php

             $events = (array)$database->getAllEvents();
                foreach ($events as $event) { 

                  $cat = $event['startDate'];
                  $cat = explode("/", $cat);
                  $d = $cat[0];
                  $m = $cat[1] - 1;
                  $y = $cat[2];  

                  $mouse = $event['startTime'];
                  $mouse = explode(":", $mouse);
                  $hr = $mouse[0];
                  $hr2 = $hr + 3;
                  $min = $mouse[1];

            ?>
                {
                    title: 'Event Created by <?php echo $database->getMyUserInformation($event['user_id'])['fullname'];?> \n <?php echo $event['event'];?>',
                    start: new Date(<?php echo $y;?>, <?php echo $m;?>, <?php echo $d;?>,<?php echo $hr;?>,<?php echo $min;?>),
                    end: new Date(<?php echo $y;?>, <?php echo $m;?>, <?php echo $d;?>,<?php echo $hr2;?>,<?php echo $min;?>),
                    color: '#ff0000'
                },

            <?php }?>


           <?php

             $events = (array)$database->getLeadRevisitDates($user_id);
             $n = 0;
                foreach ($events as $event) { 

                  $cat = $event['rDate'];
                  $cat = explode("/", $cat);
                  $d = $cat[0];
                  $m = $cat[1] - 1;
                  $y = $cat[2];  

                  //$mouse = $event['startTime'];
                 // $mouse = explode(":", $mouse);
                  $hr = 8;
                  $hr2 = $hr + 3;
                  $min = 20;

            ?>
                {
                    <?php 
                            $AdminUser = $database->getMyUserInformation($event['assigned'])['fullname'];
                            $companyName = addslashes($event['companyName']);
                           // $companyName = wordwrap($companyName,10);
                    ?>
                   

                    title: '<?php echo $companyName;?>',
                    start: new Date(<?php echo $y;?>,<?php echo $m;?>,<?php echo $d;?>,<?php echo $hr;?>,<?php echo $min;?>),
                    end: new Date(<?php echo $y;?>,<?php echo $m;?>,<?php echo $d;?>,<?php echo $hr2;?>,<?php echo $min;?>)
                    
                },

            <?php  }?>


            

              
            ]
        });


    });

</script>
</body>
</html>
