<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
   $getLeadID ="";
   $getLeadDemand = "";
if(isset($_GET['id'])){$getLeadID = $_GET['id'];}else{$database->redirect_to($host."view-my-lead");}
if(isset($_GET['leadDemandID'])){$getLeadDemand = $_GET['leadDemandID'];}else{$database->redirect_to($host."view-my-lead");}

//if(isset($_GET['demandID'])){$getDemandID = $_GET['demandID'];}else{$database->redirect_to($host."view-my-lead");}
$leadData = $database->getLeadData($getLeadID);
if(empty($leadData)){
    $database->redirect_to($host."view-my-lead");
}

?>

 <?php 
                        $err = "";
                        $msg = "";
                       
                            if(isset($_POST['btnCreateLead'])){
                              
                                   // $phone = $database->test_input($_POST['txtPhone']);
                                    $leadID = $getLeadID;
                                    $productID = $database->test_input($_POST['txtProduct']);
                                    $qty = $database->test_input($_POST['txtQty']);
                                    $rentalcharge = $database->test_input($_POST['txtRentalCharge']);
                                    $costMono = $database->test_input($_POST['txtCostMono']);
                                    $costColor = $database->test_input($_POST['txtCostColor']);
                                    $minVolMono = $database->test_input($_POST['txtVolMono']);
                                    $minVolColor = $database->test_input($_POST['txtVolColor']);
                                    $contractDuration = $database->test_input($_POST['txtContractDuration']);
                                    $BillingType = $database->test_input($_POST['txtBillingType']);
                                    $description =$database->test_input($_POST['txtDescription']);

                                    $accessories = "";
                                    if(isset($_POST['txtCC'])){
                                        if (is_array($_POST['txtCC'])) {
                                                foreach($_POST['txtCC'] as $value){
                                                  $accessories = $accessories.",".$value;
                                                }
                                            }else {
                                                $value = $_POST['txtCC'];
                                                $accessories =  $value;
                                              }
                                        }



                                    

                                 if($leadID!= "" && $productID != "" && $qty != "" && $rentalcharge!= "" && $costMono != "" 
                                    && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $costColor !="" && $minVolMono != "" && $minVolColor!= "" && $contractDuration !="" && $BillingType != ""){

                      //  updateMPSMachineInfo($id,$leadDemandID,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories){
                                        $database->updateMPSMachineInfo($getLeadDemand,$leadID,$productID,$qty,$rentalcharge,$costMono,$costColor,$minVolMono,$minVolColor,$contractDuration,$BillingType,$description,$accessories);
                                       
                                            $msg = "your lead MPS ticket has been editted successfully!.";
                                           // $_POST['txtFname']="";
                                            unset($_POST);

                                                                          
                                    
                                    }else{
                                            if($productID == ""){$err.="<li>please select product</li>";}
                                            if($qty == ""){$err.="<li>please enter quantity of product</li>";}
                                            if($rentalcharge == ""){$err.="<li>please enter rental charge</li>";}
                                            if($costMono == ""){$err.="<li>please enter the cost of printing Mono</li>";}
                                            if($costColor == ""){$err.="<li>please enter the cost of printing Color</li>";}
                                            if($minVolColor == ""){$err.="<li>please enter the minimum printing Mono</li>";}
                                            if($minVolMono == ""){$err.="<li>please enter the minimum printing Color</li>";}
                                            if($contractDuration == ""){$err.="<li>please select the Contract duration</li>";}
                                            if($BillingType == ""){$err.="<li>please select the Billing type</li>";}
                                    }
                            
                                }

                        ?>


                      <?php $mpsorder = (array)$database->getLeadMPSWithID($getLeadID,$getLeadDemand); ?>
<!DOCTYPE HTML>
<html>
<head>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenaui+ :: CRM for Tenaui</title>
    <?php include("../includes/styles.php");?>
    <link href="<?php echo $host;?>css/plugins/dualListbox/bootstrap-duallistbox.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/select2/select2.min.css" rel="stylesheet">
</head>
<script src="<?php echo $host;?>js/jquery.min.js"></script>
<?php include("../includes/header.php");?>

<script type="text/javascript">
var parent = <?php echo $database->getArrayStates();?>;
var child = <?php echo $database->getLGAofStates();?>;
var gchild = <?php echo $database->getAreasofLGA();?>;
    function LoadChild(){
        var i = document.getElementById("parent").selectedIndex ;
       // var dp = document.getElementById("child");
        var dp2 = document.getElementById("gchild");
      //  var count = child[i-1].length;
        var count2 = gchild[i-1].length;

        //var html = "<option value=\"\" disabled selected hidden>- select -</option>";
       // for(var k = 0 ; k < count ; k ++){
       //     html += "<option value=\""+child[i-1][k][0]+"\">"+child[i-1][k][1]+"</option>";
       // }

        var html2 = "<option value=\"\" disabled selected hidden>- select -</option>";
        for(var k = 0 ; k < count2 ; k ++){
            html2 += "<option value=\""+gchild[i-1][k][0]+"\">"+gchild[i-1][k][1]+"</option>";
        }
        
       // dp.innerHTML = html;
        dp2.innerHTML = html2;
    }
    
</script>

<?php 
$productsName = "";
       $products = (array)$database->getAllProducts();
                                        foreach ($products as $dpt) {

                                                if($dpt['ProductType'] == 2){break;}
                                                $value = "";
                                                $sel = "";
                                                if($dpt['ProductType'] == 1){
                                                    $value = $dpt['productName'];
                                                    if($dpt['id'] == $mpsorder['productID']){
                                                        $sel = "selected";
                                                    }
                                                }
                                           
                                               $productsName.='<option value="'. $dpt['id'].'" '.$sel.'>'. $value.'</option>';
                                         }

                                         ?>



<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Creating MPS for <?php echo $leadData['companyName'];?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo $host;?>">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Create Managed Printing Service</strong>
                        </li>
                    </ol>
                </div>
               <div class="col-lg-2">
               <a href="<?php echo $host;?>lead-profile/<?php echo $getLeadID;?>" class="btn btn-success">Back</a>

                </div>
            </div>

  <div class="wrapper wrapper-content">
  <div class="row">
                <div class="col-lg-10">
                    <div class="ibox float-e-margins">
                        

                       

                        <div class="ibox-content">
                            <form method="post" name="lead-registration" class="form-horizontal">

                             <div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	<?php if($err!= ""){$database->showMsg('Error',$err,1);}
                                    	 else if($msg!=""){$database->showMsg('Success',$msg,2);}?>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">Company Name</label>
                                   <div class="col-sm-10">
                                        <input name="txtCompany" value="<?php echo $leadData['companyName'];?>" type="text" placeholder="Enter company Name" required class="form-control required" disabled>
                                       
                                    </div>
                                    
                                </div>
                                
<div class="hr-line-dashed"></div>
                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Machine</label>
                                   <div class="col-sm-3">
                                       <select class="form-control m-b" name="txtProduct">
                                         <?php echo  $productsName;?>
                                         </select>   
                                       
                                    </div>
                                     <label class="col-sm-2 control-label">Qty of Machine</label>
                                   <div class="col-sm-1">
                                       <input type="text" placeholder="QTY." required onKeyPress="return isNumberKey(event)" name="txtQty" class="form-control" value="<?php echo $mpsorder['product_qty'];?>" />
                                       </div>
                                        <label class="col-sm-2 control-label">Rental Charge</label>
                                   <div class="col-sm-2">

                                       <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtRentalCharge" value="<?php echo $mpsorder['rentalCharge'];?>" class="form-control" onkeyup = "javascript:this.value=Comma

(this.value);" required />
                                       </div>
                                      
                                </div>

                                <div class="form-group">
                                <label class="col-sm-2 control-label">Accessories</label>
                                    <div class="col-sm-10">
                                     <select data-placeholder="Choose Accessories for this Machine" name="txtCC[]" class=" form-control chosen-select" multiple style="width:350px;" tabindex="4">
                            
                                         <?php 
                                               $acces_ = (array)$database->getAllProducts();
                                               foreach ( $acces_ as  $acceso) {
                                                if($acceso['ProductType'] != 4){continue;}
                                          ?>

<?php
  $cat = $mpsorder['accesories'];
  $cat = explode(",", $cat);
   foreach($cat as $cats){?>

    
 <option value="<?php echo $acceso['id'];?>" <?php if($cats ==$acceso['id']){ echo 'selected';}?>><?php echo strtoupper(($acceso['productName']));?></option> 

 <?php }?>


                                               
                                                  

                                         <?php   } ?>
                        </select>
                                      

                                      
                                </div>
                                </div>
                               
                                 <div class="form-group">
                                 </div>

 
                <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Mono</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostMono" class="form-control" value="<?php echo $mpsorder['cost_mono'];?>" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Mono</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" onKeyPress="return isNumberKey(event)" name="txtVolMono" class="form-control" value="<?php echo $mpsorder['min_vol_mono'];?>" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">Total:</label>
                                     <div class="col-sm-3">
                                  
                                                                                
                                    </div>
                                </div>
                        <div class="form-group">
                                <label class="col-sm-2 control-label">Cost-Color</label>
                                   <div class="col-sm-2">
                                    <input type="text" placeholder="AMOUNT" onKeyPress="return isNumberKey(event)" name="txtCostColor" class="form-control" value="<?php echo $mpsorder['cost_color'];?>" onkeyup = "javascript:this.value=Comma(this.value);" required />
                                        
                                    </div>
                                     <label class="col-sm-2 control-label">Min-Volume-Color</label>
                                   <div class="col-sm-2">
                                   <input type="text" placeholder="volume" value="<?php echo $mpsorder['min_vol_color'];?>" onKeyPress="return isNumberKey(event)" name="txtVolColor" class="form-control" required />
                                       
                                        
                                    </div>
                                  <!--  <label class="col-sm-1 control-label">L.G.A</label>
                                   <div class="col-sm-2">
                                   <select class="form-control m-b" name="txtLga" required data-validation-required-message="LGA is required" id="child" onChange="LoadGChild();">
                                    

                                    </select>
                                                                                
                                    </div>-->
                                    <label class="col-sm-1 control-label">Total:</label>
                                     <div class="col-sm-3">
                                  
                                                                                
                                    </div>
                                </div>

                                 <div class="form-group">
                                <label class="col-sm-2 control-label">Contract Duration</label>
                                <div class="col-sm-3">
                                       <select class="form-control m-b" name="txtContractDuration">
                                         <?php for($i = 4;$i <12;$i++){?>
                                         <option value="<?php echo $i;?>" <?php if($mpsorder['contract_duration'] == $i){ echo 'selected';}?>><?php echo strtoupper($database->convert_number_to_words($i));?> YEARS</option>
                                         <?php }?>
                                         </select>   
                                       
                                    </div>
                                    <label class="col-sm-2 control-label">Billing Type</label>
                                <div class="col-sm-3">
                                       <select class="form-control m-b" name="txtBillingType">

                                       <?php 
                                            $bt = (array)$database->getBillingType();
                                            foreach ($bt as $bts) {
                                               ?>
                                        
                                         <option value="<?php echo $bts['value'];?>" <?php if($mpsorder['billingType'] == $bts['value']){ echo 'selected';}?>><?php echo $bts['BillingType'];?></option>
                                         
                                         <?php }?>
                                         </select>   
                                       
                                    </div>
                                  
                                </div>
                                
                            <div class="hr-line-dashed"></div>
                             <div class="form-group">
                                <label class="col-sm-2 control-label">Description</label>
                                   <div class="col-sm-10">
                                   <textarea class="form-control" name="txtDescription" placeholder="Describe this MPS Contract"><?php echo $mpsorder['description'];?></textarea>
                                    </div>
                                    
                                </div>
<div class="hr-line-dashed"></div>
                                

							<div class="form-group">
                                <label class="col-sm-2 control-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                    	 <button name="btnCreateLead" class="btn btn-primary col-lg-12" type="submit">
                                         <i class="fa fa-user"></i>&nbsp;Edit Managed Print Service</button>
                           
                                    </div>
                                </div>
                                </form>

                                                                                  
  </div>
  
  <?php include("../includes/js.php");?>
  <script type="text/javascript">
     $('#trucated').inputmask("numeric", {
    radixPoint: ".",
    groupSeparator: ",",
    digits: 2,
    autoGroup: true,
    prefix: 'N', //No Space, this will truncate the first character
    rightAlign: false,
   oncleared: function(){self.Value('');}
   });
    
  </script>
