<?php
  include("../data/DBConfig.php");
  include_once("../data/sessioncheck.php");
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tenaui+</title>

    <link href="<?php echo $host;?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $host;?>font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/animate.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/style.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/datapicker/datepicker3.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
    <link href="<?php echo $host;?>css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">

   <?php include("../includes/header.php");?>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-9">
                    <h2>Pin Board</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index-2.html">Home</a>
                        </li>
                        
                        <li class="active">
                            <strong>Pin Board</strong>
                        </li>
                    </ol>
                </div>
            </div>
        <div class="row">

        <div class="col-lg-3">
        <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Revisit Date</h5>
                            <!--<div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                               <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>-->
                        </div>
                        <div class="ibox-content">
                          
                            <form method="post">
                            <?php 
                                    if(isset($_POST['btnSubmitRevisitDate'])){
                                        $eventDate = $database->test_input($_POST['txtEventDate']);
                                        $eventTime = $database->test_input($_POST['txtEventTime']);
                                        $eventTitle = $database->test_input($_POST['txtEventTitle']);

                                        if($eventTime != "" && $eventDate != "" && $eventTitle != ""){
                                            $database->addAnEvent($user_id,$eventTitle,$eventDate,$eventTime);
                                            echo $database->showMsg('', 'Your event has been added successfully!.',2);

                                        }else{
                                            echo $database->showMsg('', 'all fields are required', 1);
                                        }

                                    }

                            ?>
                                <div class="form-group" id="data_2">
                                    <label class="font-normal">Revisit Date</label>
                                    <div class="input-group date">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" name="txtRDate">
                                    </div>
                                </div>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control" name="txtRTime"  >
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>

                                

                                <div class="form-group">
                                    <label class="font-normal">Event Title</label>
                                    <div class="input-group date">
                                    <textarea class="form-control" name="txtEventTitle" maxlength="150"></textarea>
                                    </div>
                                </div>
                                 <div class="form-group">
                                   
                                    <div class="input-group">
                                    <input type="submit" name="btnSubmitRevisitDate" value="Create Event" class="btn btn-warning"/>
                                    </div>
                                </div>
                        </form>
                           
                        </div>
                    </div>
             <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add an Event</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                               <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                          
                            <form method="post">
                            <?php 
                                    if(isset($_POST['btnSubmitEvent'])){
                                        $eventDate = $database->test_input($_POST['txtEventDate']);
                                        $eventTime = $database->test_input($_POST['txtEventTime']);
                                        $eventTitle = $database->test_input($_POST['txtEventTitle']);

                                        if($eventTime != "" && $eventDate != "" && $eventTitle != ""){
                                            $database->addAnEvent($user_id,$eventTitle,$eventDate,$eventTime);
                                            echo $database->showMsg('', 'Your event has been added successfully!.',2);

                                        }else{
                                            echo $database->showMsg('', 'all fields are required', 1);
                                        }

                                    }

                            ?>
                                <div class="form-group" id="data_2">
                                    <label class="font-normal">Event Date</label>
                                    <div class="input-group date">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input type="text" class="form-control" name="txtEventDate">
                                    </div>
                                </div>
                                <div class="input-group clockpicker" data-autoclose="true">
                                    <input type="text" class="form-control" name="txtEventTime"  >
                                    <span class="input-group-addon">
                                        <span class="fa fa-clock-o"></span>
                                    </span>
                                </div>

                                

                                <div class="form-group">
                                    <label class="font-normal">Event Title</label>
                                    <div class="input-group date">
                                    <textarea class="form-control" name="txtEventTitle" maxlength="150"></textarea>
                                    </div>
                                </div>
                                 <div class="form-group">
                                   
                                    <div class="input-group">
                                    <input type="submit" name="btnSubmitEvent" value="Create Event" class="btn btn-success"/>
                                    </div>
                                </div>
                        </form>
                           
                        </div>
                    </div>
        </div>
            <div class="col-lg-9">
                <div class="wrapper wrapper-content animated fadeInUp">
                 <div class="form-group" id="data_5">
                            <form method="post">
                                <label class="font-normal">Range select</label>
                                <div class="input-daterange input-group" id="datepicker">
                                <span class="input-group-addon">from</span>
                                    <input type="text" class="input-sm form-control" name="start" value=""/>
                                    <span class="input-group-addon">to</span>
                                    <input type="text" class="input-sm form-control" name="end" value="" />
                                     <span class="input-group-addon">
                                     <button name="btnSearchMyPin" class="btn-primary"><i class="fa fa-search"></i></button>
                                     </span>
                                </div>
                            </form>
                    </div>
                    <ul class="notes">

                    <?php 
                         $events = (array)$database->getLeadRevisitDates();

                    ?>
                        <li>
                            <div>
                                <small>12:03:28 12-04-2014 </small>

                                <h4>The years, sometimes by accident, sometimes on purpose (injected humour and the like). The years, sometimes by accident, sometimes on purpose (injected humour and the like). </h4>
                                
                                <a href="#"><h4><i class="fa fa-pencil"></i></h4></a>

                            </div>
                        </li>
                        






                        <li>
                            <div>
                                <small>9:12:28 10-04-2014</small>
                                <h4>The standard chunk of Lorem</h4>
                                <p>Ipsum used since the 1500s is reproduced below for those interested.</p>
                                <a href="#"><i class="fa fa-trash-o "></i></a>
                            </div>
                        </li>
                        <li>
                            <div>
                                <small>3:33:12 6-03-2014</small>
                                <h4>The generated Lorem Ipsum </h4>
                                <p>The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                                <a href="#"><i class="fa fa-trash-o "></i></a>
                            </div>
                        </li>
                        <li>
                            <div>
                                <small>5:20:11 4-04-2014</small>
                                <h4>Contrary to popular belief</h4>
                                <p>Hampden-Sydney College in Virginia, looked up one.</p>
                                <a href="#"><i class="fa fa-trash-o "></i></a>
                            </div>
                        </li>
                        <li>
                            <div>
                                <small>2:10:12 4-05-2014</small>
                                <h4>There are many variations</h4>
                                <p>All the Lorem Ipsum generators on the Internet .</p>
                                <a href="#"><i class="fa fa-trash-o "></i></a>
                            </div>
                        </li>
                        <li>
                            <div>
                                <small>10:15:26 6-04-2014</small>
                                <h4>Ipsum used standard chunk of Lorem</h4>
                                <p>Standard chunk  is reproduced below for those.</p>
                                <a href="#"><i class="fa fa-trash-o "></i></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2014-2017
            </div>
        </div>

        </div>
        </div>

    <!-- Mainly scripts -->
    <script src="<?php echo $host;?>js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo $host;?>js/bootstrap.min.js"></script>
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo $host;?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <!-- Custom and plugin javascript -->
    <script src="<?php echo $host;?>js/inspinia.js"></script>
    <script src="<?php echo $host;?>js/plugins/pace/pace.min.js"></script>




    <!-- Chosen -->
    <script src="<?php echo $host;?>js/plugins/chosen/chosen.jquery.js"></script>

   <!-- JSKnob -->
   <script src="js/plugins/jsKnob/jquery.knob.js"></script>

   <!-- Input Mask-->
    <script src="<?php echo $host;?>js/plugins/jasny/jasny-bootstrap.min.js"></script>

   <!-- Data picker -->
   <script src="<?php echo $host;?>js/plugins/datapicker/bootstrap-datepicker.js"></script>

   <!-- NouSlider -->
   <script src="<?php echo $host;?>js/plugins/nouslider/jquery.nouislider.min.js"></script>

   <!-- Switchery -->
   <script src="<?php echo $host;?>js/plugins/switchery/switchery.js"></script>

    <!-- IonRangeSlider -->
    <script src="<?php echo $host;?>js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

    <!-- iCheck -->
    <script src="<?php echo $host;?>js/plugins/iCheck/icheck.min.js"></script>

    <!-- MENU -->
    <script src="<?php echo $host;?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Color picker -->
    <script src="<?php echo $host;?>js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

    <!-- Clock picker -->
    <script src="<?php echo $host;?>js/plugins/clockpicker/clockpicker.js"></script>


    <!-- Image cropper -->
    <script src="<?php echo $host;?>js/plugins/cropper/cropper.min.js"></script>

    <!-- Date range use moment.js same as full calendar plugin -->
    <script src="<?php echo $host;?>js/plugins/fullcalendar/moment.min.js"></script>

    <!-- Date range picker -->
    <script src="<?php echo $host;?>js/plugins/daterangepicker/daterangepicker.js"></script>

    <!-- Select2 -->
    <script src="<?php echo $host;?>js/plugins/select2/select2.full.min.js"></script>

    <!-- TouchSpin -->
    <script src="<?php echo $host;?>js/plugins/touchspin/jquery.bootstrap-touchspin.min.js"></script>

    <!-- Tags Input -->
    <script src="<?php echo $host;?>js/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>

    <!-- Dual Listbox -->
    <script src="<?php echo $host;?>js/plugins/dualListbox/jquery.bootstrap-duallistbox.js"></script>

    <script>
        $(document).ready(function(){

           

            $('#data_1 .input-group.date').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#data_2 .input-group.date').datepicker({
                startView: 1,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $('#data_3 .input-group.date').datepicker({
                startView: 2,
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            $('#data_4 .input-group.date').datepicker({
                minViewMode: 1,
                keyboardNavigation: false,
                forceParse: false,
                forceParse: false,
                autoclose: true,
                todayHighlight: true
            });

            $('#data_5 .input-daterange').datepicker({
                keyboardNavigation: false,
                forceParse: false,
                autoclose: true
            });

            

            $('input[name="daterange"]').daterangepicker();

            $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));

            $('#reportrange').daterangepicker({
                format: 'MM/DD/YYYY',
                startDate: moment().subtract(29, 'days'),
                endDate: moment(),
                minDate: '01/01/2012',
                maxDate: '12/31/2015',
                dateLimit: { days: 60 },
                showDropdowns: true,
                showWeekNumbers: true,
                timePicker: false,
                timePickerIncrement: 1,
                timePicker12Hour: true,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                opens: 'right',
                drops: 'down',
                buttonClasses: ['btn', 'btn-sm'],
                applyClass: 'btn-primary',
                cancelClass: 'btn-default',
                separator: ' to ',
                locale: {
                    applyLabel: 'Submit',
                    cancelLabel: 'Cancel',
                    fromLabel: 'From',
                    toLabel: 'To',
                    customRangeLabel: 'Custom',
                    daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
                    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                    firstDay: 1
                }
            }, function(start, end, label) {
                console.log(start.toISOString(), end.toISOString(), label);
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            });

            $(".select2_demo_1").select2();
            $(".select2_demo_2").select2();
            $(".select2_demo_3").select2({
                placeholder: "Select a state",
                allowClear: true
            });


            $(".touchspin1").TouchSpin({
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin2").TouchSpin({
                min: 0,
                max: 100,
                step: 0.1,
                decimals: 2,
                boostat: 5,
                maxboostedstep: 10,
                postfix: '%',
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $(".touchspin3").TouchSpin({
                verticalbuttons: true,
                buttondown_class: 'btn btn-white',
                buttonup_class: 'btn btn-white'
            });

            $('.dual_select').bootstrapDualListbox({
                selectorMinimalHeight: 160
            });


        });

        $('.chosen-select').chosen({width: "100%"});

        $("#ionrange_1").ionRangeSlider({
            min: 0,
            max: 5000,
            type: 'double',
            prefix: "$",
            maxPostfix: "+",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_2").ionRangeSlider({
            min: 0,
            max: 10,
            type: 'single',
            step: 0.1,
            postfix: " carats",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_3").ionRangeSlider({
            min: -50,
            max: 50,
            from: 0,
            postfix: "°",
            prettify: false,
            hasGrid: true
        });

        $("#ionrange_4").ionRangeSlider({
            values: [
                "January", "February", "March",
                "April", "May", "June",
                "July", "August", "September",
                "October", "November", "December"
            ],
            type: 'single',
            hasGrid: true
        });

        $("#ionrange_5").ionRangeSlider({
            min: 10000,
            max: 100000,
            step: 100,
            postfix: " km",
            from: 55000,
            hideMinMax: true,
            hideFromTo: false
        });

        $(".dial").knob();

        var basic_slider = document.getElementById('basic_slider');

        noUiSlider.create(basic_slider, {
            start: 40,
            behaviour: 'tap',
            connect: 'upper',
            range: {
                'min':  20,
                'max':  80
            }
        });

        var range_slider = document.getElementById('range_slider');

        noUiSlider.create(range_slider, {
            start: [ 40, 60 ],
            behaviour: 'drag',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });

        var drag_fixed = document.getElementById('drag-fixed');

        noUiSlider.create(drag_fixed, {
            start: [ 40, 60 ],
            behaviour: 'drag-fixed',
            connect: true,
            range: {
                'min':  20,
                'max':  80
            }
        });


    </script>
    <script type="text/javascript">
$('.clockpicker').clockpicker();
</script>

</body>

</html>
