<link href="<?php echo $host;?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $host;?>font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="<?php echo $host;?>css/animate.css" rel="stylesheet">
<link href="<?php echo $host;?>css/style.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/steps/jquery.steps.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/iCheck/custom.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/chosen/bootstrap-chosen.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/cropper/cropper.min.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/switchery/switchery.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/datapicker/datepicker3.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/datapicker/datepicker3.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/select2/select2.min.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet">
<link href="<?php echo $host;?>css/plugins/dualListbox/bootstrap-duallistbox.min.css" rel="stylesheet">
<!-- Sweet Alert -->
    <link href="<?php echo $host;?>css/plugins/sweetalert/sweetalert.css" rel="stylesheet">


